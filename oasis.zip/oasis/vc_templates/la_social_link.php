<?php
$el_class = $style = '';

$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

$css_class = implode(' ', array(
        'social-media-link',
        'style-' . $style
    ))  . $this->getExtraClass( $el_class );
?>
<div class="<?php echo esc_attr($css_class)?>"><?php
    if ( $facebook_url = cs_get_option('facebook_url') ) :
        ?><a target="_blank" rel="nofollow" class="facebook" href="<?php echo esc_url($facebook_url);?>"  title="<?php esc_attr_e('Facebook', LA_TEXTDOMAIN) ?>"><i class="fa fa-facebook"></i></a><?php
    endif;
    if ( $twitter_url = cs_get_option('twitter_url') ) :
        ?><a target="_blank" rel="nofollow" class="twitter" href="<?php echo esc_url($twitter_url);?>"  title="<?php esc_attr_e('Twitter', LA_TEXTDOMAIN) ?>"><i class="fa fa-twitter"></i></a><?php
    endif;
    if ( $pinterest_url = cs_get_option('pinterest_url') ) :
        ?><a target="_blank" rel="nofollow" class="pinterest" href="<?php echo esc_url($pinterest_url);?>"  title="<?php esc_attr_e('Pinterest', LA_TEXTDOMAIN) ?>"><i class="fa fa-pinterest"></i></a><?php
    endif;
    if ( $linkedin_url = cs_get_option('linkedin_url') ) :
        ?><a target="_blank" rel="nofollow" class="linkedin" href="<?php echo esc_url($linkedin_url);?>"  title="<?php esc_attr_e('LinkedIn', LA_TEXTDOMAIN) ?>"><i class="fa fa-linkedin"></i></a><?php
    endif;
    if ( $google_plus_url = cs_get_option('google_plus_url') ) :
        ?><a target="_blank" rel="nofollow" class="google-plus" href="<?php echo esc_url($google_plus_url);?>"  title="<?php esc_attr_e('Google Plus', LA_TEXTDOMAIN) ?>"><i class="fa fa-google-plus"></i></a><?php
    endif;
    if ( $rss_url = cs_get_option('rss_url') ) :
        ?><a target="_blank" rel="nofollow" class="rss" href="<?php echo esc_url($rss_url);?>"  title="<?php esc_attr_e('Rss', LA_TEXTDOMAIN) ?>"><i class="fa fa-rss"></i></a><?php
    endif;
    if ( $tumblr_url = cs_get_option('tumblr_url') ) :
        ?><a target="_blank" rel="nofollow" class="tumblr" href="<?php echo esc_url($tumblr_url);?>"  title="<?php esc_attr_e('Tumblr', LA_TEXTDOMAIN) ?>"><i class="fa fa-tumblr"></i></a><?php
    endif;
    if ( $instagram_url = cs_get_option('instagram_url') ) :
        ?><a target="_blank" rel="nofollow" class="instagram" href="<?php echo esc_url($instagram_url);?>"  title="<?php esc_attr_e('Instagram', LA_TEXTDOMAIN) ?>"><i class="fa fa-instagram"></i></a><?php
    endif;
    if ( $youtube_url = cs_get_option('youtube_url') ) :
        ?><a target="_blank" rel="nofollow" class="youtube" href="<?php echo esc_url($youtube_url);?>"  title="<?php esc_attr_e('Youtube', LA_TEXTDOMAIN) ?>"><i class="fa fa-youtube-play"></i></a><?php
    endif;
    if ( $vimeo_url = cs_get_option('vimeo_url') ) :
        ?><a target="_blank" rel="nofollow" class="vimeo" href="<?php echo esc_url($vimeo_url);?>"  title="<?php esc_attr_e('Vimeo', LA_TEXTDOMAIN) ?>"><i class="fa fa-vimeo"></i></a><?php
    endif;
    if ( $behance_url = cs_get_option('behance_url') ) :
        ?><a target="_blank" rel="nofollow" class="behance" href="<?php echo esc_url($behance_url);?>"  title="<?php esc_attr_e('Behance', LA_TEXTDOMAIN) ?>"><i class="fa fa-behance"></i></a><?php
    endif;
    if ( $dribble_url = cs_get_option('dribble_url') ) :
        ?><a target="_blank" rel="nofollow" class="dribble" href="<?php echo esc_url($dribble_url);?>"  title="<?php esc_attr_e('Dribble', LA_TEXTDOMAIN) ?>"><i class="fa fa-dribble"></i></a><?php
    endif;
    if ( $flickr_url = cs_get_option('flickr_url') ) :
        ?><a target="_blank" rel="nofollow" class="flickr" href="<?php echo esc_url($flickr_url);?>"  title="<?php esc_attr_e('Flickr', LA_TEXTDOMAIN) ?>"><i class="fa fa-flickr"></i></a><?php
    endif;
    if ( $git_url = cs_get_option('git_url') ) :
        ?><a target="_blank" rel="nofollow" class="git" href="<?php echo esc_url($git_url);?>"  title="<?php esc_attr_e('Git', LA_TEXTDOMAIN) ?>"><i class="fa fa-git"></i></a><?php
    endif;
    if ( $skype_url = cs_get_option('skype_url') ) :
        ?><a target="_blank" rel="nofollow" class="skype" href="<?php echo esc_url($skype_url);?>"  title="<?php esc_attr_e('Skype', LA_TEXTDOMAIN) ?>"><i class="fa fa-skype"></i></a><?php
    endif;
    if ( $weibo_url = cs_get_option('weibo_url') ) :
        ?><a target="_blank" rel="nofollow" class="weibo" href="<?php echo esc_url($weibo_url);?>"  title="<?php esc_attr_e('Weibo', LA_TEXTDOMAIN) ?>"><i class="fa fa-weibo"></i></a><?php
    endif;
    if ( $foursquare_url = cs_get_option('foursquare_url') ) :
        ?><a target="_blank" rel="nofollow" class="foursquare" href="<?php echo esc_url($foursquare_url);?>"  title="<?php esc_attr_e('Foursquare', LA_TEXTDOMAIN) ?>"><i class="fa fa-foursquare"></i></a><?php
    endif;
    if ( $soundcloud_url = cs_get_option('soundcloud_url') ) :
        ?><a target="_blank" rel="nofollow" class="soundcloud" href="<?php echo esc_url($soundcloud_url);?>"  title="<?php esc_attr_e('Soundcloud', LA_TEXTDOMAIN) ?>"><i class="fa fa-soundcloud"></i></a><?php
    endif;
    ?></div>