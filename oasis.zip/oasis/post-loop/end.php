<?php
/*
 * Template loop-end
 */
global $oasis_loop;
$layout = isset($oasis_loop['loop_layout']) ? $oasis_loop['loop_layout'] : 'grid';
$style = isset($oasis_loop['loop_style']) ? $oasis_loop['loop_style'] : 1;
?>
</div>
<!-- .posts-loop -->