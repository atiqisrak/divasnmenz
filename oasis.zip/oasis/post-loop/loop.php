<?php
global $oasis_loop;
$blog_style = isset($oasis_loop['blog_style']) ? $oasis_loop['blog_style'] : 'grid-3col';
$show_postformat = isset($oasis_loop['blog_show_postformat']) ? $oasis_loop['blog_show_postformat'] : false;
$excerpt_length = isset($oasis_loop['excerpt_length']) ? $oasis_loop['excerpt_length'] : 5;
$thumbnail_size = (isset($oasis_loop['image_size']) && !empty($oasis_loop['image_size']) ? $oasis_loop['image_size'] : 'thumbnail');
$title_tag      = (isset($oasis_loop['title_tag']) && !empty($oasis_loop['title_tag']) ? $oasis_loop['title_tag'] : 'h2');
$post_class = array('loop-item','grid-item','post-item');
?>
<article <?php post_class($post_class); ?>>
    <div class="item-inner">
        <?php if(has_post_thumbnail()): ?>
            <div class="entry-thumbnail">
                <?php do_action('oasis/before_resize_image'); ?>
                <a href="<?php the_permalink();?>"><?php the_post_thumbnail($thumbnail_size);?></a>
                <?php do_action('oasis/after_resize_image'); ?>
                <span class="<?php echo esc_attr(oasis_get_post_format_icon()) ?>"></span>
            </div><!-- .entry-thumbnail -->
        <?php endif; ?>
        <div class="entry-meta"><div class="post-date"><?php echo get_the_date('d M, Y'); ?></div></div><!-- .entry-meta -->
        <header class="entry-header">
            <?php the_title( sprintf( '<%s class="entry-title"><a href="%s">',$title_tag, esc_url( get_the_permalink() ) ), sprintf('</a></%s>', $title_tag) ); ?>
        </header><!-- .entry-header -->
        <div class="entry-excerpt"><?php the_excerpt();?></div><!-- .entry-content -->
    </div>
</article>