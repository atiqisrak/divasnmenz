<?php
global $oasis_loop;
if(!isset($oasis_loop['loop_index'])){
    $oasis_loop['loop_index'] = 0;
}
$oasis_loop['loop_index']++;
$loop_index     = isset($oasis_loop['loop_index']) ? $oasis_loop['loop_index'] : 1;
$thumbnail_size = (isset($oasis_loop['image_size']) && !empty($oasis_loop['image_size']) ? $oasis_loop['image_size'] : 'thumbnail');
$title_tag      = (isset($oasis_loop['title_tag']) && !empty($oasis_loop['title_tag']) ? $oasis_loop['title_tag'] : 'h3');
$post_class     = array('loop-item','grid-item','post-item');
?>
<article <?php post_class($post_class); ?>>
    <div class="item-inner">
        <div class="post-left">
            <div class="post-date"><?php echo get_the_date('d M, Y'); ?></div>
        </div>
        <div class="post-right">
            <header class="entry-header">
                <?php the_title( sprintf( '<%s class="entry-title"><a href="%s">',$title_tag, esc_url( get_the_permalink() ) ), sprintf('</a></%s>', $title_tag) ); ?>
            </header>
            <div class="entry-excerpt"><?php the_excerpt();?></div>
        </div>
    </div>
</article>