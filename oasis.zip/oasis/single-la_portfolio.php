<?php
get_header();

$portfolio_single_style = Oasis_Helper::getOption('single_portfolio_style', 'default');

if( $_tmp = Oasis_Helper::getPostMeta( get_the_ID(), OASIS_OPTION, 'single_portfolio_style') ) {
    if( $_tmp && $_tmp != 'inherit' ){
        $portfolio_single_style = $_tmp;
    }
}

do_action( 'oasis/action/before_render_main' ); ?>
<div id="main" class="site-main">
    <div class="container">
        <div class="row">
            <main id="site-content" class="<?php echo esc_attr(Oasis()->getLayout()->getMainContentCssClass('col-xs-12 site-content'))?>">
                <div class="site-content-inner">

                    <?php do_action( 'oasis/action/before_render_main_inner' );?>

                    <div class="page-content">
                        <div class="single-post-content single-portfolio-content clearfix">
                            <?php

                            do_action( 'oasis/action/before_render_main_content' );

                            if( have_posts() ):  the_post(); ?>
                                <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

                                    <?php if($portfolio_single_style == 'use_vc'): ?>

                                        <?php the_content(); ?>

                                    <?php else: ?>
                                        <?php
                                        $client_name = Oasis_Helper::getPostMeta(get_the_ID(), OASIS_OPTION, 'portfolio_client');
                                        $portfolio_gallery = Oasis_Helper::getPostMeta(get_the_ID(), OASIS_OPTION, 'portfolio_gallery');
                                        ?>
                                        <?php if(!empty($portfolio_gallery)):?>
                                            <div class="block-single-portfolio-gallery"><?php echo do_shortcode('[la_block id="'.esc_attr($portfolio_gallery).'"]')?></div>
                                        <?php endif; ?>
                                        <div class="clearfix"></div>
                                        <header class="entry-header text-center margin-bottom-35">
                                            <?php the_title( '<h2 class="entry-title">', '</h2>' );?>
                                        </header><!-- .entry-header -->
                                        <div class="single-portfolio-meta">
                                            <?php if(!empty($client_name)): ?>
                                                <div class="meta-item">
                                                    <div class="meta-label"><?php esc_html_e('Client:', 'oasis')?></div>
                                                    <div class="meta-value"><?php echo esc_html($client_name)?></div>
                                                </div>
                                            <?php endif; ?>
                                            <div class="meta-item">
                                                <div class="meta-label"><?php esc_html_e('Category:', 'oasis')?></div>
                                                <?php the_terms(get_the_ID(), 'la_portfolio_category', '<div class="meta-value">', ', ', '</div>');?>
                                            </div>
                                            <div class="meta-item">
                                                <div class="meta-label"><?php esc_html_e('Date:', 'oasis')?></div>
                                                <div class="meta-value"><?php the_date();?></div>
                                            </div>
                                        </div>
                                        <div class="entry-content">
                                            <?php the_content(); ?>
                                        </div><!-- .entry-content -->
                                    <?php endif; ?>

                                </article><!-- #post-## -->

                                <?php

                                the_post_navigation( array(
                                    'next_text' => '<span class="meta-nav" aria-hidden="true">' . esc_html__( 'Next', 'oasis' ) . '</span> ' .
                                        '<span class="post-title">%title</span>',
                                    'prev_text' => '<span class="meta-nav" aria-hidden="true">' . esc_html__( 'Previous', 'oasis' ) . '</span> ' .
                                        '<span class="post-title">%title</span>',
                                ) );


                            endif;

                            do_action( 'oasis/action/after_render_main_content' );

                            ?>
                        </div>
                    </div>

                    <?php do_action( 'oasis/action/after_render_main_inner' );?>
                </div>
            </main>
            <!-- #site-content -->
            <?php get_sidebar();?>
        </div>
    </div>
</div>
<!-- .site-main -->
<?php do_action( 'oasis/action/after_render_main' ); ?>
<?php get_footer();?>