<?php
add_action( 'tgmpa_register', 'oasis_register_required_plugins' );

if(!function_exists('oasis_register_required_plugins')){

	function oasis_register_required_plugins() {

		$plugins = array(

			array(
				'name'					=> esc_html__('LA Studio Core','oasis'),
				'slug'					=> 'la-studio-core',
				'source'				=> get_template_directory() . '/plugins/la-studio-core.zip',
				'required'				=> true,
				'version'				=> '1.0.5'
			),

			array(
				'name'					=> esc_html__('Oasis Package Demo Data','oasis'),
				'slug'					=> 'oasis-demo-data',
				'source'				=> 'https://github.com/la-studioweb/oasis/raw/master/oasis-demo-data.zip',
				'required'				=> true,
				'version'				=> '1.2'
			),

			array(
				'name'     				=> esc_html__('Envato Market', 'oasis'),
				'slug'     				=> 'envato-market',
				'source'   				=> 'https://envato.github.io/wp-envato-market/dist/envato-market.zip',
				'required' 				=> false,
				'version' 				=> '2.0.0'
			),

			array(
				'name'					=> esc_html__('WPBakery Visual Composer','oasis'),
				'slug'					=> 'js_composer',
				'source'				=> get_template_directory() . '/plugins/js_composer.zip',
				'required'				=> true,
				'version'				=> '5.6'
			),

			array(
				'name'					=> esc_html__('Slider Revolution','oasis'),
				'slug'					=> 'revslider',
				'source'				=> get_template_directory() . '/plugins/revslider.zip',
				'required'				=> true,
				'version'				=> '5.4.8.1'
			),
			

			array(
				'name'     				=> esc_html__('WooCommerce','oasis'),
				'slug'     				=> 'woocommerce',
				'required' 				=> false,
				'version' 				=> '3.5.2'
			),

			array(
				'name'     				=> esc_html__('YITH WooCommerce Wishlist','oasis'),
				'slug'     				=> 'yith-woocommerce-wishlist',
				'required' 				=> false
			),

			array(
				'name'     				=> esc_html__('Regenerate Thumbnails','oasis'),
				'slug'     				=> 'regenerate-thumbnails',
				'required' 				=> false
			),
			array(
				'name' 					=> esc_html__('Contact Form 7', 'oasis'),
				'slug' 					=> 'contact-form-7',
				'required' 				=> false
			),
			array(
				'name' 					=> esc_html__('Instagram Slider Widget', 'oasis'),
				'slug' 					=> 'instagram-slider-widget',
				'source'   				=> 'https://downloads.wordpress.org/plugin/instagram-slider-widget.zip',
				'required' 				=> false
			)
		);

		$config = array(
			'id'           				=> 'oasis',
			'default_path' 				=> '',
			'menu'         				=> 'tgmpa-install-plugins',
			'has_notices'  				=> true,
			'dismissable'  				=> true,
			'dismiss_msg'  				=> '',
			'is_automatic' 				=> false,
			'message'      				=> ''
		);

		tgmpa( $plugins, $config );

	}

}