<footer id="colophon" class="site-footer">
    <div class="footer-top">
        <div class="container">
            <div class="row">
                <?php if(is_active_sidebar('footer-area-2')){
                    dynamic_sidebar('footer-area-2');
                }?>
            </div>
        </div>
    </div>
    <div class="footer-bottom">
        <div class="container">
            <div class="footer-bottom-inner">
                <?php echo Oasis_Helper::getOption('footer_copyright_text');?>
            </div>
        </div>
    </div>
</footer>
<!-- #colophon -->