<footer id="colophon" class="site-footer">
    <?php if(has_nav_menu('footer-nav')): ?>
    <div class="footer-nav">
        <div class="container">
            <div class="row">
                <div class="col-xs-12"><?php
                    wp_nav_menu(array(
                        'theme_location' => 'footer-nav',
                        'depth'  => 1,
                        'container' => false
                    ))
                    ?></div>
            </div>
        </div>
    </div>
    <?php endif; ?>
    <div class="footer-top">
        <div class="container">
            <div class="row">
                <?php if(is_active_sidebar('footer-area-1')){
                    dynamic_sidebar('footer-area-1');
                }?>
            </div>
        </div>
    </div>
</footer>
<!-- #colophon -->