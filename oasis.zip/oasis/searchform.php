<form method="get" class="search-form" action="<?php echo esc_url( home_url( '/'  ) ); ?>">
	<input type="search" class="search-field" placeholder="<?php echo esc_attr_x( 'Search here&hellip;', 'placeholder', 'oasis' ); ?>" name="s" title="<?php echo esc_attr_x( 'Search for:', 'label', 'oasis' ); ?>" />
	<button class="search-button" type="submit"><i class="la-icon-zoom"></i></button>
</form>
<!-- .search-form -->