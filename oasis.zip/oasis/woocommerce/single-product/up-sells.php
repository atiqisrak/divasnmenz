<?php
/**
 * Single Product Up-Sells
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product/up-sells.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see 	    https://docs.woocommerce.com/document/template-structure/
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     3.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( $upsells ) : ?>
<?php

$product_cols = Oasis_Helper::getOption('upsell_product_columns');
switch($product_cols){
    case 2:
        $columns = array('lg'=> 2,'md'=> 2,'sm'=> 1,'xs'=> 1);
        break;

    case 3:
        $columns = array('lg'=> 3,'md'=> 3,'sm'=> 2,'xs'=> 1);
        break;

    case 4:
        $columns = array('lg'=> 4,'md'=> 4,'sm'=> 2,'xs'=> 1);
        break;

    case 5:
        $columns = array('lg'=> 5,'md'=> 4,'sm'=> 2,'xs'=> 1);
        break;

    case 6:
        $columns = array('lg'=> 6,'md'=> 5,'sm'=> 2,'xs'=> 1);
        break;

    default:
        $columns = array('lg'=> 1,'md'=> 1,'sm'=> 1,'xs'=> 1);
}

$loopCssClass = array('products','grid-items', 'la-slick-slider');
$slide_configs = array(
    'infinite' => false,
    'dots' => false,
    'slidesToShow' => absint($columns['lg']),
    'slidesToScroll' => 1,
    'autoplay' => false,
    'arrows' => true,
    'speed' => 1000,
    'autoplaySpeed' => 3000,
    'responsive' => array(
        array(
            'breakpoint' => 1024,
            'settings' => array(
                'slidesToShow' => absint($columns['md'])
            )
        ),
        array(
            'breakpoint' => 992,
            'settings' => array(
                'slidesToShow' => absint($columns['sm'])
            )
        ),
        array(
            'breakpoint' => 768,
            'settings' => array(
                'slidesToShow' => absint($columns['xs'])
            )
        )
    )
);
$slide_configs = json_encode($slide_configs);
?>
<div class="up-sells upsells up-sells-product">
    <div class="row">
        <div class="col-xs-12">
            <h3 class="heading--title text-center text-uppercase"><?php esc_html_e( 'You may also like&hellip;', 'oasis' ) ?></h3>
        </div>
    </div>
    <div class="row">
        <div class="col-xs-12">
            <ul class="<?php echo esc_attr(implode(' ', $loopCssClass)) ?>" data-slider_config="<?php echo esc_attr($slide_configs)?>">

                <?php foreach ( $upsells as $upsell ) : ?>

                    <?php
                    $post_object = get_post( $upsell->get_id() );

                    setup_postdata( $GLOBALS['post'] =& $post_object );

                    wc_get_template_part( 'content', 'product' ); ?>

                <?php endforeach; ?>

            </ul>
        </div>
	</div>
</div>
<?php endif;
wp_reset_postdata();
