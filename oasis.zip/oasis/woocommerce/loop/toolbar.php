<?php
$show_breadcrumbs = apply_filters('oasis/filter/show_breadcrumbs', true);
$view_mode = Oasis_Helper::getOption('catalog_display_type', 'grid');
if(is_product_taxonomy()){
    if($custom_settings = Oasis_Helper::getTermMeta(get_queried_object_id(), OASIS_OPTION, 'product_cat_custom_setting')){
        $view_mode = Oasis_Helper::getTermMeta(get_queried_object_id(), OASIS_OPTION, 'catalog_display_type');
    }
}
$view_mode = apply_filters('oasis/filter/catalog_view_mode', $view_mode);

$per_page_array = apply_filters('oasis/filter/product_per_page_array', Oasis_Helper::getOption('product_per_page_grid', '9,15,30'));
$per_page = apply_filters('oasis/filter/product_per_page', Oasis_Helper::getOption('product_per_page_default_grid', 9));
$per_page_array = explode(',', $per_page_array);
$per_page_array = array_map('trim', $per_page_array);
$per_page_array = array_map('absint', $per_page_array);
asort($per_page_array);
$current_url = add_query_arg(null, null);
$current_url = remove_query_arg(array('page', 'paged', 'mode_view'), $current_url);
$current_url = preg_replace('/\/page\/\d+/', '', $current_url);
?>
<div class="wc-toolbar-container">
    <div class="container">
        <div class="wc-toolbar wc-toolbar-top clearfix">
            <?php if(!$show_breadcrumbs){
                Oasis()->getLayout()->getBreadcrumbs();
            } ?>
            <?php if(!is_product()): ?>
            <div class="shop-filter-toggle">
                <i class="la-icon-search"></i><span><?php esc_html_e('Product Filter', 'oasis'); ?></span>
            </div>
            <div class="wc-toolbar-left">
                <?php woocommerce_catalog_ordering();?>
            </div>
            <div class="wc-toolbar-right">
                <?php woocommerce_result_count();?>
                <div class="wc-view-count">
                    <p><?php esc_html_e('Show', 'oasis'); ?></p>
                    <ul><?php
                        foreach ($per_page_array as $val){?><li
                            <?php echo ($per_page == $val ? ' class="active"' : '')?>><a href="<?php echo esc_url(add_query_arg('per_page', $val, $current_url)); ?>"><?php echo sprintf( esc_html__( '%s' , 'oasis'), $val ) ?></a></li>
                        <?php }
                        ?></ul>
                </div>
                <div class="wc-view-toggle">
                <span data-view_mode="grid"<?php
                if ($view_mode == 'grid') {
                    echo ' class="active"';
                }
                ?>><i title="<?php esc_attr_e('Grid view', 'oasis') ?>" class="la-icon-grid"></i></span>
                <span data-view_mode="list"<?php
                if ($view_mode == 'list') {
                    echo ' class="active"';
                }
                ?>><i title="<?php esc_attr_e('List view', 'oasis') ?>" class="la-icon-list"></i></span>
                </div>
            </div>
            <?php endif; ?>
        </div><!-- .wc-toolbar -->
    </div>
</div>

<?php if(is_woocommerce() && !is_product()){
    $layout = Oasis()->getLayout()->getSiteLayout();
    if($layout == 'col-1c' && is_active_sidebar('sidebar-shop-primary')){
        ?>
        <div class="sidebar-product-filters">
            <div class="sidebar-inner">
                <?php dynamic_sidebar('sidebar-shop-primary');?>
            </div>
        </div>
<?php
    }
}