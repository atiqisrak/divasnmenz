<?php
/**
 * The template for displaying product content in the single-product.php template
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/content-single-product.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce/Templates
 * @version 3.4.0
 */

defined( 'ABSPATH' ) || exit;

?>
<?php
$product_design = Oasis_Helper::getOptionByMetadata('product_single_style', Oasis_Helper::getOption('product_single_style', '1'));
if($product_design == 3){
	remove_action('woocommerce_before_single_product', 'wc_print_notices', 10);
}
?>
<?php
	/**
	 * woocommerce_before_single_product hook.
	 *
	 * @hooked wc_print_notices - 10
	 */
	 do_action( 'woocommerce_before_single_product' );

	 if ( post_password_required() ) {
	 	echo get_the_password_form();
	 	return;
	 }
?>

<div id="product-<?php the_ID(); ?>" <?php post_class(); ?>>

	<?php if($product_design == 3): ?>

		<div data-vc-full-width="true" data-vc-full-width-init="false" data-vc-stretch-content="true" class="row_product_images vc_row wpb_row vc_row-fluid">
			<div class="wpb_column vc_column_container vc_col-sm-12">
				<div class="vc_column-inner">
					<div class="wpb_wrapper">
						<div class="container">
							<div class="row"><div class="col-xs-12"><?php
								echo wc_print_notices();
								?></div></div>
							<div class="row_product_images2">
								<div class="col-xs-12 col-sm-6 product-main-image">
									<div class="p---large position-relative images">
										<?php
										/**
										 * woocommerce_before_single_product_summary hook.
										 *
										 * @hooked woocommerce_show_product_sale_flash - 10
										 * @hooked woocommerce_show_product_images - 20
										 */
										do_action( 'woocommerce_before_single_product_summary' );
										?>
									</div>
									<?php
									if(Oasis_Helper::getOption('show_product_thumbnails')){
										do_action( 'woocommerce_product_thumbnails' );
									}
									?>
								</div><!-- .product--images -->
								<div class="col-xs-12 col-sm-6 col-lg-5 col-lg-offset-1 product--summary">
									<div class="summary entry-summary">

										<?php
										/**
										 * woocommerce_single_product_summary hook.
										 *
										 * @hooked woocommerce_template_single_title - 5
										 * @hooked woocommerce_template_single_rating - 10
										 * @hooked woocommerce_template_single_price - 10
										 * @hooked woocommerce_template_single_meta - 10
										 * @hooked woocommerce_template_single_excerpt - 20
										 * @hooked woocommerce_template_single_add_to_cart - 30
										 * @hooked woocommerce_template_single_sharing - 50
										 */
										do_action( 'woocommerce_single_product_summary' );
										?>

									</div>
								</div><!-- .product-summary -->
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="vc_row-full-width vc_clearfix"></div>
		<div class="row design-03-row-02">
			<div class="col-xs-12 col-md-6"><?php woocommerce_template_single_meta(); ?></div>
			<div class="col-xs-12 col-md-6"><?php woocommerce_template_single_sharing(); ?></div>
		</div>
		<div class="row design-03-row-03">
			<div class="col-xs-12"><?php woocommerce_product_description_tab();?></div>
		</div>
		<div class="row design-03-row-04">
			<div class="col-xs-12"><?php woocommerce_product_additional_information_tab();?></div>
		</div>
	<?php else: ?>
		<div class="row">
			<div class="col-xs-12 col-sm-6 product-main-image">
				<div class="p---large position-relative images">
					<?php
					/**
					 * woocommerce_before_single_product_summary hook.
					 *
					 * @hooked woocommerce_show_product_sale_flash - 10
					 * @hooked woocommerce_show_product_images - 20
					 */
					do_action( 'woocommerce_before_single_product_summary' );
					?>
				</div>
				<?php
				if(Oasis_Helper::getOption('show_product_thumbnails')){
					do_action( 'woocommerce_product_thumbnails' );
				}
				?>
			</div><!-- .product--images -->
			<div class="col-xs-12 col-sm-6 col-lg-5 col-lg-offset-1 product--summary">
				<div class="summary entry-summary">

					<?php
					/**
					 * woocommerce_single_product_summary hook.
					 *
					 * @hooked woocommerce_template_single_title - 5
					 * @hooked woocommerce_template_single_rating - 10
					 * @hooked woocommerce_template_single_price - 10
					 * @hooked woocommerce_template_single_meta - 10
					 * @hooked woocommerce_template_single_excerpt - 20
					 * @hooked woocommerce_template_single_add_to_cart - 30
					 * @hooked woocommerce_template_single_sharing - 50
					 * @hooked WC_Structured_Data::generate_product_data() - 60
					 */
					do_action( 'woocommerce_single_product_summary' );
					?>

				</div>
			</div><!-- .product-summary -->
		</div>
	<?php endif; ?>


	<div class="row">
		<div class="col-xs-12">
			<?php
			/**
			 * woocommerce_after_single_product_summary hook.
			 *
			 * @hooked woocommerce_output_product_data_tabs - 10
			 * @hooked woocommerce_upsell_display - 15
			 * @hooked woocommerce_output_related_products - 20
			 */
			do_action( 'woocommerce_after_single_product_summary' );
			?>
		</div>
	</div>

</div><!-- #product-<?php the_ID(); ?> -->

<?php do_action( 'woocommerce_after_single_product' ); ?>
