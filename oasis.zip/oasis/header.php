<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <!--[if IE]>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>
    <![endif]-->
    <link rel="profile" href="http://gmpg.org/xfn/11">
    <link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>

<?php do_action('oasis/action/before_render_body'); ?>
<?php
$show_custom_header_top = Oasis_Helper::getOption('show_custom_header_top');
$custom_header_text = Oasis_Helper::getOption('custom_header_top_text');
if($show_custom_header_top && !empty($custom_header_text)) :
?>
<div class="custom-header-top-text">
    <div class="header-top-text-inner"><div class="container"><?php echo balanceTags( $custom_header_text ); ?></div></div>
</div>
<?php endif; ?>

<div id="page" class="site">
    <div class="site-inner"><?php

Oasis()->getLayout()->renderHeaderTpl();

Oasis()->getLayout()->renderHeaderMobileTpl();

Oasis()->getLayout()->renderPageHeaderTpl();


