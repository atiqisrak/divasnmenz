<div class="clearfix">
    <div class="container backtotop-container">
        <a href="#page" class="btn-backtotop"><span class="fa-angle-up"></span><span><?php esc_html_e('Back to top', 'oasis'); ?></span></a>
    </div>
</div>
<?php
    Oasis()->getLayout()->renderFooterTpl();
?>
    </div><!-- .site-inner -->
</div><!-- #page-->

<div class="la-overlay-global"></div>

<?php
$show_popup = Oasis_Helper::getOption('enable_newsletter_popup');
$only_home_page = Oasis_Helper::getOption('only_show_newsletter_popup_on_home_page');
$delay = Oasis_Helper::getOption('newsletter_popup_delay', 2000);
$popup_content = Oasis_Helper::getOption('newsletter_popup_content');
$show_checkbox = Oasis_Helper::getOption('show_checkbox_hide_newsletter_popup', false);
$back_display_time = Oasis_Helper::getOption('newsletter_popup_show_again', '1');
if($show_popup){
    if($only_home_page && !is_front_page()){
        $show_popup = false;
    }
}
if($show_popup && !empty($popup_content)):
?>
<div class="la-newsletter-popup-outer">
<div class="la-newsletter-popup" data-back-time="<?php echo esc_attr( floatval($back_display_time) ); ?>" data-show-mobile="<?php echo Oasis_Helper::getOption('disable_popup_on_mobile') ? 1 : 0 ?>" id="la_newsletter_popup" data-delay="<?php echo esc_attr( absint($delay) ); ?>">
    <button class="btn-close-newsletter-popup active menu-toggle-icon"><span class="menu-line-1"></span><span class="menu-line-2"></span><span class="menu-line-3"></span></button>
    <div class="newsletter-popup-content"><?php echo Oasis_Helper::removeJsWpAutop($popup_content, true); ?></div>
    <?php if($show_checkbox): ?>
    <label><input type="checkbox" id="dont_show_popup"/><?php esc_html_e("Don't show popup anymore", 'oasis') ?></label>
    <?php endif;?>
</div>
</div>
<?php endif; ?>
<?php
do_action('oasis/action/after_render_body');
wp_footer();
?>
</body>
</html>