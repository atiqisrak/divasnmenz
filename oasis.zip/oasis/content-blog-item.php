<?php
global $oasis_loop;
$blog_style         = isset($oasis_loop['blog_style']) ? $oasis_loop['blog_style'] : 'grid-3col';
$show_postformat    = isset($oasis_loop['blog_show_postformat']) ? $oasis_loop['blog_show_postformat'] : false;
$thumbnail_size     = (isset($oasis_loop['image_size']) && !empty($oasis_loop['image_size']) ? $oasis_loop['image_size'] : 'thumbnail');
$title_tag          = (isset($oasis_loop['title_tag']) && !empty($oasis_loop['title_tag']) ? $oasis_loop['title_tag'] : 'h2');
$post_class         = array('loop-item','grid-item','post-item');

$format_type        = get_post_format();

?>
<article <?php post_class($post_class); ?>>
    <div class="item-inner">

        <?php if($blog_style == 'list-1col'): ?>

            <?php if(has_post_thumbnail()): ?>
                <div class="post-left">
                    <?php do_action('oasis/before_resize_image'); ?>
                    <?php oasis_loop_post_thumbnail( $thumbnail_size, false); ?>
                    <?php do_action('oasis/after_resize_image'); ?>
                </div>
            <?php endif; ?>
            <div class="post-right">
                <div class="entry-meta"><div class="post-date"><?php echo get_the_date('d M, Y'); ?></div></div><!-- .entry-meta -->
                <header class="entry-header">
                    <?php the_title( sprintf( '<%s class="entry-title"><a href="%s">',$title_tag, esc_url( get_the_permalink() ) ), sprintf('</a></%s>', $title_tag) ); ?>
                </header><!-- .entry-header -->
                <div class="entry-excerpt"><?php the_excerpt();?></div><!-- .entry-content -->
                <footer>
                    <a class="link-readmore" href="<?php the_permalink();?>"><?php esc_html_e('Read More', 'oasis'); ?></a>
                </footer>
            </div>

        <?php else: ?>
            <?php do_action('oasis/before_resize_image'); ?>
            <?php oasis_loop_post_thumbnail( $thumbnail_size, $show_postformat); ?>
            <?php do_action('oasis/after_resize_image'); ?>

            <div class="entry-meta"><div class="post-date"><?php echo get_the_date('d M, Y'); ?></div></div><!-- .entry-meta -->

            <header class="entry-header">
                <?php the_title( sprintf( '<%s class="entry-title"><a href="%s">',$title_tag, esc_url( get_the_permalink() ) ), sprintf('</a></%s>', $title_tag) ); ?>
            </header><!-- .entry-header -->

            <div class="entry-excerpt"><?php the_excerpt();?></div><!-- .entry-content -->

        <?php endif; ?>
    </div>
</article>
