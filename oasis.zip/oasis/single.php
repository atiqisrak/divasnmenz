<?php get_header(); ?>
<?php do_action( 'oasis/action/before_render_main' ); ?>
<div id="main" class="site-main">
    <div class="container">
        <div class="row">
            <main id="site-content" class="<?php echo esc_attr(Oasis()->getLayout()->getMainContentCssClass('col-xs-12 site-content'))?>">
                <div class="site-content-inner">

                    <?php do_action( 'oasis/action/before_render_main_inner' );?>

                    <div class="page-content">
                        <div class="single-post-content clearfix">
                            <?php

                            do_action( 'oasis/action/before_render_main_content' );

                            if( have_posts() ):  the_post(); ?>

                                <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

                                    <?php oasis_single_post_thumbnail(); ?>

                                    <header class="entry-header">
                                        <?php
                                            the_title( '<h1 class="entry-title h3">', '</h1>' );
                                        ?>
                                    </header><!-- .entry-header -->

                                    <div class="entry-meta"><?php oasis_entry_meta(true,true,false);?></div><!-- .entry-meta -->

                                    <div class="entry-content">
                                        <?php

                                        the_content( sprintf(
                                            esc_html__( 'Continue reading %s', 'oasis' ),
                                            the_title( '<span class="screen-reader-text">', '</span>', false )
                                        ) );

                                        wp_link_pages( array(
                                            'before'      => '<div class="page-links"><span class="page-links-title">' . esc_html__( 'Pages:', 'oasis' ) . '</span>',
                                            'after'       => '</div>',
                                            'link_before' => '<span>',
                                            'link_after'  => '</span>',
                                            'pagelink'    => '<span class="screen-reader-text">' . esc_html__( 'Page', 'oasis' ) . ' </span>%',
                                            'separator'   => '<span class="screen-reader-text">, </span>',
                                        ) );
                                        ?>
                                    </div><!-- .entry-content -->

                                    <?php the_tags('<span class="tags-list clearfix"><i class="fa fa-tags"></i>',', ','</span><!-- .tags-list -->') ;?>

                                    <footer class="entry-footer clearfix">
                                        <?php
                                        if(Oasis_Helper::getOption('single_post_show_author_info')){
                                            // Author bio.
                                            if ( get_the_author_meta( 'description' ) ) :
                                                get_template_part( 'author-bio' );
                                            endif;
                                        }
                                        if(Oasis_Helper::getOption('single_post_show_share_link')) {
                                            oasis_social_sharing();
                                        }
                                        ?>

                                        <?php edit_post_link( esc_html__( 'Edit', 'oasis' ), '<div class="clearfix"></div><span class="edit-link">', '</span>' ); ?>
                                    </footer><!-- .entry-footer -->

                                </article><!-- #post-## -->

                            <?php

                                the_post_navigation( array(
                                    'next_text' => '<span class="meta-nav highlight-font-family three-text-color" aria-hidden="true">' . esc_html__( 'Next Post', 'oasis' ) . '</span> ' .
                                        '<span class="post-title">%title</span>',
                                    'prev_text' => '<span class="meta-nav highlight-font-family three-text-color" aria-hidden="true">' . esc_html__( 'Previous Post', 'oasis' ) . '</span> ' .
                                        '<span class="post-title">%title</span>',
                                ) );

                                if(Oasis_Helper::getOption('single_post_show_comment')){
                                    if ( comments_open() || get_comments_number() ) :
                                        comments_template();
                                    endif;
                                }

                            endif;

                            do_action( 'oasis/action/after_render_main_content' );

                            ?>
                        </div>
                    </div>

                    <?php do_action( 'oasis/action/after_render_main_inner' );?>
                </div>
            </main>
            <!-- #site-content -->
            <?php get_sidebar();?>
        </div>
    </div>
</div>
<!-- .site-main -->
<?php do_action( 'oasis/action/after_render_main' ); ?>
<?php get_footer();?>
