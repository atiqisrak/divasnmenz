<?php if ( ! defined( 'ABSPATH' ) ) { die; }

$post_metaboxes = $tax_metaboxes = array();

$post_metaboxes[]    = array(
    'id'        => OASIS_OPTION,
    'title'     => esc_html__('Meta Options', 'oasis'),
    'post_type' => 'page',
    'context'   => 'normal',
    'priority'  => 'default',
    'sections'  => array(
        /**
         * View Options
         */
        array(
            'name'  => 'view',
            'title' => esc_html__('View Options', 'oasis'),
            'icon'  => 'fa fa-cog',
            'fields' => Oasis_Option_Config::getViewMetaBox()
        ),
        /**
         * Skin Options
         */
        array(
            'name'  => 'skin',
            'title' => esc_html__('Skin Options', 'oasis'),
            'icon'  => 'fa fa-tint',
            'fields' => Oasis_Option_Config::getSkinMetaBox()
        )
    ),
);

$post_metaboxes[]    = array(
    'id'        => OASIS_OPTION,
    'title'     => esc_html__('Meta Options', 'oasis'),
    'post_type' => 'post',
    'context'   => 'normal',
    'priority'  => 'default',
    'sections'  => array(
        /**
         * Post format options
         */
        array(
            'name'  => 'format_option',
            'title' => esc_html__('Post Format Options', 'oasis'),
            'icon'  => 'fa fa-cogs',
            'fields' => array(
                array(
                    'id'    => 'post_format_quote',
                    'type'  => 'wysiwyg',
                    'title' => esc_html__('Quote', 'oasis'),
                    'wrap_class' => 'post_format_quote'
                ),
                array(
                    'id'    => 'post_format_video',
                    'type'  => 'textarea',
                    'title' => esc_html__('Video', 'oasis'),
                    'desc'  => esc_html__('Video URL (oEmbed) or Embed Code', 'oasis'),
                    'wrap_class' => 'post_format_video'
                ),
                array(
                    'id'    => 'post_format_link',
                    'type'  => 'text',
                    'title' => esc_html__('Link URL', 'oasis'),
                    'wrap_class' => 'post_format_link'
                ),
                array(
                    'id'    => 'post_format_audio',
                    'type'  => 'textarea',
                    'title' => esc_html__('Audio', 'oasis'),
                    'desc'  => esc_html__('Audio URL (oEmbed) or Embed Code', 'oasis'),
                    'wrap_class' => 'post_format_audio'
                ),
                array(
                    'id'    => 'post_format_gallery',
                    'type'  => 'gallery',
                    'title' => esc_html__('Gallery Images', 'oasis'),
                    'wrap_class' => 'post_format_gallery'
                ),
            )
        ),
        /**
         * View Options
         */
        array(
            'name'  => 'view',
            'title' => esc_html__('View Options', 'oasis'),
            'icon'  => 'fa fa-cog',
            'fields' => Oasis_Option_Config::getViewMetaBox()
        ),
        /**
         * Skin Options
         */
        array(
            'name'  => 'skin',
            'title' => esc_html__('Skin Options', 'oasis'),
            'icon'  => 'fa fa-tint',
            'fields' => Oasis_Option_Config::getSkinMetaBox()
        )
    ),
);

$post_metaboxes[]    = array(
    'id'        => OASIS_OPTION,
    'title'     => esc_html__('Testimonial Information', 'oasis'),
    'post_type' => 'la_testimonial',
    'context'   => 'normal',
    'priority'  => 'default',
    'sections'  => array(
        array(
            'name'  => 'testimonial_info',
            'fields' => array(
                array(
                    'id'    => 'role',
                    'type'  => 'text',
                    'title' => esc_html__('Role', 'oasis'),
                )
            )
        ),
    )
);

$post_metaboxes[]    = array(
    'id'        => OASIS_OPTION,
    'title'     => esc_html__('Member Information', 'oasis'),
    'post_type' => 'la_team_member',
    'context'   => 'normal',
    'priority'  => 'default',
    'sections'  => array(
        array(
            'name'  => 'member_info',
            'fields' => array(
                array(
                    'id'    => 'role',
                    'type'  => 'text',
                    'title' => esc_html__('Role', 'oasis'),
                ),
                array(
                    'id'    => 'email',
                    'type'  => 'text',
                    'title' => esc_html__('Email Address', 'oasis'),
                ),
                array(
                    'id'    => 'facebook',
                    'type'  => 'text',
                    'title' => esc_html__('Facebook URL', 'oasis'),
                ),
                array(
                    'id'    => 'twitter',
                    'type'  => 'text',
                    'title' => esc_html__('Twitter URL', 'oasis'),
                ),
                array(
                    'id'    => 'pinterest',
                    'type'  => 'text',
                    'title' => esc_html__('Pinterest URL', 'oasis'),
                ),
                array(
                    'id'    => 'dribbble',
                    'type'  => 'text',
                    'title' => esc_html__('Dribbble URL', 'oasis'),
                ),
                array(
                    'id'    => 'gplus',
                    'type'  => 'text',
                    'title' => esc_html__('Google Plus URL', 'oasis'),
                )
            )
        ),
    )
);
$post_metaboxes[]    = array(
    'id'        => OASIS_OPTION,
    'title'     => esc_html__('Meta Options', 'oasis'),
    'post_type' => 'la_portfolio',
    'context'   => 'normal',
    'priority'  => 'high',
    'sections'  => array(
        /**
         * Portfolio Options
         */
        array(
            'name'  => 'portfolio_view',
            'title' => esc_html__('Portfolio Options', 'oasis'),
            'icon'  => 'fa fa-cog',
            'fields' => array(
                array(
                    'id'    => 'portfolio_client',
                    'type'  => 'text',
                    'title' => esc_html__('Client Name', 'oasis'),
                ),
                array(
                    'id'    => 'portfolio_gallery',
                    'type'  => 'select',
                    'title' => esc_html__('Gallery Block', 'oasis'),
                    'options'   => 'posts',
                    'query_args'    => array(
                        'post_type'    => 'la_block',
                        'orderby'      => 'post_date',
                        'order'        => 'DESC',
                        'posts_per_page' => -1
                    ),
                    'default_option' => esc_html__('Select a gallery','oasis'),
                ),
                array(
                    'id'             => 'single_portfolio_style',
                    'type'           => 'radio',
                    'title'          => esc_html__('Select Design', 'oasis'),
                    'options'        => array(
                        'inherit'   => esc_html__('Inherit', 'oasis'),
                        'use_vc'    => esc_html__('Use Visual composer', 'oasis')
                    ),
                    'default' => 'inherit',
                ),
            )
        ),
        /**
         * View Options
         */
        array(
            'name'  => 'view',
            'title' => esc_html__('View Options', 'oasis'),
            'icon'  => 'fa fa-cog',
            'fields' => Oasis_Option_Config::getViewMetaBox()
        ),
        /**
         * Skin Options
         */
        array(
            'name'  => 'skin',
            'title' => esc_html__('Skin Options', 'oasis'),
            'icon'  => 'fa fa-tint',
            'fields' => Oasis_Option_Config::getSkinMetaBox()
        )
    ),
);

$post_metaboxes[]    = array(
    'id'        => OASIS_OPTION,
    'title'     => esc_html__('Meta Options', 'oasis'),
    'post_type' => 'product',
    'context'   => 'normal',
    'priority'  => 'default',
    'sections'  => array(
        /**
         * View Options
         */
        array(
            'name'  => 'view',
            'title' => esc_html__('View Options', 'oasis'),
            'icon'  => 'fa fa-cog',
            'fields' => array_merge(array(
                array(
                    'id' => 'product_single_style',
                    'type' => 'select',
                    'title' => esc_html__('Select Design', 'oasis'),
                    'options' => array(
                        'inherit'	=> esc_html__('Inherit', 'oasis'),
                        '1'			=> esc_html__('Style 01', 'oasis'),
                        '2'			=> esc_html__('Style 02', 'oasis'),
                        '3'			=> esc_html__('Style 03', 'oasis'),
                        '4'			=> esc_html__('Style 04', 'oasis'),
                        '5'			=> esc_html__('Style 05', 'oasis')
                    ),
                    'default' => 'inherit',
                ),
            ),Oasis_Option_Config::getViewMetaBox(false))
        ),
        /**
         * Skin Options
         */
        array(
            'name'  => 'skin',
            'title' => esc_html__('Skin Options', 'oasis'),
            'icon'  => 'fa fa-tint',
            'fields' => Oasis_Option_Config::getSkinMetaBox()
        )
    ),
);



$tax_metaboxes[]    = array(
    'id'        => OASIS_OPTION,
    'taxonomy'  => 'category',
    'fields' 	=> Oasis_Option_Config::getViewMetaBox()
);

$tax_metaboxes[]    = array(
    'id'        => OASIS_OPTION,
    'taxonomy'  => 'product_tag',
    'fields' 	=> Oasis_Option_Config::getViewMetaBox()
);

$tax_metaboxes[]    = array(
    'id'        => OASIS_OPTION,
    'taxonomy'  => 'product_cat',
    'fields' 	=> array_merge(array(
        array(
            'id'    => 'product_cat_custom_setting',
            'type'  => 'switcher',
            'title' => esc_html__('Override Shop Settings ?', 'oasis'),
            'default' => false,
        ),

        array(
            'id'       => 'catalog_display_type',
            'type'     => 'select',
            'title'    => esc_html__('Catalog Display Type', 'oasis'),
            'options'  => array(
                'grid'  	=> esc_html__('Grid', 'oasis'),
                'list'  	=> esc_html__('List', 'oasis')
            ),
            'default'  => 'grid',
            'dependency'   => array( 'product_cat_custom_setting', '==', 'true' ),
        ),

        array(
            'id'        => 'column_per_row',
            'type'      => 'la_column_responsive',
            'title'     => esc_html__('Product Columns', 'oasis'),
            'default' => array(
                'xlg'	=> '3',
                'lg'	=> '3',
                'md'    => '2',
                'sm'	=> '2',
                'xs'    => '1',
            ),
            'after'     	=> '<p class="cs-text-desc">' . esc_html__('choose the select to set the number of products per row to be listed on the shop page and catalog pages.', 'oasis') . '</p>',
            'dependency'   	=> array( 'product_cat_custom_setting|catalog_display_type', '==|any', 'true|grid,grid2' ),
        )

    ), Oasis_Option_Config::getViewMetaBox() )
);

$tax_metaboxes[]    = array(
    'id'        => OASIS_OPTION,
    'taxonomy'  => 'portfolio_cat',
    'fields' 	=> Oasis_Option_Config::getViewMetaBox()
);

$tax_metaboxes[]    = array(
    'id'        => OASIS_OPTION,
    'taxonomy'  => 'portfolio_skill',
    'fields' 	=> Oasis_Option_Config::getViewMetaBox()
);

CSFramework_Metabox::instance( $post_metaboxes );
CSFramework_Taxonomy::instance( $tax_metaboxes );