<?php if ( ! defined( 'ABSPATH' ) ) { die; }

if(!class_exists('Oasis_Option_Config')){

    class Oasis_Option_Config{

		private static $instance = null;

		public static function instance() {
			if ( null === static::$instance ) {
				static::$instance = new static();
			}
			return static::$instance;
		}

		public function loadConfig(){
            if(!class_exists('CSFramework')) return;
			require get_template_directory() . '/framework/configs/theme-option.php';
			require get_template_directory() . '/framework/configs/metabox.php';
		}

		protected function __construct(){
			add_action('init', array( $this, 'loadConfig') );
		}

		public static function getAssetUri(){
			return get_template_directory_uri() . '/assets';
		}

		public static function radioOption( $inherit = true){
			$options = array();
			if($inherit){
				$options['inherit'] = esc_html__('Inherit', 'oasis');
			}
			$options['yes'] = esc_html__('Yes', 'oasis');
			$options['no'] = esc_html__('No', 'oasis');
			return $options;
		}

		public static function blockQueryArgs(){
			return array(
				'post_type'    => 'la_block',
				'orderby'      => 'post_date',
				'order'        => 'DESC',
				'posts_per_page' => -1
			);
		}

		public static function headerLayout($image_select = true, $inherit = false){
			$options = array(
				'1' => $image_select ? esc_url( self::getAssetUri() . '/images/theme_options/header-style-1.jpg') : esc_attr__('Layout 1','oasis'),
				'2' => $image_select ? esc_url( self::getAssetUri() . '/images/theme_options/header-style-2.jpg') : esc_attr__('Layout 2','oasis'),
				'3' => $image_select ? esc_url( self::getAssetUri() . '/images/theme_options/header-style-3.jpg') : esc_attr__('Layout 3','oasis'),
				'4' => $image_select ? esc_url( self::getAssetUri() . '/images/theme_options/header-style-4.jpg') : esc_attr__('Layout 4','oasis'),
				'5' => $image_select ? esc_url( self::getAssetUri() . '/images/theme_options/header-style-5.jpg') : esc_attr__('Layout 5','oasis'),
				'6' => $image_select ? esc_url( self::getAssetUri() . '/images/theme_options/header-style-6.jpg') : esc_attr__('Layout 6','oasis'),
				'7' => $image_select ? esc_url( self::getAssetUri() . '/images/theme_options/header-style-7.jpg') : esc_attr__('Layout 7','oasis')
			);
			if($inherit){
				$inherit = array(
					'inherit' => $image_select ? esc_url( self::getAssetUri() . '/images/theme_options/header-inherit.jpg') : esc_attr__('Inherit','oasis')
				);
				$options = $inherit + $options;
			}
			return $options;
		}

		public static function pageHeaderLayout($image_select = true, $inherit = false){
			$options = array(
				'1' => $image_select ? esc_url( self::getAssetUri() . '/images/theme_options/page-header-1.jpg') : esc_attr__('Title & Breadcrumbs left','oasis'),
				'2' => $image_select ? esc_url( self::getAssetUri() . '/images/theme_options/page-header-2.jpg') : esc_attr__('Title & Breadcrumbs center','oasis'),
				'3' => $image_select ? esc_url( self::getAssetUri() . '/images/theme_options/page-header-2.jpg') : esc_attr__('Title & Breadcrumbs right','oasis'),
				'4' => $image_select ? esc_url( self::getAssetUri() . '/images/theme_options/page-header-2.jpg') : esc_attr__('Title left & Breadcrumbs right','oasis'),
			);
			if($inherit){
				$inherit = array(
					'inherit' => $image_select ? esc_url( self::getAssetUri() . '/images/theme_options/page-header-inherit.jpg') : esc_attr__('Inherit','oasis'),
					'hide' => $image_select ? esc_url( self::getAssetUri() . '/images/theme_options/page-header-inherit.jpg') : esc_attr__('Hidden','oasis')
				);
				$options = $inherit + $options;
			}
			return $options;
		}

		public static function footerLayout($image_select = true, $inherit = false){
			$options = array(
				'1' => $image_select ? esc_url( self::getAssetUri() . '/images/theme_options/footer-1.jpg') : esc_attr__('Layout Simple','oasis'),
				'2' => $image_select ? esc_url( self::getAssetUri() . '/images/theme_options/footer-2.jpg') : esc_attr__('Layout 2','oasis'),
				'3' => $image_select ? esc_url( self::getAssetUri() . '/images/theme_options/footer-3.jpg') : esc_attr__('Layout 3','oasis'),
			);
			if($inherit){
				$inherit = array(
					'inherit' => $image_select ? esc_url( self::getAssetUri() . '/images/theme_options/footer-inherit.jpg') : esc_attr__('Inherit','oasis')
				);
				$options = $inherit + $options;
			}
			return $options;
		}

		public static function mainLayout($image_select = true, $inherit = false){
			$options =  array(
				'col-1c'    => $image_select ? esc_url( self::getAssetUri() . '/images/theme_options/col-1c.png')    : esc_attr__('1 column', 'oasis'),
				'col-2cl'   => $image_select ? esc_url( self::getAssetUri() . '/images/theme_options/col-2cl.png')   : esc_attr__('2 columns left (3-9)', 'oasis'),
				'col-2cr'   => $image_select ? esc_url( self::getAssetUri() . '/images/theme_options/col-2cr.png')   : esc_attr__('2 columns right (9-3)', 'oasis'),
				'col-2cl-l'   => $image_select ? esc_url( self::getAssetUri() . '/images/theme_options/col-2cl-l.png')   : esc_attr__('2 columns left (4-8)', 'oasis'),
				'col-2cr-l'   => $image_select ? esc_url( self::getAssetUri() . '/images/theme_options/col-2cr-l.png')   : esc_attr__('2 columns right (8-4)', 'oasis')
			);
			if($inherit){
				$inherit = array(
					'inherit' => $image_select ? esc_url( self::getAssetUri() . '/images/theme_options/inherit.png') : esc_attr__('Inherit','oasis')
				);
				$options = $inherit + $options;
			}
			return $options;
		}

		public static function bodyStyle($inherit = false){
			$options = array(
				'stretched' => esc_attr__('Stretched', 'oasis'),
				'boxed'     => esc_attr__('Boxed', 'oasis'),
			);
			if($inherit){
				$inherit = array(
					'inherit' => esc_attr__('Inherit','oasis')
				);
				$options = $inherit + $options;
			}
			return $options;
		}

		public static function getViewMetaBox($show_layout = true){
			$options = array();
			if($show_layout){
				$options[] = array(
					'id'        => 'layout',
					'type'      => 'image_select',
					'title'     => esc_html__('Layout', 'oasis'),
					'options'   => self::mainLayout(true,true),
					'default'   => 'inherit',
				);
			}
			$options[] = array(
				'id'    => 'main_full_width',
				'type'  => 'radio',
				'title' => esc_html__('Enable Main FullWidth', 'oasis'),
				'options' => self::radioOption(),
				'default' => 'inherit',
			);

			$options[] = array(
				'id'        => 'main_menu',
				'type'      => 'select',
				'title'     => esc_html__('Main Menu','oasis'),
				'class'     => 'chosen',
				'options'   => 'tags',
				'query_args'     => array(
					'orderby'      => 'name',
					'order'        => 'ASC',
					'taxonomies'=>  'nav_menu'
				),
				'default_option' => esc_html__('Select a Menu', 'oasis'),
			);

			$options[] = array(
				'id'        => 'hide_header',
				'type'      => 'switcher',
				'title'     => esc_html__('Hide header', 'oasis'),
			);

			$options[] = array(
				'id'        => 'header_layout',
				'type'      => 'select',
				'title'     => esc_html__('Header Layout', 'oasis'),
				'class'     => 'chosen',
				'options'   => self::headerLayout(false,true),
				'default'   => 'inherit',
				'dependency'   => array( 'hide_header', '!=', '1' ),
			);
			$options[] = array(
				'id'        => 'header_full_width',
				'type'      => 'radio',
				'title'     => esc_html__('Enable Header FullWidth', 'oasis'),
				'options' => self::radioOption(),
				'default' => 'inherit',
				'dependency'   => array( 'hide_header', '!=', '1' ),
			);
			$options[] = array(
				'id'        => 'header_transparency',
				'type'      => 'radio',
				'title'     => esc_html__('Enable Header Transparency', 'oasis'),
				'options' => self::radioOption(),
				'default' => 'inherit',
				'dependency'   => array( 'hide_header', '!=', '1' ),
			);


			$options[] = array(
				'id'        => 'page_header_layout',
				'type'      => 'select',
				'title'     => esc_html__('Page Header Layout', 'oasis'),
				'class'     => 'chosen',
				'options'   => self::pageHeaderLayout(false,true),
				'default'   => 'inherit',
			);
			$options[] = array(
				'id'        => 'hide_breadcrumb',
				'type'      => 'switcher',
				'title'     => esc_html__('Hide Breadcrumbs', 'oasis'),
				'dependency'   => array( 'page_header_layout', '!=', 'hide' )
			);

			$options[] = array(
				'id'        => 'hide_page_title',
				'type'      => 'switcher',
				'title'     => esc_html__('Hide Page Title', 'oasis'),
				'dependency'   => array( 'page_header_layout', '!=', 'hide' )
			);
			$options[] = array(
				'id'    => 'page_title_custom',
				'type'  => 'text',
				'title' => esc_html__('Custom Page Title','oasis'),
				'dependency'   => array( 'hide_page_title|page_header_layout', '==|!=', '|hide' ),
			);

			$options[] = array(
				'id'           => 'page_header_background',
				'type'         => 'background',
				'title'        => esc_html__('Page Header Background', 'oasis'),
				'dependency'   => array( 'page_header_layout', '!=', 'hide' )
			);

			$options[] = array(
				'id'        => 'hide_footer',
				'type'      => 'switcher',
				'title'     => esc_html__('Hide Footer', 'oasis'),
			);

			$options[] = array(
				'id'        => 'footer_layout',
				'type'      => 'select',
				'title'     => esc_html__('Footer Layout', 'oasis'),
				'class'     => 'chosen',
				'options'   => self::footerLayout(false,true),
				'default'   => 'inherit',
				'dependency'   => array( 'hide_footer', '!=', '1' ),
			);
			$options[] = array(
				'id'    => 'footer_full_width',
				'type'  => 'radio',
				'title' => esc_html__('Enable Footer FullWidth', 'oasis'),
				'options' => self::radioOption(),
				'default' => 'inherit',
				'dependency'   => array( 'hide_footer', '!=', '1' ),
			);

			$options[] = array(
				'id'        => 'block_content_top',
				'type'      => 'select',
				'title'     => esc_html__('Block Content Top', 'oasis'),
				'class'     => 'chosen',
				'options'   => 'posts',
				'query_args'    => self::blockQueryArgs(),
				'default_option' => esc_html__('Select a block', 'oasis'),
			);
			$options[] = array(
				'id'        => 'block_content_inner_top',
				'type'      => 'select',
				'title'     => esc_html__('Block Content Inner Top', 'oasis'),
				'class'     => 'chosen',
				'options'   => 'posts',
				'query_args'    => self::blockQueryArgs(),
				'default_option' => esc_html__('Select a block', 'oasis'),
			);
			$options[] = array(
				'id'        => 'block_content_bottom',
				'type'      => 'select',
				'title'     => esc_html__('Block Content Bottom', 'oasis'),
				'class'     => 'chosen',
				'options'   => 'posts',
				'query_args'    => self::blockQueryArgs(),
				'default_option' => esc_html__('Select a block', 'oasis'),
			);
			$options[] = array(
				'id'        => 'block_content_inner_bottom',
				'type'      => 'select',
				'title'     => esc_html__('Block Content Inner Bottom', 'oasis'),
				'class'     => 'chosen',
				'options'   => 'posts',
				'query_args'    => self::blockQueryArgs(),
				'default_option' => esc_html__('Select a block', 'oasis'),
			);
			return $options;
		}

		public static function getSkinMetaBox(){
			$options = array();
			return $options;
		}
	}
}