<?php if ( ! defined( 'ABSPATH' ) ) { die; }


$settings = array(
    'menu_title' => esc_html__('Theme Options', 'oasis'),
    'menu_type' => 'theme',
    'menu_slug' => 'theme_options',
    'ajax_save' => false,
    'show_reset_all' => true,
    'framework_title' => sprintf(
        esc_html__('Oasis %1$s%2$sv1.1.5%3$s%4$s %2$sby LA-Studio%3$s', 'oasis'),
        '<sup>',
        '<small>',
        '</small>',
        '</sup>'
    ),
);

$options = array();

$favicon_field = array(
    'id' => 'favicon',
    'type' => 'image',
    'title' => esc_html__('Fav-icon', 'oasis'),
    'add_title' => esc_html__('Add Favicon', 'oasis'),
);

/**
 * General Settings
 */
$options[] = array(
    'name' => 'general_settings',
    'title' => esc_html__('General Settings', 'oasis'),
    'icon' => 'fa fa-tachometer',
    'fields' => array(
        array(
            'type' => 'heading',
            'content' => esc_html__('General Settings', 'oasis'),
        ),
        array(
            'id' => 'layout',
            'type' => 'image_select',
            'title' => esc_html__('Main Layout', 'oasis'),
            'radio' => true,
            'desc' => esc_html__('Select main content and sidebar alignment. Choose between 1, 2 or 3 column layout.', 'oasis'),
            'options' => Oasis_Option_Config::mainLayout(),
            'default' => 'col-2cl',
        ),
        array(
            'id' => 'main_full_width',
            'type' => 'radio',
            'title' => esc_html__('Enable Main FullWidth', 'oasis'),
            'options' => Oasis_Option_Config::radioOption(false),
            'default' => 'no',
        ),
        $favicon_field,
        array(
            'id' => 'google_rich_snippets',
            'type' => 'switcher',
            'title' => esc_html__('Enable Google Rich Snippets', 'oasis'),
            'after' => sprintf('%s%s%s', '<p class="cs-text-desc">', esc_html__('Enable / Disable the Google Rich Snippets in the Breadcrumbs.', 'oasis'), '</p>'),
            'default' => true
        ),
        array(
            'id' => 'enable_back_top',
            'type' => 'switcher',
            'title' => esc_html__('Enable Button Back to top', 'oasis'),
            'default' => true
        ),
        array(
            'id'    => 'enable_page_loader',
            'type'  => 'switcher',
            'title' => esc_html__('Enable Page Loader Icon','oasis'),
            'default' => true
        ),
        array(
            'id'    => 'page_loader_icon_style',
            'default' => '1',
            'type'  => 'select',
            'title' => esc_html__('Page Loader Icon Style','oasis'),
            'options' => array(
                '1' => esc_html__('Style 1', 'oasis'),
                '2' => esc_html__('Style 2', 'oasis'),
                '3' => esc_html__('Style 3', 'oasis'),
                '4' => esc_html__('Style 4', 'oasis'),
                'custom' => esc_html__('Custom image', 'oasis')
            ),
            'dependency' => array('enable_page_loader', '==', 'true'),
        ),
        array(
            'id' => 'page_loader_icon_style_custom',
            'type' => 'image',
            'title' => esc_html__('Custom Loader Icon', 'oasis'),
            'add_title' => esc_html__('Add Image', 'oasis'),
            'dependency' => array('enable_page_loader|page_loader_icon_style', '==|==', 'true|custom'),
        ),

        array(
            'type' => 'heading',
            'content' => esc_html__('Logo Settings', 'oasis'),
        ),

        array(
            'id' => 'logo',
            'type' => 'image',
            'title' => esc_html__('Logo', 'oasis'),
            'add_title' => esc_html__('Add Logo', 'oasis'),
        ),
        array(
            'id' => 'logo_2x',
            'type' => 'image',
            'title' => esc_html__('Retina Logo', 'oasis'),
            'add_title' => esc_html__('Add Logo', 'oasis'),
        ),
        array(
            'id' => 'logo_transparency',
            'type' => 'image',
            'title' => esc_html__('Retina Transparency Logo', 'oasis'),
            'add_title' => esc_html__('Add Logo', 'oasis'),
        ),
        array(
            'id' => 'logo_transparency_2x',
            'type' => 'image',
            'title' => esc_html__('Retina Transparency Logo', 'oasis'),
            'add_title' => esc_html__('Add Logo', 'oasis'),
        ),
        array(
            'id' => 'logo_mobile',
            'type' => 'image',
            'title' => esc_html__('Logo Mobile', 'oasis'),
            'add_title' => esc_html__('Add Logo', 'oasis'),
        ),
        array(
            'id' => 'logo_mobile_2x',
            'type' => 'image',
            'title' => esc_html__('Retina Logo Mobile', 'oasis'),
            'add_title' => esc_html__('Add Logo', 'oasis'),
        )
    )
);
$options[] = array(
    'name' => 'promotion_settings',
    'title' => esc_html__('Newsletter Popup', 'oasis'),
    'icon' => 'fa fa-check',
    'fields' => array(
        array(
            'id' => 'enable_newsletter_popup',
            'type' => 'switcher',
            'title' => esc_html__('Enable Newsletter Popup', 'oasis'),
            'default' => false
        ),
        array(
            'id' => 'only_show_newsletter_popup_on_home_page',
            'type' => 'switcher',
            'title' => esc_html__('Only showing on homepage', 'oasis'),
            'default' => false,
            'dependency' => array('enable_newsletter_popup', '==', 'true')
        ),
        array(
            'id' => 'disable_popup_on_mobile',
            'type' => 'switcher',
            'title' => esc_html__("Don't show popup on mobile", 'oasis'),
            'default' => false,
            'dependency' => array('enable_newsletter_popup', '==', 'true')
        ),
        array(
            'id' => 'newsletter_popup_delay',
            'type' => 'text',
            'title' => esc_html__('Popup showing after', 'oasis'),
            'info' => esc_html__('Show Popup when site loaded after (number) seconds ( 1000ms = 1 second )', 'oasis'),
            'default' => '2000',
            'dependency' => array('enable_newsletter_popup', '==', 'true'),
        ),
        array(
            'id' => 'show_checkbox_hide_newsletter_popup',
            'type' => 'switcher',
            'title' => esc_html__("Display option \"Don't show popup anymore\"", 'oasis'),
            'default' => false,
            'dependency' => array('enable_newsletter_popup', '==', 'true')
        ),
        array(
            'id' => 'newsletter_popup_show_again',
            'type' => 'text',
            'title' => esc_html__('Back display popup after', 'oasis'),
            'info' => esc_html__('Enter number day', 'oasis'),
            'default' => '1',
            'dependency' => array('enable_newsletter_popup|show_checkbox_hide_newsletter_popup', '==|==', 'true|true'),
        ),
        array(
            'id' => 'newsletter_popup_content',
            'type' => 'wysiwyg',
            'title' => esc_html__('Newsletter Popup Content', 'oasis'),
            'dependency' => array('enable_newsletter_popup', '==', 'true'),
        ),
    )
);
/**
 * Skins
 */
$options[] = array(
    'name' => 'skin_settings',
    'title' => esc_html__('Skins', 'oasis'),
    'icon' => 'fa fa-paint-brush',
    'sections' => array(
        /*
        * General
        */
        array(
            'name' => 'section_skin_general',
            'title' => esc_html__('General', 'oasis'),
            'icon' => 'fa fa-cog',
            'fields' => array(
                array(
                    'id' => 'body_background',
                    'type' => 'background',
                    'title' => esc_html__('Body background', 'oasis'),
                ),
                array(
                    'id' => 'body_font_size',
                    'type' => 'number',
                    'title' => esc_html__('Body Font Size', 'oasis'),
                    'default' => '14',
                    'after' => 'px'
                ),
                array(
                    'id' => 'text_color',
                    'type' => 'color_picker',
                    'title' => esc_html__('Text Color', 'oasis'),
                    'default' => '#727883',
                ),
                array(
                    'id' => 'heading_color',
                    'type' => 'color_picker',
                    'title' => esc_html__('Heading Color', 'oasis'),
                    'default' => '#000',
                ),
                array(
                    'id' => 'primary_color',
                    'type' => 'color_picker',
                    'title' => esc_html__('Primary Color', 'oasis'),
                    'default' => '#ce1a2b',
                ),
                array(
                    'id' => 'secondary_color',
                    'type' => 'color_picker',
                    'title' => esc_html__('Secondary Color', 'oasis'),
                    'default' => '#000'
                ),
                array(
                    'id' => 'third_color',
                    'type' => 'color_picker',
                    'title' => esc_html__('Third Color', 'oasis'),
                    'default' => '#727883'
                ),
                array(
                    'id' => 'border_color',
                    'type' => 'color_picker',
                    'title' => esc_html__('Border Color', 'oasis'),
                    'default' => '#dddddd',
                    'rgba' => true,
                ),
            )
        ),
        /*
        * Fonts
        */
        array(
            'name' => 'section_skin_fonts',
            'title' => esc_html__('Fonts', 'oasis'),
            'icon' => 'fa fa fa-font',
            'fields' => array(
                array(
                    'type' => 'heading',
                    'content' => esc_html__('Typography', 'oasis'),
                ),
                array(
                    'type' => 'subheading',
                    'content' => esc_html__('Font Sources', 'oasis'),
                ),
                array(
                    'id' => 'font_source',
                    'type' => 'radio',
                    'title' => esc_html__('Font Sources', 'oasis'),
                    'options' => array(
                        '1' => esc_html__('Standard + Google Webfonts', 'oasis'),
                        '2' => esc_html__('Google Custom', 'oasis'),
                        '3' => esc_html__('Adobe Typekit', 'oasis'),
                    ),
                    'default' => '1'
                ),
                //
                array(
                    'id' => 'main_font',
                    'type' => 'typography',
                    'title' => esc_html__('Main Font', 'oasis'),
                    'default' => array(
                        'family' => esc_html__('Raleway', 'oasis'),
                        'font' => 'google',
                    ),
                    'dependency' => array('font_source_1', '==', 'true'),
                    'variant' => false
                ),
                array(
                    'id' => 'secondary_font',
                    'type' => 'typography',
                    'title' => esc_html__('Secondary Font', 'oasis'),
                    'default' => array(
                        'family' => esc_html__('Questrial', 'oasis'),
                        'font' => 'google',
                    ),
                    'dependency' => array('font_source_1', '==', 'true'),
                    'variant' => false
                ),
                array(
                    'id' => 'highlight_font',
                    'type' => 'typography',
                    'title' => esc_html__('Highlight Font', 'oasis'),
                    'default' => array(
                        'family' => esc_html__('Questrial', 'oasis'),
                        'font' => 'google',
                    ),
                    'dependency' => array('font_source_1', '==', 'true'),
                    'variant' => false
                ),
                //
                array(
                    'id' => 'font_google_code',
                    'type' => 'text',
                    'title' => esc_html__('Font Google code', 'oasis'),
                    'dependency' => array('font_source_2', '==', 'true'),
                ),
                array(
                    'id' => 'main_google_font_face',
                    'type' => 'text',
                    'title' => esc_html__('Main Google Font Face', 'oasis'),
                    'after' => 'e.g : open sans',
                    'desc' => esc_html__('Enter your Google Font Name for the theme\'s Main Typography', 'oasis'),
                    'dependency' => array('font_source_2', '==', 'true'),
                ),
                array(
                    'id' => 'secondary_google_font_face',
                    'type' => 'text',
                    'title' => esc_html__('Secondary Google Font Face', 'oasis'),
                    'after' => 'e.g : open sans',
                    'desc' => esc_html__('Enter your Google Font Name for the theme\'s Secondary Typography', 'oasis'),
                    'dependency' => array('font_source_2', '==', 'true'),
                ),
                array(
                    'id' => 'highlight_google_font_face',
                    'type' => 'text',
                    'title' => esc_html__('Highlight Google Font Face', 'oasis'),
                    'after' => 'e.g : open sans',
                    'desc' => esc_html__('Enter your Google Font Name for the theme\'s Highlight Typography', 'oasis'),
                    'dependency' => array('font_source_2', '==', 'true'),
                ),

                //
                array(
                    'id' => 'font_typekit_kit_id',
                    'type' => 'text',
                    'title' => esc_html__('Typekit Kit ID', 'oasis'),
                    'dependency' => array('font_source_3', '==', 'true'),
                ),
                array(
                    'id' => 'main_typekit_font_face',
                    'type' => 'text',
                    'title' => esc_html__('Main Typekit Font Face', 'oasis'),
                    'after' => 'e.g : futura-pt',
                    'desc' => esc_html__('Enter your Typekit Font Name for the theme\'s Main Typography', 'oasis'),
                    'dependency' => array('font_source_3', '==', 'true'),
                ),
                array(
                    'id' => 'secondary_typekit_font_face',
                    'type' => 'text',
                    'title' => esc_html__('Secondary Typekit Font Face', 'oasis'),
                    'after' => 'e.g : futura-pt',
                    'desc' => esc_html__('Enter your Typekit Font Name for the theme\'s Secondary Typography', 'oasis'),
                    'dependency' => array('font_source_3', '==', 'true'),
                ),
                array(
                    'id' => 'highlight_typekit_font_face',
                    'type' => 'text',
                    'title' => esc_html__('Highlight Typekit Font Face', 'oasis'),
                    'after' => 'e.g : futura-pt',
                    'desc' => esc_html__('Enter your Typekit Font Name for the theme\'s Highlight Typography', 'oasis'),
                    'dependency' => array('font_source_3', '==', 'true'),
                ),
            )
        ),
        /*
        * Main Menu
        */
        array(
            'name' => 'section_skin_nav',
            'title' => esc_html__('Main Menu', 'oasis'),
            'icon' => 'fa fa-check',
            'fields' => array(
                array(
                    'type' => 'heading',
                    'content' => esc_html__('Main Menu', 'oasis'),
                ),
                array(
                    'id' => 'mm_dropdown_bg',
                    'type' => 'color_picker',
                    'title' => esc_html__('DropDown Background Color', 'oasis'),
                    'default' => '#fff',
                ),
                array(
                    'id' => 'mm_dropdown_link_color',
                    'type' => 'color_picker',
                    'title' => esc_html__('DropDown Link Color', 'oasis'),
                    'default' => '#696c75',
                ),
                array(
                    'id' => 'mm_dropdown_link_bg',
                    'type' => 'color_picker',
                    'title' => esc_html__('DropDown Link Background Color', 'oasis'),
                    'default' => 'rgba(0,0,0,0)',
                ),
                array(
                    'id' => 'mm_dropdown_link_hover_color',
                    'type' => 'color_picker',
                    'title' => esc_html__('DropDown Link Hover Color', 'oasis'),
                    'default' => '#1c1d1f',
                ),
                array(
                    'id' => 'mm_dropdown_link_hover_bg',
                    'type' => 'color_picker',
                    'title' => esc_html__('DropDown Link Hover Background Color', 'oasis'),
                    'default' => 'rgba(0,0,0,0)',
                ),


                array(
                    'id' => 'mm_wide_dropdown_bg',
                    'type' => 'color_picker',
                    'title' => esc_html__('(Wide) DropDown Background Color', 'oasis'),
                    'default' => '#fff',
                ),
                array(
                    'id' => 'mm_wide_dropdown_heading_color',
                    'type' => 'color_picker',
                    'title' => esc_html__('(Wide) DropDown Heading Color', 'oasis'),
                    'default' => '#1c1d1f',
                ),
                array(
                    'id' => 'mm_wide_dropdown_link_color',
                    'type' => 'color_picker',
                    'title' => esc_html__('(Wide) DropDown Link Color', 'oasis'),
                    'default' => '#696c75',
                ),
                array(
                    'id' => 'mm_wide_dropdown_link_bg',
                    'type' => 'color_picker',
                    'title' => esc_html__('(Wide) DropDown Link Background Color', 'oasis'),
                    'default' => 'rgba(0,0,0,0)',
                ),
                array(
                    'id' => 'mm_wide_dropdown_link_hover_color',
                    'type' => 'color_picker',
                    'title' => esc_html__('(Wide) DropDown Link Hover Color', 'oasis'),
                    'default' => '#1c1d1f',
                ),
                array(
                    'id' => 'mm_wide_dropdown_link_hover_bg',
                    'type' => 'color_picker',
                    'title' => esc_html__('(Wide) DropDown Link Hover Background Color', 'oasis'),
                    'default' => 'rgba(0,0,0,0)',
                ),

                array(
                    'type' => 'heading',
                    'content' => esc_html__('Mobile Menu', 'oasis'),
                ),

                array(
                    'id' => 'mb_background',
                    'type' => 'color_picker',
                    'title' => esc_html__('Mobile Menu Background', 'oasis'),
                    'default' => '#fff',
                ),
                array(
                    'id' => 'mb_lv_1_color',
                    'type' => 'color_picker',
                    'title' => esc_html__('Mobile Menu Level 1 Color', 'oasis'),
                    'default' => '#727883',
                ),
                array(
                    'id' => 'mb_lv_1_bg_color',
                    'type' => 'color_picker',
                    'title' => esc_html__('Mobile Menu Level 1 Background Color', 'oasis'),
                    'default' => '#f4f6f7',
                ),
                array(
                    'id' => 'mb_lv_1_hover_color',
                    'type' => 'color_picker',
                    'title' => esc_html__('Mobile Menu Level 1 Hover Color', 'oasis'),
                    'default' => '#727883',
                ),
                array(
                    'id' => 'mb_lv_1_hover_bg_color',
                    'type' => 'color_picker',
                    'title' => esc_html__('Mobile Menu Level 1 Hover Background Color', 'oasis'),
                    'default' => '#f4f6f7',
                ),
                array(
                    'id' => 'mb_lv_2_color',
                    'type' => 'color_picker',
                    'title' => esc_html__('Mobile Menu Level 2 Color', 'oasis'),
                    'default' => '#727883',
                ),
                array(
                    'id' => 'mb_lv_2_bg_color',
                    'type' => 'color_picker',
                    'title' => esc_html__('Mobile Menu Level 2 Background Color', 'oasis'),
                    'default' => '#f4f6f7',
                ),
                array(
                    'id' => 'mb_lv_2_hover_color',
                    'type' => 'color_picker',
                    'title' => esc_html__('Mobile Menu Level 2 Hover Color', 'oasis'),
                    'default' => '#727883',
                ),
                array(
                    'id' => 'mb_lv_2_hover_bg_color',
                    'type' => 'color_picker',
                    'title' => esc_html__('Mobile Menu Level 2 Hover Background Color', 'oasis'),
                    'default' => '#f4f6f7',
                ),
            )
        ),
    )
);

/**
 * Header
 */
$options[] = array(
    'name' => 'header_settings',
    'title' => esc_html__('Header', 'oasis'),
    'icon' => 'fa fa-bookmark',
    'sections' => array(
        /**
         * Header Layout
         */
        array(
            'name' => 'section_header_layout',
            'title' => esc_html__('Header Layout', 'oasis'),
            'icon' => 'fa fa-check',
            'fields' => array(
                array(
                    'type' => 'heading',
                    'content' => esc_html__('Header layout', 'oasis'),
                ),
                array(
                    'id' => 'header_layout',
                    'type' => 'image_select',
                    'title' => esc_html__('Header Layout', 'oasis'),
                    'radio' => true,
                    'options' => Oasis_Option_Config::headerLayout(),
                    'default' => '2',
                ),
                array(
                    'id' => 'header_full_width',
                    'type' => 'radio',
                    'title' => esc_html__('Enable Header Full Width', 'oasis'),
                    'desc' => esc_html__('This option do not apply for header side', 'oasis'),
                    'options' => Oasis_Option_Config::radioOption(false),
                    'default' => 'no',
                ),
                array(
                    'id' => 'header_transparency',
                    'type' => 'radio',
                    'title' => esc_html__('Enable Header Transparency', 'oasis'),
                    'desc' => esc_html__('This option do not apply for header side', 'oasis'),
                    'options' => Oasis_Option_Config::radioOption(false),
                    'default' => 'no',
                ),
            )

        ),
        /**
         * Header Elements
         */
        array(
            'name' => 'section_header_elements',
            'title' => esc_html__('Header Elements', 'oasis'),
            'icon' => 'fa fa-check',
            'fields' => array(
                array(
                    'type' => 'heading',
                    'content' => esc_html__('Header Elements', 'oasis'),
                ),
                array(
                    'id' => 'header_show_cart',
                    'type' => 'switcher',
                    'title' => esc_html__('Show Shopping Bag', 'oasis'),
                    'after' => sprintf('%s%s%s', '<p class="cs-text-desc">', esc_html__('Enable / Disable Shopping Bag in the Header.', 'oasis'), '</p>'),
                    'default' => true
                ),
                array(
                    'id' => 'header_show_search',
                    'type' => 'switcher',
                    'title' => esc_html__('Show Search', 'oasis'),
                    'after' => sprintf('%s%s%s', '<p class="cs-text-desc">', esc_html__('Enable / Disable Search in the Header.', 'oasis'), '</p>'),
                    'default' => true
                ),
                array(
                    'id' => 'header_show_social',
                    'type' => 'switcher',
                    'title' => esc_html__('Show Social', 'oasis'),
                    'after' => sprintf('%s%s%s', '<p class="cs-text-desc">', esc_html__('For header style 5,6', 'oasis'), '</p>'),
                    'default' => true
                ),
                array(
                    'id' => 'store_address',
                    'type' => 'text',
                    'title' => esc_html__('Store Address', 'oasis'),
                    'after' => sprintf('<p class="cs-text-desc">%s</p>', esc_html__('For header style 3,5,6', 'oasis'))
                ),

                array(
                    'id' => 'store_phone',
                    'type' => 'text',
                    'title' => esc_html__('Store Phone', 'oasis'),
                    'after' => sprintf('<p class="cs-text-desc">%s</p>', esc_html__('For header style 3,5,6', 'oasis'))
                ),
                array(
                    'id' => 'store_email',
                    'type' => 'text',
                    'title' => esc_html__('Store Email', 'oasis'),
                    'after' => sprintf('<p class="cs-text-desc">%s</p>', esc_html__('For header style 5,6', 'oasis'))
                ),
                array(
                    'id' => 'show_custom_header_top',
                    'type' => 'switcher',
                    'title' => esc_html__('Enable custom header top text', 'oasis'),
                    'after' => sprintf('%s%s%s', '<p class="cs-text-desc">', esc_html__('Enable / Disable custom header top text.', 'oasis'), '</p>'),
                    'default' => false
                ),
                array(
                    'id' => 'custom_header_top_text',
                    'type' => 'textarea',
                    'default' => 'FREE WORLDWIDE SHIPPING ON ALL ORDERS OVER $100',
                    'title' => esc_html__('Custom Header top text', 'oasis'),
                    'dependency' => array('show_custom_header_top', '==', 'true')
                ),
                array(
                    'id' => 'header_top_custom_color',
                    'type' => 'color_picker',
                    'title' => esc_html__('Custom Header Top Text Color', 'oasis'),
                    'default' => '#252634',
                ),
                array(
                    'id' => 'header_top_custom_bg',
                    'type' => 'color_picker',
                    'title' => esc_html__('Custom Header Top Background', 'oasis'),
                    'default' => '#fff',
                ),
            )
        ),
        array(
            'name' => 'section_header_colors',
            'title' => esc_html__('Header Color', 'oasis'),
            'icon' => 'fa fa-check',
            'fields' => array(
                array(
                    'type' => 'heading',
                    'content' => esc_html__('Header Color', 'oasis'),
                ),
                array(
                    'id' => 'header_background',
                    'type' => 'background',
                    'title' => esc_html__('Header Background', 'oasis'),
                    'default' => array(
                        'color' => '#fff',
                    )
                ),
                array(
                    'id' => 'header_text_color',
                    'type' => 'color_picker',
                    'title' => esc_html__('Header Text Color', 'oasis'),
                    'default' => '#2b2c30',
                    'rgba' => true,
                ),
                array(
                    'id' => 'header_link_color',
                    'type' => 'color_picker',
                    'title' => esc_html__('Header Link Color', 'oasis'),
                    'default' => '#2b2c30'
                ),
                array(
                    'id' => 'header_link_hover_color',
                    'type' => 'color_picker',
                    'title' => esc_html__('Header Link Hover Color', 'oasis'),
                    'default' => '#ce1a2b',
                    'rgba' => true,
                ),

                array(
                    'id' => 'mm_lv_1_color',
                    'type' => 'color_picker',
                    'title' => esc_html__('Menu Level 1 Color', 'oasis'),
                    'default' => '#2b2c30',
                ),
                array(
                    'id' => 'mm_lv_1_bg_color',
                    'type' => 'color_picker',
                    'title' => esc_html__('Menu Level 1 Background Color', 'oasis'),
                    'default' => 'rgba(0, 0, 0, 0)',
                ),
                array(
                    'id' => 'mm_lv_1_hover_color',
                    'type' => 'color_picker',
                    'title' => esc_html__('Menu Level 1 Hover Color', 'oasis'),
                    'default' => '#ce1a2b',
                ),
                array(
                    'id' => 'mm_lv_1_hover_bg_color',
                    'type' => 'color_picker',
                    'title' => esc_html__('Menu Level 1 Hover Background Color', 'oasis'),
                    'default' => 'rgba(0, 0, 0, 0)',
                ),
                array(
                    'id' => 'mm_lv_1_active_color',
                    'type' => 'color_picker',
                    'title' => esc_html__('Menu Level 1 Active Color', 'oasis'),
                    'default' => '#ce1a2b',
                ),
                array(
                    'id' => 'mm_lv_1_active_bg_color',
                    'type' => 'color_picker',
                    'title' => esc_html__('Menu Level 1 Active Background Color', 'oasis'),
                    'default' => 'rgba(0, 0, 0, 0)',
                ),

                /**
                 * Header Transparency styling
                 */
                array(
                    'type' => 'heading',
                    'content' => esc_html__('Header Transparency Color', 'oasis'),
                ),
                array(
                    'id' => 'header_transparency_background',
                    'type' => 'background',
                    'title' => esc_html__('Header Transparency Background', 'oasis'),
                    'default' => array(
                        'color' => 'transparent',
                    ),
                ),
                array(
                    'id' => 'header_transparency_text_color',
                    'type' => 'color_picker',
                    'title' => esc_html__('Header Transparency Text Color', 'oasis'),
                    'default' => '#2b2c30',
                    'rgba' => true,
                ),
                array(
                    'id' => 'header_transparency_link_color',
                    'type' => 'color_picker',
                    'title' => esc_html__('Header Transparency Link Color', 'oasis'),
                    'default' => '#2b2c30'
                ),
                array(
                    'id' => 'header_transparency_link_hover_color',
                    'type' => 'color_picker',
                    'title' => esc_html__('Header Transparency Link Hover Color', 'oasis'),
                    'default' => '#ce1a2b',
                    'rgba' => true,
                ),

                array(
                    'id' => 'header_transparency_mm_lv_1_color',
                    'type' => 'color_picker',
                    'title' => esc_html__('Menu Level 1 Color', 'oasis'),
                    'default' => '#fff',
                ),
                array(
                    'id' => 'header_transparency_mm_lv_1_bg_color',
                    'type' => 'color_picker',
                    'title' => esc_html__('Menu Level 1 Background Color', 'oasis'),
                    'default' => 'rgba(0, 0, 0, 0)',
                ),
                array(
                    'id' => 'header_transparency_mm_lv_1_hover_color',
                    'type' => 'color_picker',
                    'title' => esc_html__('Menu Level 1 Hover Color', 'oasis'),
                    'default' => '#fff',
                ),
                array(
                    'id' => 'header_transparency_mm_lv_1_hover_bg_color',
                    'type' => 'color_picker',
                    'title' => esc_html__('Menu Level 1 Hover Background Color', 'oasis'),
                    'default' => '#111',
                ),
                array(
                    'id' => 'header_transparency_mm_lv_1_active_color',
                    'type' => 'color_picker',
                    'title' => esc_html__('Menu Level 1 Active Color', 'oasis'),
                    'default' => '#fff',
                ),
                array(
                    'id' => 'header_transparency_mm_lv_1_active_bg_color',
                    'type' => 'color_picker',
                    'title' => esc_html__('Menu Level 1 Active Background Color', 'oasis'),
                    'default' => '#111',
                ),
            )
        )
    )
);
/**
 * Page Header
 */
$options[] = array(
    'name' => 'page_header_settings',
    'title' => esc_html__('Page Header', 'oasis'),
    'icon' => 'fa fa-bookmark',
    'sections' => array(
        /**
         * Header Layout
         */
        array(
            'name' => 'section_page_header_layout',
            'title' => esc_html__('Page Header Layout', 'oasis'),
            'icon' => 'fa fa-check',
            'fields' => array(
                array(
                    'type' => 'heading',
                    'content' => esc_html__('Page Header layout', 'oasis'),
                ),
                array(
                    'id' => 'page_header_layout',
                    'type' => 'select',
                    'title' => esc_html__('Page Header Layout', 'oasis'),
                    'radio' => true,
                    'options' => Oasis_Option_Config::pageHeaderLayout(false),
                    'default' => '1',
                ),
                array(
                    'id' => 'show_page_title',
                    'type' => 'radio',
                    'title' => esc_html__('Display Title on page header', 'oasis'),
                    'options' => Oasis_Option_Config::radioOption(false),
                    'default' => 'no',
                ),
                array(
                    'id' => 'show_breadcrumbs',
                    'type' => 'radio',
                    'title' => esc_html__('Display Breadcrumbs', 'oasis'),
                    'options' => Oasis_Option_Config::radioOption(false),
                    'default' => 'yes',
                ),
                array(
                    'id' => 'page_header_background',
                    'type' => 'background',
                    'title' => esc_html__('Page Header Background', 'oasis'),
                    'default' => array(
                        'color' => '#eeeeee'
                    )
                ),
                array(
                    'id' => 'page_header_spacing',
                    'type' => 'la_spacing',
                    'title' => esc_html__('Padding', 'oasis'),
                    'unit' => 'px',
                    'default' => array(
                        'top' => 70,
                        'bottom' => 60
                    ),
                    'options' => array(
                        'top' => true,
                        'bottom' => true,
                        'left' => false,
                        'right' => false
                    )
                ),
                array(
                    'id' => 'page_header_spacing_tablet',
                    'type' => 'la_spacing',
                    'title' => esc_html__('Padding', 'oasis'),
                    'desc' => esc_html__('On Tablet', 'oasis'),
                    'unit' => 'px',
                    'default' => array(
                        'top' => 70,
                        'bottom' => 60
                    ),
                    'options' => array(
                        'top' => true,
                        'bottom' => true,
                        'left' => false,
                        'right' => false
                    )
                ),
                array(
                    'id' => 'page_header_spacing_mobile',
                    'type' => 'la_spacing',
                    'title' => esc_html__('Padding', 'oasis'),
                    'desc' => esc_html__('On Mobile', 'oasis'),
                    'unit' => 'px',
                    'default' => array(
                        'top' => 40,
                        'bottom' => 30
                    ),
                    'options' => array(
                        'top' => true,
                        'bottom' => true,
                        'left' => false,
                        'right' => false
                    )
                ),
                array(
                    'id' => 'page_header_title_color',
                    'type' => 'color_picker',
                    'title' => esc_html__('Page Header Title Color', 'oasis'),
                    'default' => '#000',
                    'rgba' => false
                ),
                array(
                    'id' => 'page_header_text_color',
                    'type' => 'color_picker',
                    'title' => esc_html__('Page Header Text Color', 'oasis'),
                    'default' => '#bdbfc3',
                    'rgba' => false
                ),
                array(
                    'id' => 'page_header_link_color',
                    'type' => 'color_picker',
                    'title' => esc_html__('Page Header Link Color', 'oasis'),
                    'default' => '#bdbfc3',
                    'rgba' => false
                ),
                array(
                    'id' => 'page_header_link_hover_color',
                    'type' => 'color_picker',
                    'title' => esc_html__('Page Header Link Hover Color', 'oasis'),
                    'default' => '#ce1a2b',
                    'rgba' => false
                ),
            )
        ),
    )
);
/**
 * Footer
 */
$options[] = array(
    'name' => 'footer_settings',
    'title' => esc_html__('Footer', 'oasis'),
    'icon' => 'fa fa-arrow-circle-down',
    'sections' => array(
        /**
         * Footer Layout
         */
        array(
            'name' => 'section_footer_layout',
            'title' => esc_html__('Footer Layout', 'oasis'),
            'icon' => 'fa fa-check',
            'fields' => array(
                array(
                    'type' => 'heading',
                    'content' => esc_html__('Footer Layout', 'oasis'),
                ),
                array(
                    'id' => 'footer_layout',
                    'type' => 'image_select',
                    'title' => esc_html__('Footer Layout', 'oasis'),
                    'radio' => true,
                    'options' => Oasis_Option_Config::footerLayout(),
                    'default' => '1',
                ),
                array(
                    'id' => 'footer_full_width',
                    'type' => 'radio',
                    'title' => esc_html__('Enable Footer FullWidth', 'oasis'),
                    'options' => Oasis_Option_Config::radioOption(false),
                    'default' => 'yes',
                ),
                array(
                    'id' => 'footer_copyright_text',
                    'type' => 'la_ace_editor',
                    'mode' => 'html',
                    'theme' => 'monokai',
                    'options' => array('minLines' => 12, 'maxLines' => 30),
                    'before' => '<h4>' . esc_html__('Footer copyright text', 'oasis') . '</h4>',
                    'after' => esc_html__('Paste your custom HTML code here.', 'oasis'),
                ),
            )
        ),

        array(
            'name' => 'section_footer_style',
            'title' => esc_html__('Footer Color', 'oasis'),
            'icon' => 'fa fa-check',
            'fields' => array(
                array(
                    'type' => 'heading',
                    'content' => esc_html__('Footer Styling', 'oasis'),
                ),
                array(
                    'id' => 'footer_background',
                    'type' => 'background',
                    'title' => esc_html__('Footer Background', 'oasis'),
                    'default' => array(
                        'color' => '#fff',
                    )
                ),
                array(
                    'id' => 'footer_text_color',
                    'type' => 'color_picker',
                    'title' => esc_html__('Footer Text Color', 'oasis'),
                    'default' => '#2b2c30',
                    'rgba' => false
                ),
                array(
                    'id' => 'footer_heading_color',
                    'type' => 'color_picker',
                    'title' => esc_html__('Footer Heading Color', 'oasis'),
                    'default' => '#2b2c30',
                    'rgba' => false
                ),
                array(
                    'id' => 'footer_link_color',
                    'type' => 'color_picker',
                    'title' => esc_html__('Footer Link Color', 'oasis'),
                    'default' => '#2b2c30',
                    'rgba' => false
                ),
                array(
                    'id' => 'footer_link_hover_color',
                    'type' => 'color_picker',
                    'title' => esc_html__('Footer Link Hover Color', 'oasis'),
                    'default' => '#ce1a2b',
                    'rgba' => false
                )
            )
        )
    )
);

/**
 * Blog
 */
$options[] = array(
    'name' => 'blog_settings',
    'title' => esc_html__('Blog', 'oasis'),
    'icon' => 'fa fa-newspaper-o',
    'sections' => array(
        /**
         * Blog General
         */
        array(
            'name' => 'section_blog_general',
            'title' => esc_html__('General', 'oasis'),
            'icon' => 'fa fa-file-archive-o',
            'fields' => array(
                array(
                    'type' => 'heading',
                    'content' => esc_html__('Blog & Post Archives General Setting', 'oasis'),
                ),
                array(
                    'id' => 'blog_layout',
                    'type' => 'image_select',
                    'title' => esc_html__('Blog Layout', 'oasis'),
                    'radio' => true,
                    'options' => Oasis_Option_Config::mainLayout(true, true),
                    'default' => 'col-1c',
                ),
                array(
                    'id'        => 'blog_style',
                    'type'      => 'select',
                    'title'     => esc_html__('Blog Design', 'oasis'),
                    'options'        => array(
                        'grid-1col'          => esc_html__('Grid 1 column', 'oasis'),
                        'grid-2col'          => esc_html__('Grid 2 columns', 'oasis'),
                        'grid-3col'          => esc_html__('Grid 3 columns', 'oasis'),
                        'grid-4col'          => esc_html__('Grid 4 columns', 'oasis'),
                        'grid-5col'          => esc_html__('Grid 5 columns', 'oasis'),
                        'grid-6col'          => esc_html__('Grid 6 columns', 'oasis'),
                        'pinterest-2col'     => esc_html__('Pinterest 2 columns', 'oasis'),
                        'pinterest-3col'     => esc_html__('Pinterest 3 columns', 'oasis'),
                        'pinterest-4col'     => esc_html__('Pinterest 4 columns', 'oasis'),
                        'pinterest-5col'     => esc_html__('Pinterest 5 columns', 'oasis'),
                        'pinterest-6col'     => esc_html__('Pinterest 6 columns', 'oasis'),
                        'list-1col'          => esc_html__('List view', 'oasis'),
                        'metro'              => esc_html__('Metro', 'oasis')
                    ),
                    'default' => 'grid-3col'
                ),
                array(
                    'id'    => 'blog_show_postformat',
                    'type'  => 'radio',
                    'title' => esc_html__('Show PostFormat Content', 'oasis'),
                    'options' => Oasis_Option_Config::radioOption(false),
                    'default' => 'no'
                ),
                array(
                    'id' => 'blog_excerpt_length',
                    'type' => 'number',
                    'title' => esc_html__('Excerpt Length', 'oasis'),
                    'default' => 6
                ),
            )
        ),
        /**
         * Single Post
         */
        array(
            'name' => 'section_blog_single_post',
            'title' => esc_html__('Single Post', 'oasis'),
            'icon' => 'fa fa-file-o',
            'fields' => array(
                array(
                    'type' => 'heading',
                    'content' => esc_html__('Single Post Setting', 'oasis'),
                ),
                array(
                    'id' => 'single_post_layout',
                    'type' => 'image_select',
                    'title' => esc_html__('Single Post Layout', 'oasis'),
                    'radio' => true,
                    'options' => Oasis_Option_Config::mainLayout(true, true),
                    'default' => 'col-2cl',
                ),
                array(
                    'id' => 'single_post_show_share_link',
                    'type' => 'switcher',
                    'title' => esc_html__('Show Social Share Links', 'oasis'),
                    'default' => true
                ),
                array(
                    'id' => 'single_post_show_author_info',
                    'type' => 'switcher',
                    'title' => esc_html__('Show Author Info', 'oasis'),
                    'default' => true
                ),
                array(
                    'id' => 'single_post_show_comment',
                    'type' => 'switcher',
                    'title' => esc_html__('Show Comment', 'oasis'),
                    'default' => true
                )
            )
        )
    )
);

/**
 * Shop
 */
if(Oasis_Helper::isActiveWooCommerce()) {
    $options[] = array(
        'name' => 'shop_settings',
        'title' => esc_html__('WooCommerce', 'oasis'),
        'icon' => 'fa fa-shopping-cart',
        'sections' => array(
            /**
             * Shop Layout
             */
            array(
                'name' => 'section_shop_layout',
                'title' => esc_html__('General', 'oasis'),
                'icon' => 'fa fa-check',
                'fields' => array(
                    array(
                        'type' => 'heading',
                        'content' => esc_html__('Shop General Setting', 'oasis'),
                    ),
                    array(
                        'id' => 'shop_layout',
                        'type' => 'image_select',
                        'title' => esc_html__('Shop Layout', 'oasis'),
                        'radio' => true,
                        'options' => Oasis_Option_Config::mainLayout(true, true),
                        'default' => 'col-2cl',
                    ),
                    array(
                        'id' => 'show_pageheader_on_shop',
                        'type' => 'switcher',
                        'title' => esc_html__('Show Page header', 'oasis'),
                        'info' => esc_html__('Allow display page header layout in shop page & product category and product tags', 'oasis'),
                        'default' => false
                    ),
                    array(
                        'id' => 'catalog_display_type',
                        'type' => 'select',
                        'title' => esc_html__('Catalog Display Type', 'oasis'),
                        'options' => array(
                            'grid' => esc_html__('Grid', 'oasis'),
                            'list' => esc_html__('List', 'oasis')
                        ),
                        'default' => 'grid',
                    ),
                    array(
                        'id' => 'column_per_row',
                        'type' => 'la_column_responsive',
                        'title' => esc_html__('Product Columns', 'oasis'),
                        'default' => array(
                            'xlg' => '3',
                            'lg' => '3',
                            'md' => '2',
                            'sm' => '2',
                            'xs' => '1',
                        ),
                        'after' => '<p class="cs-text-desc">' . esc_html__('choose the select to set the number of products per row to be listed on the shop page and catalog pages.', 'oasis') . '</p>',
                        'dependency' => array('catalog_display_type', 'any', 'grid,grid2'),
                    ),
                    array(
                        'id' => 'product_per_page_grid',
                        'type' => 'text',
                        'title' => esc_html__('Number product per page allow', 'oasis'),
                        'after' => esc_html__('Comma-separated.', 'oasis'),
                        'default' => '9,15,30',
                    ),
                    array(
                        'id' => 'product_per_page_default_grid',
                        'type' => 'number',
                        'title' => esc_html__('Number product per page default', 'oasis'),
                        'default' => '9',
                    ),
                    array(
                        'id' => 'enable_shop_infinite_scroll',
                        'type' => 'switcher',
                        'title' => esc_html__('Enable Shop Infinite Scroll', 'oasis'),
                        'default' => false
                    ),
                    array(
                        'id' => 'show_rating_on_catalog_page',
                        'type' => 'switcher',
                        'title' => esc_html__('Show Ratings on Catalog Page', 'oasis'),
                        'default' => true
                    ),
                    array(
                        'id' => 'show_alt_image_catalog_page',
                        'type' => 'switcher',
                        'title' => esc_html__('Show second image on catalog page ( Hover effect )', 'oasis'),
                        'default' => true
                    ),
                    array(
                        'id' => 'show_quick_view_btn',
                        'type' => 'switcher',
                        'title' => esc_html__('Show Quick View Button', 'oasis'),
                        'default' => true
                    ),
                    array(
                        'id' => 'show_wishlist_btn',
                        'type' => 'switcher',
                        'title' => esc_html__('Show Wishlist Button', 'oasis'),
                        'default' => true
                    ),
                    array(
                        'id' => 'enable_popup_addtolink',
                        'type' => 'switcher',
                        'title' => esc_html__('Enable Popup When Click Add to link', 'oasis'),
                        'info' => esc_html__('Enable popup when click to "Add to cart", "Add to wishlist" button','oasis'),
                        'default' => false
                    ),
                )
            ),
            /**
             * Shop Detail
             */
            array(
                'name' => 'section_shop_details',
                'title' => esc_html__('Product Page', 'oasis'),
                'icon' => 'fa fa-check',
                'fields' => array(
                    array(
                        'type' => 'heading',
                        'content' => esc_html__('Product Page', 'oasis'),
                    ),

                    array(
                        'id' => 'product_single_style',
                        'title' => esc_html__('Select Design', 'oasis'),
                        'type' => 'select',
                        'options'        => array(
                            '1'          => esc_html__('Design 01', 'oasis'),
                            '2'          => esc_html__('Design 02', 'oasis'),
                            '3'          => esc_html__('Design 03', 'oasis'),
                            '4'          => esc_html__('Design 04', 'oasis'),
                            '5'          => esc_html__('Design 05', 'oasis')
                        ),
                        'default'   => 1
                    ),

                    array(
                        'id' => 'enable_product_sharing',
                        'type' => 'switcher',
                        'title' => esc_html__('Product Sharing Option', 'oasis'),
                        'default' => true
                    ),
                    array(
                        'id' => 'show_related_product',
                        'type' => 'switcher',
                        'title' => esc_html__('Show Related Product', 'oasis'),
                        'default' => true
                    ),

                    array(
                        'id' => 'related_product_columns',
                        'title' => esc_html__('Related Product Columns', 'oasis'),
                        'type' => 'select',
                        'options'        => array(
                            '1'          => esc_html__('1 column', 'oasis'),
                            '2'          => esc_html__('2 columns', 'oasis'),
                            '3'          => esc_html__('3 columns', 'oasis'),
                            '4'          => esc_html__('4 columns', 'oasis'),
                            '5'          => esc_html__('5 columns', 'oasis'),
                            '6'          => esc_html__('6 columns', 'oasis')
                        ),
                        'default'   => 4,
                        'dependency' => array('show_related_product', '==', 'true'),
                    ),
                    array(
                        'id' => 'show_upsell_product',
                        'type' => 'switcher',
                        'title' => esc_html__('Show Upsell Product', 'oasis'),
                        'default' => true
                    ),
                    array(
                        'id' => 'upsell_product_columns',
                        'title' => esc_html__('Upsell Product Columns', 'oasis'),
                        'type' => 'select',
                        'options'        => array(
                            '1'          => esc_html__('1 column', 'oasis'),
                            '2'          => esc_html__('2 columns', 'oasis'),
                            '3'          => esc_html__('3 columns', 'oasis'),
                            '4'          => esc_html__('4 columns', 'oasis'),
                            '5'          => esc_html__('5 columns', 'oasis'),
                            '6'          => esc_html__('6 columns', 'oasis')
                        ),
                        'default'   => 4,
                        'dependency' => array('show_upsell_product', '==', 'true'),
                    ),
                    array(
                        'id' => 'show_custom_tab',
                        'type' => 'switcher',
                        'title' => esc_html__('Show Custom tab', 'oasis'),
                    ),
                    array(
                        'id' => 'product_custom_tab_title',
                        'type' => 'text',
                        'title' => esc_html__('Custom tab title', 'oasis'),
                        'default' => esc_html__('Custom tab title', 'oasis'),
                        'dependency' => array('show_custom_tab', '==', 'true')
                    ),
                    array(
                        'id' => 'product_custom_tab_content',
                        'type' => 'wysiwyg',
                        'title' => esc_html__('Custom tab content', 'oasis'),
                        'default' => esc_html__('Custom tab content', 'oasis'),
                        'dependency' => array('show_custom_tab', '==', 'true')
                    ),
                )
            ),
            /**
             * Shop Product Image & Zoom
             */
            array(
                'name' => 'section_shop_product_image_and_zoom',
                'title' => esc_html__('Product Image & Zoom', 'oasis'),
                'icon' => 'fa fa-search',
                'fields' => array(
                    array(
                        'type' => 'heading',
                        'content' => esc_html__('Product Image & Zoom', 'oasis'),
                    ),
                    array(
                        'id' => 'show_product_thumbnails',
                        'type' => 'switcher',
                        'title' => esc_html__('Show Thumbnails', 'oasis'),
                        'default' => true
                    ),
                    array(
                        'id' => 'enable_product_image_zoom',
                        'type' => 'switcher',
                        'title' => esc_html__('Enable Image Zoom', 'oasis'),
                        'default' => true
                    ),
                    array(
                        'id' => 'enable_product_image_popup',
                        'type' => 'switcher',
                        'title' => esc_html__('Enable Image Popup', 'oasis'),
                        'default' => true
                    ),
                    array(
                        'id' => 'product_image_zoom_type',
                        'type' => 'select',
                        'title' => esc_html__('Image Zoom Type', 'oasis'),
                        'options' => array(
                            'inner' => esc_html__('Inner', 'oasis'),
                            'lens' => esc_html__('Lens', 'oasis')
                        ),
                        'default' => 'inner',
                        'dependency' => array('enable_product_image_zoom', '==', 'true')
                    ),
                )
            ),
            /**
             * Shop cart page
             */
            array(
                'name' => 'section_shop_cart_page',
                'title' => esc_html__('Cart Page', 'oasis'),
                'icon' => 'fa fa-shopping-bag',
                'fields' => array(
                    array(
                        'type' => 'heading',
                        'content' => esc_html__('Cart Page', 'oasis'),
                    ),
                    array(
                        'id' => 'show_cross_sells',
                        'type' => 'switcher',
                        'title' => esc_html__('Show Cross Sells', 'oasis'),
                        'default' => true
                    ),
                    array(
                        'id' => 'cross_sells_columns',
                        'title' => esc_html__('Cross sells Columns', 'oasis'),
                        'type' => 'la_column_responsive',
                        'default' => array(
                            'xlg' => '3',
                            'lg' => '3',
                            'md' => '2',
                            'sm' => '2',
                            'xs' => '1',
                        ),
                        'dependency' => array('show_cross_sells', '==', 'true'),
                    )
                )
            ),
            /**
             * Shop Catalog Mode
             */
            array(
                'name' => 'section_shop_catalog_mode',
                'title' => esc_html__('Catalog Mode', 'oasis'),
                'icon' => 'fa fa-check',
                'fields' => array(
                    array(
                        'type' => 'heading',
                        'content' => esc_html__('Catalog Mode', 'oasis'),
                    ),
                    array(
                        'id' => 'enable_catalog_mode',
                        'type' => 'switcher',
                        'title' => esc_html__('Catalog Mode', 'oasis'),
                        'label' => esc_html__('When enabled, the feature Turns Off the shopping functionality of WooCommerce.', 'oasis'),
                    ),
                )
            )
        )
    );
}
/**
 * Portfolio
 */
$options[] = array(
    'name' => 'portfolio_settings',
    'title' => esc_html__('Portfolio', 'oasis'),
    'icon' => 'dashicons-before dashicons-portfolio',
    'sections' => array(
        /**
         * Portfolio Layout
         */
        array(
            'name' => 'section_portfolio_archive',
            'title' => esc_html__('Archive & Category', 'oasis'),
            'icon' => 'fa fa-cog',
            'fields' => array(
                array(
                    'type' => 'heading',
                    'content' => esc_html__('Display Setting', 'oasis'),
                ),
                array(
                    'id'           => 'portfolio_page_header_background',
                    'type'         => 'background',
                    'title'        => esc_html__('Page Header Background', 'oasis'),
                ),
                array(
                    'id' => 'portfolio_layout',
                    'type' => 'image_select',
                    'title' => esc_html__('Portfolio Layout', 'oasis'),
                    'radio' => true,
                    'options' => Oasis_Option_Config::mainLayout(true, true),
                    'default' => 'col-1c',
                ),
                array(
                    'id' => 'portfolio_main_full_width',
                    'type' => 'radio',
                    'title' => esc_html__('Enable Main FullWidth', 'oasis'),
                    'options' => Oasis_Option_Config::radioOption(),
                    'default' => 'inherit',
                ),
                array(
                    'id' => 'portfolio_style',
                    'type' => 'select',
                    'title' => esc_html__('Portfolio Style', 'oasis'),
                    'options' => array(
                        'grid' => esc_html__('Grid Style', 'oasis'),
                        'masonry' => esc_html__('Masonry Style', 'oasis')
                    ),
                    'default' => 'list'
                ),
                array(
                    'id' => 'portfolio_columns',
                    'title' => esc_html__('Portfolio Columns', 'oasis'),
                    'type' => 'la_column_responsive',
                    'default' => array(
                        'xlg' => '3',
                        'lg' => '3',
                        'md' => '2',
                        'sm' => '2',
                        'xs' => '1',
                    ),
                    'dependency' => array('portfolio_style', '!=', 'list'),
                ),
                array(
                    'id' => 'portfolio_thumbnail_size',
                    'type' => 'text',
                    'title' => esc_html__('Thumbnail Size', 'oasis'),
                    'after' => '<p class="cs-text-desc">' . esc_html__('Enter image size (Example: "thumbnail", "medium", "large", "full" or other sizes defined by theme). Alternatively enter size in pixels (Example: 200x100 (Width x Height)).', 'oasis') . '</p>',
                    'default' => 'thumbnail',
                )
            )
        ),
        array(
            'name' => 'section_portfolio_single',
            'title' => esc_html__('Single', 'oasis'),
            'icon' => 'fa fa-cog',
            'fields' => array(
                array(
                    'type' => 'heading',
                    'content' => esc_html__('Display Setting', 'oasis'),
                ),
                array(
                    'id' => 'single_portfolio_layout',
                    'type' => 'image_select',
                    'title' => esc_html__('Single Portfolio Layout', 'oasis'),
                    'radio' => true,
                    'options' => Oasis_Option_Config::mainLayout(true, true),
                    'default' => 'col-1c',
                ),

                array(
                    'id' => 'single_portfolio_style',
                    'type' => 'select',
                    'title' => esc_html__('Select Design', 'oasis'),
                    'options' => array(
                        'default'         => esc_html__('Default', 'oasis'),
                        'use_vc'    => esc_html__('Use Visual composer', 'oasis')
                    ),
                    'default' => 'default',
                )
            )
        ),
    )
);

/**
 * Social Share
 */
$options[] = array(
    'name' => 'social_share_settings',
    'title' => esc_html__('Social Share', 'oasis'),
    'icon' => 'fa fa-share',
    'fields' => array(
        array(
            'type' => 'heading',
            'content' => esc_html__('Social Share', 'oasis'),
        ),
        array(
            'id' => 'facebook_share',
            'type' => 'switcher',
            'title' => esc_html__('Facebook Share', 'oasis'),
            'default' => true
        ),
        array(
            'id' => 'twitter_share',
            'type' => 'switcher',
            'title' => esc_html__('Twitter Share', 'oasis'),
            'default' => true
        ),
        array(
            'id' => 'linkedin_share',
            'type' => 'switcher',
            'title' => esc_html__('Linked In Share', 'oasis'),
            'default' => true
        ),
        array(
            'id' => 'email_share',
            'type' => 'switcher',
            'title' => esc_html__('Email Share', 'oasis'),
            'default' => true
        ),
        array(
            'id' => 'pinterest_share',
            'type' => 'switcher',
            'title' => esc_html__('Pinterest Share', 'oasis'),
            'default' => true
        ),
        array(
            'id' => 'google_plus_share',
            'type' => 'switcher',
            'title' => esc_html__('Google Plus Share', 'oasis'),
            'default' => true
        ),
    )
);

/**
 * 404 Page
 */
$options[] = array(
    'name' => 'section_404',
    'title' => esc_html__('404 Page', 'oasis'),
    'icon' => 'fa fa-file-o',
    'fields' => array(
        array(
            'type' => 'heading',
            'content' => esc_html__('404 Page Settings', 'oasis'),
        ),
        array(
            'id' => '404_layout',
            'type' => 'image_select',
            'title' => esc_html__('Page Layout', 'oasis'),
            'radio' => true,
            'options' => Oasis_Option_Config::mainLayout(true, true),
            'default' => 'col-1c',
        ),
        array(
            'id'    => '404_page_content',
            'type'  => 'wysiwyg',
            'title' => esc_html__('Page Content', 'oasis'),
        )
    )
);

/**
 * Social Media
 */
$options[] = array(
    'name' => 'social_media_settings',
    'title' => esc_html__('Social Media', 'oasis'),
    'icon' => 'fa fa-share-alt',
    'fields' => array(
        array(
            'type' => 'heading',
            'content' => esc_html__('Social Media', 'oasis'),
        ),
        array(
            'id' => 'facebook_url',
            'type' => 'text',
            'desc' => esc_html__('Type your Facebook profile URL here.', 'oasis'),
            'title' => esc_html__('Facebook', 'oasis'),
            'default' => '#'
        ),
        array(
            'id' => 'twitter_url',
            'type' => 'text',
            'desc' => esc_html__('Type your Twitter profile URL here.', 'oasis'),
            'title' => esc_html__('Twitter', 'oasis'),
            'default' => '#'
        ),
        array(
            'id' => 'pinterest_url',
            'type' => 'text',
            'desc' => esc_html__('Type your Pinterest profile URL here.', 'oasis'),
            'title' => esc_html__('Pinterest', 'oasis'),
            'default' => '#'
        ),
        array(
            'id' => 'linkedin_url',
            'type' => 'text',
            'desc' => esc_html__('Type your LinkedIn profile URL here.', 'oasis'),
            'title' => esc_html__('LinkedIn', 'oasis'),
        ),
        array(
            'id' => 'google_plus_url',
            'type' => 'text',
            'desc' => esc_html__('Type your Google Plus profile URL here.', 'oasis'),
            'title' => esc_html__('Google +', 'oasis'),
        ),
        array(
            'id' => 'rss_url',
            'type' => 'text',
            'desc' => esc_html__('Type your RSS Feed URL here.', 'oasis'),
            'title' => esc_html__('RSS', 'oasis'),
        ),
        array(
            'id' => 'tumblr_url',
            'type' => 'text',
            'desc' => esc_html__('Type your Tumblr URL here.', 'oasis'),
            'title' => esc_html__('Tumblr', 'oasis'),
        ),
        array(
            'id' => 'instagram_url',
            'type' => 'text',
            'desc' => esc_html__('Type your Instagram URL here.', 'oasis'),
            'title' => esc_html__('Instagram', 'oasis'),
        ),
        array(
            'id' => 'youtube_url',
            'type' => 'text',
            'desc' => esc_html__('Type your Youtube URL here.', 'oasis'),
            'title' => esc_html__('Youtube', 'oasis'),
        ),
        array(
            'id' => 'vimeo_url',
            'type' => 'text',
            'desc' => esc_html__('Type your Vimeo URL here.', 'oasis'),
            'title' => esc_html__('Vimeo', 'oasis'),
        ),
        array(
            'id' => 'behance_url',
            'type' => 'text',
            'desc' => esc_html__('Type your Behance URL here.', 'oasis'),
            'title' => esc_html__('Behance', 'oasis'),
        ),
        array(
            'id' => 'dribble_url',
            'type' => 'text',
            'desc' => esc_html__('Type your Dribble URL here.', 'oasis'),
            'title' => esc_html__('Dribble', 'oasis'),
        ),
        array(
            'id' => 'flickr_url',
            'type' => 'text',
            'desc' => esc_html__('Type your Flickr URL here.', 'oasis'),
            'title' => esc_html__('Flickr', 'oasis'),
        ),
        array(
            'id' => 'git_url',
            'type' => 'text',
            'desc' => esc_html__('Type your Git URL here.', 'oasis'),
            'title' => esc_html__('Git', 'oasis'),
        ),
        array(
            'id' => 'skype_url',
            'type' => 'text',
            'desc' => esc_html__('Type your Skype URL here.', 'oasis'),
            'title' => esc_html__('Skype', 'oasis'),
        ),
        array(
            'id' => 'foursquare_url',
            'type' => 'text',
            'desc' => esc_html__('Type your Foursquare URL here.', 'oasis'),
            'title' => esc_html__('Foursquare', 'oasis'),
        ),
        array(
            'id' => 'soundcloud_url',
            'type' => 'text',
            'desc' => esc_html__('Type your Soundcloud URL here.', 'oasis'),
            'title' => esc_html__('Soundcloud', 'oasis'),
        ),
    )
);

/**
 * Custom Code
 */
$options[] = array(
    'name' => 'custom_code_settings',
    'title' => esc_html__('Custom Code', 'oasis'),
    'icon' => 'fa fa-code',
    'fields' => array(
        array(
            'type' => 'heading',
            'content' => esc_html__('Custom Code', 'oasis'),
        ),
        array(
            'id' => 'custom_css',
            'type' => 'la_ace_editor',
            'mode' => 'css',
            'theme' => 'monokai',
            'options' => array('minLines' => 12, 'maxLines' => 30),
            'before' => '<h4>' . esc_html__('Custom CSS', 'oasis') . '</h4>',
            'after' => esc_html__('Paste your custom CSS code here.', 'oasis')
        ),
        array(
            'id' => 'header_js',
            'type' => 'la_ace_editor',
            'mode' => 'javascript',
            'before' => '<h4>' . esc_html__('Header Javascript Code', 'oasis') . '</h4>',
            'after' => esc_html__('Paste your custom JS code here. The code will be added to the header of your site.', 'oasis')
        ),
        array(
            'id' => 'footer_js',
            'type' => 'la_ace_editor',
            'mode' => 'javascript',
            'before' => '<h4>' . esc_html__('Footer Javascript Code', 'oasis') . '</h4>',
            'after' => esc_html__('Paste your custom JS code here. The code will be added to the header of your site.', 'oasis')
        ),
    )
);

/**
 * Backup
 */
$options[] = array(
    'name' => 'backup_settings',
    'title' => esc_html__('Backup', 'oasis'),
    'icon' => 'fa fa-refresh',
    'fields' => array(
        array(
            'type' => 'heading',
            'content' => esc_html__('Backup', 'oasis'),
        ),
        array(
            'type' => 'backup',
            'title' => esc_html__('Backup Fields', 'oasis'),
        ),
    )
);

/**
 * Demo Importer
 */

$options[] = array(
    'name' => 'demo_import_settings',
    'title' => esc_html__('Demo Importer', 'oasis'),
    'icon' => 'fa fa-download',
    'fields' => array(
        array(
            'type' => 'heading',
            'content' => esc_html__('Demo Importer', 'oasis'),
        ),
        array(
            'id' => 'demo_importer',
            'type' => 'la_demo_importer',
            'demo' => apply_filters('oasis/filter/demo_data', array())
        ),
    )
);

CSFramework::instance($settings, $options);