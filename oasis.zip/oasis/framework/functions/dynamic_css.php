<?php
$body_font_family = "Raleway, sans-serif";
$heading_font_family = "Questrial, sans-serif";
$highlight_font_family = "Questrial, sans-serif";

switch (Oasis_Helper::getOption('font_source', '1')) {
    case '1':
        $main_font = Oasis_Helper::getOption('main_font');
        $secondary_font = Oasis_Helper::getOption('secondary_font');
        $highlight_font = Oasis_Helper::getOption('highlight_font');
        if (isset($main_font['family']) && !empty($main_font['family'])) {
            $body_font_family = $main_font['family'];
        }
        if (isset($secondary_font['family']) && !empty($secondary_font['family'])) {
            $heading_font_family = $secondary_font['family'];
        }
        if (isset($highlight_font['family']) && !empty($highlight_font['family'])) {
            $highlight_font_family = $highlight_font['family'];
        }
        break;
    case '2':
        $body_font_family = Oasis_Helper::getOption('main_google_font_face', $body_font_family);
        $heading_font_family = Oasis_Helper::getOption('secondary_google_font_face', $heading_font_family);
        $highlight_font_family = Oasis_Helper::getOption('highlight_google_font_face', $highlight_font_family);
        break;
    case '3':
        $body_font_family = Oasis_Helper::getOption('main_typekit_font_face', $body_font_family);
        $heading_font_family = Oasis_Helper::getOption('secondary_typekit_font_face', $heading_font_family);
        $highlight_font_family = Oasis_Helper::getOption('highlight_typekit_font_face', $highlight_font_family);
        break;
}

$body_background = shortcode_atts(array(
    'image' => '',
    'repeat' => 'repeat',
    'position' => 'left top',
    'attachment' => 'scroll',
    'size' => '',
    'color' => '#fff'
), Oasis_Helper::getOption('body_background'));

$header_background = shortcode_atts(array(
    'image' => '',
    'repeat' => 'repeat',
    'position' => 'left top',
    'attachment' => 'scroll',
    'size' => '',
    'color' => '#fff'
), Oasis_Helper::getOption('header_background'));

$header_transparency_background = shortcode_atts(array(
    'image' => '',
    'repeat' => 'repeat',
    'position' => 'left top',
    'attachment' => 'scroll',
    'size' => '',
    'color' => 'rgba(0, 0, 0, 0)'
), Oasis_Helper::getOption('header_transparency_background'));

$page_header_background = shortcode_atts(array(
    'image' => '',
    'repeat' => 'repeat',
    'position' => 'left top',
    'attachment' => 'scroll',
    'size' => '',
    'color' => ''
), Oasis_Helper::getPageHeaderBackgroundOpts());

$page_header_spacing = shortcode_atts(array(
    'top' => 70,
    'bottom' => 60,
), Oasis_Helper::getOption('page_header_spacing'));

$page_header_spacing_tablet = shortcode_atts(array(
    'top' => 70,
    'bottom' => 60,
), Oasis_Helper::getOption('page_header_spacing_tablet'));

$page_header_spacing_mobile = shortcode_atts(array(
    'top' => 40,
    'bottom' => 30,
), Oasis_Helper::getOption('page_header_spacing_mobile'));


$footer_background = shortcode_atts(array(
    'image' => '',
    'repeat' => 'repeat',
    'position' => 'left top',
    'attachment' => 'scroll',
    'size' => '',
    'color' => '#1d1f1f'
), Oasis_Helper::getOption('footer_background'));

if(Oasis_Helper::getOption('enable_catalog_mode', false)){
    echo '.header-toggle-cart { display: none !important }';
}

?>
.section-page-header {
    <?php
    Oasis_Helper::renderBackgroundProperty($page_header_background);
    ?>
}
.section-page-header .page-header-inner{
    padding-top: <?php echo absint($page_header_spacing_mobile['top']) ?>px;
    padding-bottom: <?php echo absint($page_header_spacing_mobile['bottom']) ?>px;
}
@media(min-width: 768px){
    .section-page-header .page-header-inner{
        padding-top: <?php echo absint($page_header_spacing_tablet['top']) ?>px;
        padding-bottom: <?php echo absint($page_header_spacing_tablet['bottom']) ?>px;
    }
}
@media(min-width: 992px){
    .section-page-header .page-header-inner{
        padding-top: <?php echo absint($page_header_spacing['top']) ?>px;
        padding-bottom: <?php echo absint($page_header_spacing['bottom']) ?>px;
    }
}


.site-header-mobile .site-header-inner,
#masthead_aside,
.site-header .site-header-inner {
    <?php
    Oasis_Helper::renderBackgroundProperty($header_background);
    ?>
}

.enable-header-transparency .site-header:not(.is-sticky) .site-header-inner {
    <?php
    Oasis_Helper::renderBackgroundProperty($header_transparency_background);
    ?>
}

/*--------------------------------------------------------------
@Package: Oasis SASS
@File: _settings.scss
---------------------------------------------------------------*/
/** Header top **/
/** End Header top **/
.item--category, .highlight-font-family {
    font-family: <?php echo esc_attr($highlight_font_family) ?>;
}

/*--------------------------------------------------------------
@Package: Oasis SASS
@File: site/_general.scss
---------------------------------------------------------------*/
body {
    font-family: <?php echo esc_attr($body_font_family) ?>;
    font-size: <?php echo esc_attr(Oasis_Helper::getOption("body_font_size", "14")) ?>px;
    color: <?php echo esc_attr(Oasis_Helper::getOption("text_color", "#727883")) ?>;
    <?php
    Oasis_Helper::renderBackgroundProperty($body_background);
    ?>
}

a:focus, a:hover {
    color: <?php echo esc_attr(Oasis_Helper::getOption("primary_color", "#ce1a2b")) ?>;
}

input, select, textarea {
    border-color: <?php echo esc_attr(Oasis_Helper::getOption("border_color", "rgba(169,174,189,0.30)")) ?>;
    padding: 10px 20px;
}

input:focus, select:focus, textarea:focus {
    border-color: <?php echo esc_attr(Oasis_Helper::getOption("secondary_color", "#2b2c30")) ?>;
}

.button,
button,
html input[type="button"],
input[type="reset"],
input[type="submit"],
.btn {
    background-color: #fff;
    color: <?php echo esc_attr(Oasis_Helper::getOption("secondary_color", "#2b2c30")) ?>;
    border-color: <?php echo esc_attr(Oasis_Helper::getOption("secondary_color", "#2b2c30")) ?>;
}

.button:hover,
button:hover,
html input[type="button"]:hover,
input[type="reset"]:hover,
input[type="submit"]:hover,
.btn:hover {
    background-color: <?php echo esc_attr(Oasis_Helper::getOption("secondary_color", "#2b2c30")) ?>;
    color: #fff;
}

.button.btn-secondary,
button.btn-secondary,
html input[type="button"].btn-secondary,
input[type="reset"].btn-secondary,
input[type="submit"].btn-secondary,
.btn.btn-secondary {
    background-color: <?php echo esc_attr(Oasis_Helper::getOption("secondary_color", "#2b2c30")) ?>;
    border-color: <?php echo esc_attr(Oasis_Helper::getOption("secondary_color", "#2b2c30")) ?>;
    color: #fff;
}

.button.btn-secondary:hover,
button.btn-secondary:hover,
html input[type="button"].btn-secondary:hover,
input[type="reset"].btn-secondary:hover,
input[type="submit"].btn-secondary:hover,
.btn.btn-secondary:hover {
    background-color: <?php echo esc_attr(Oasis_Helper::getOption("primary_color", "#ce1a2b")) ?>;
    border-color: <?php echo esc_attr(Oasis_Helper::getOption("primary_color", "#ce1a2b")) ?>;
    color: #fff;
}

.button.btn-primary,
button.btn-primary,
html input[type="button"].btn-primary,
input[type="reset"].btn-primary,
input[type="submit"].btn-primary,
.btn.btn-primary {
    background-color: <?php echo esc_attr(Oasis_Helper::getOption("primary_color", "#ce1a2b")) ?>;
    border-color: <?php echo esc_attr(Oasis_Helper::getOption("primary_color", "#ce1a2b")) ?>;
    color: #fff;
}

.button.btn-primary:hover,
button.btn-primary:hover,
html input[type="button"].btn-primary:hover,
input[type="reset"].btn-primary:hover,
input[type="submit"].btn-primary:hover,
.btn.btn-primary:hover {
    background-color: <?php echo esc_attr(Oasis_Helper::getOption("secondary_color", "#2b2c30")) ?>;
    border-color: <?php echo esc_attr(Oasis_Helper::getOption("secondary_color", "#2b2c30")) ?>;
    color: #fff;
}

.button.alt {
    background-color: <?php echo esc_attr(Oasis_Helper::getOption("secondary_color", "#2b2c30")) ?>;
    border-color: <?php echo esc_attr(Oasis_Helper::getOption("secondary_color", "#2b2c30")) ?>;
    color: #fff;
}

.button.alt:hover {
    background-color: <?php echo esc_attr(Oasis_Helper::getOption("primary_color", "#ce1a2b")) ?>;
    border-color: <?php echo esc_attr(Oasis_Helper::getOption("primary_color", "#ce1a2b")) ?>;
    color: #fff;
}

h1,
.h1, h2,
.h2, h3,
.h3, h4,
.h4, h5,
.h5, h6,
.h6 {
    font-family: <?php echo esc_attr($heading_font_family) ?>;
    color: <?php echo esc_attr(Oasis_Helper::getOption("heading_color", "#2b2c30")) ?>;
}

table th {
    color: <?php echo esc_attr(Oasis_Helper::getOption("heading_color", "#2b2c30")) ?>;
}

table,
table th,
table td {
    border-color: <?php echo esc_attr(Oasis_Helper::getOption("border_color", "rgba(169,174,189,0.30)")) ?>;
}

.star-rating {
    color: <?php echo esc_attr(Oasis_Helper::getOption("third_color", "#a9aebd")) ?>;
}

.star-rating span {
    color: <?php echo esc_attr(Oasis_Helper::getOption("secondary_color", "#2b2c30")) ?>;
}

.la-pagination ul .page-numbers {
    border-color: <?php echo esc_attr(Oasis_Helper::getOption("secondary_color", "#2b2c30")) ?>;
    color: <?php echo esc_attr(Oasis_Helper::getOption("secondary_color", "#2b2c30")) ?>;
}

.la-pagination ul .page-numbers.current, .la-pagination ul .page-numbers:hover {
    border-color: <?php echo esc_attr(Oasis_Helper::getOption("secondary_color", "#2b2c30")) ?>;
    color: #fff;
    background: <?php echo esc_attr(Oasis_Helper::getOption("secondary_color", "#2b2c30")) ?>;
}

.share-links a {
    border-color: <?php echo esc_attr(Oasis_Helper::getOption("border_color", "rgba(169,174,189,0.30)")) ?>;
}

.search-form .search-button:hover {
    color: <?php echo esc_attr(Oasis_Helper::getOption("primary_color", "#ce1a2b")) ?>;
}

.slick-slider button.slick-arrow:hover {
    background-color: <?php echo esc_attr(Oasis_Helper::getOption("primary_color", "#ce1a2b")) ?>;
    border-color: <?php echo esc_attr(Oasis_Helper::getOption("primary_color", "#ce1a2b")) ?>;
}

.slick-slider .slick-dots li:hover button,
.slick-slider .slick-dots .slick-active button {
    background-color: <?php echo esc_attr(Oasis_Helper::getOption("primary_color", "#ce1a2b")) ?>;
}

.vertical-style ul li:hover a, .vertical-style ul li.active a {
    color: <?php echo esc_attr(Oasis_Helper::getOption("primary_color", "#ce1a2b")) ?>;
}

.filter-style-default ul li:hover a, .filter-style-default ul li.active a {
    border-bottom-color: <?php echo esc_attr(Oasis_Helper::getOption("primary_color", "#ce1a2b")) ?>;
}

/*--------------------------------------------------------------
@Package: Oasis SASS
@File: site/header/_header.scss
---------------------------------------------------------------*/
.block-title-inside .la-contacts-item > span:first-child {
    font-family: <?php echo esc_attr($heading_font_family) ?>;
    color: <?php echo esc_attr(Oasis_Helper::getOption("heading_color", "#2b2c30")) ?>;
}

.top-area {
    background-color: #2b2c30;
    color: #a9aebd;
}

.top-area a {
    color: #696c75;
}

.top-area a:hover {
    color: #fff;
}

.header-toggle-cart .header_shopping_cart .buttons .wc-forward {
    color: <?php echo esc_attr(Oasis_Helper::getOption("secondary_color", "#2b2c30")) ?>;
}

.header-toggle-cart .header_shopping_cart .buttons .wc-forward:hover {
    color: <?php echo esc_attr(Oasis_Helper::getOption("primary_color", "#ce1a2b")) ?>;
}

.header-toggle-cart .header_shopping_cart .buttons .checkout {
    color: #fff;
    background: <?php echo esc_attr(Oasis_Helper::getOption("secondary_color", "#2b2c30")) ?>;
}

.header-toggle-cart .header_shopping_cart .buttons .checkout:hover {
    color: #fff;
    background-color: <?php echo esc_attr(Oasis_Helper::getOption("primary_color", "#ce1a2b")) ?>;
}

.site-header .header-search {
    color: <?php echo esc_attr(Oasis_Helper::getOption("header_text_color", "#303744")) ?>;
}

.site-header .btn-aside-toggle,
.site-header .header-toggle-cart > a,
.site-header .header-top-nav ul.menu > li > a {
    color: <?php echo esc_attr(Oasis_Helper::getOption("header_link_color", "#303744")) ?>;
}

.site-header .btn-aside-toggle:hover,
.site-header .btn-aside-toggle.active,
.site-header .header-toggle-cart.active > a,
.site-header .header-toggle-cart:hover > a,
.site-header .header-top-nav ul.menu > li:hover > a {
    color: <?php echo esc_attr(Oasis_Helper::getOption("header_link_hover_color", "#303744")) ?>;
}

.header-top-areas .header-search {
    color: <?php echo esc_attr(Oasis_Helper::getOption("header_text_color", "#303744")) ?>;
}

.header-top-areas .header-top-nav ul.menu > li > a,
.header-top-areas .header-toggle-cart > a {
    color: <?php echo esc_attr(Oasis_Helper::getOption("header_link_color", "#303744")) ?>;
}

.header-top-areas .header-top-nav ul.menu > li:hover > a,
.header-top-areas .header-toggle-cart.active > a,
.header-top-areas .header-toggle-cart:hover > a {
    color: <?php echo esc_attr(Oasis_Helper::getOption("header_link_hover_color", "#303744")) ?>;
}

/*--------------------------------------------------------------
@Package: Oasis SASS
@File: site/header/_header-1.scss
---------------------------------------------------------------*/
.header-v1 .header-bottom {
    border-top-color: <?php echo esc_attr(Oasis_Helper::getOption("border_color", "rgba(169,174,189,0.30)")) ?>;
    border-bottom-color: <?php echo esc_attr(Oasis_Helper::getOption("border_color", "rgba(169,174,189,0.30)")) ?>;
}
.header-v1 .header-bottom .mega-menu > li > a{
    color: <?php echo esc_attr(Oasis_Helper::getOption("mm_lv_1_color", "#2b2c30")) ?>;
    background-color: <?php echo esc_attr(Oasis_Helper::getOption("mm_lv_1_bg_color", "transparent")) ?>;
}
.header-v1 .header-bottom .mega-menu > li:hover > a{
    color: <?php echo esc_attr(Oasis_Helper::getOption("mm_lv_1_hover_color", "#ce1a2b")) ?>;
    background-color: <?php echo esc_attr(Oasis_Helper::getOption("mm_lv_1_hover_bg_color", "transparent")) ?>;
}
.header-v1 .header-bottom .mega-menu > li.active > a{
    color: <?php echo esc_attr(Oasis_Helper::getOption("mm_lv_1_active_color", "#ce1a2b")) ?>;
    background-color: <?php echo esc_attr(Oasis_Helper::getOption("mm_lv_1_active_bg_color", "transparent")) ?>;
}

/*--------------------------------------------------------------
@Package: Oasis SASS
@File: site/header/_header-2.scss
---------------------------------------------------------------*/
.header-v2 .header--aside .site-main-nav .mega-menu > li > a{
    color: <?php echo esc_attr(Oasis_Helper::getOption("mm_lv_1_color", "#2b2c30")) ?>;
    background-color: <?php echo esc_attr(Oasis_Helper::getOption("mm_lv_1_bg_color", "transparent")) ?>;
}
.header-v2 .header--aside .site-main-nav .mega-menu > li:hover > a{
    color: <?php echo esc_attr(Oasis_Helper::getOption("mm_lv_1_hover_color", "#ce1a2b")) ?>;
    background-color: <?php echo esc_attr(Oasis_Helper::getOption("mm_lv_1_hover_bg_color", "transparent")) ?>;
}
.header-v2 .header--aside .site-main-nav .mega-menu > li.active > a{
    color: <?php echo esc_attr(Oasis_Helper::getOption("mm_lv_1_active_color", "#ce1a2b")) ?>;
    background-color: <?php echo esc_attr(Oasis_Helper::getOption("mm_lv_1_active_bg_color", "transparent")) ?>;
}
/*--------------------------------------------------------------
@Package: Oasis SASS
@File: site/header/_header-3.scss
---------------------------------------------------------------*/
/*--------------------------------------------------------------
@Package: Oasis SASS
@File: site/header/_header-4.scss
---------------------------------------------------------------*/
.header-v4 .site-header .site-main-nav .mega-menu > li > a{
    color: <?php echo esc_attr(Oasis_Helper::getOption("mm_lv_1_color", "#2b2c30")) ?>;
    background-color: <?php echo esc_attr(Oasis_Helper::getOption("mm_lv_1_bg_color", "transparent")) ?>;
}
.header-v4 .site-header .site-main-nav .mega-menu > li:hover > a{
    color: <?php echo esc_attr(Oasis_Helper::getOption("mm_lv_1_hover_color", "#ce1a2b")) ?>;
    background-color: <?php echo esc_attr(Oasis_Helper::getOption("mm_lv_1_hover_bg_color", "transparent")) ?>;
}
.header-v4 .site-header .site-main-nav .mega-menu > li.active > a{
    color: <?php echo esc_attr(Oasis_Helper::getOption("mm_lv_1_active_color", "#ce1a2b")) ?>;
    background-color: <?php echo esc_attr(Oasis_Helper::getOption("mm_lv_1_active_bg_color", "transparent")) ?>;
}
/*--------------------------------------------------------------
@Package: Oasis SASS
@File: site/header/_header-5.scss
---------------------------------------------------------------*/
.header-v5 .header-main .header-search .search-button:hover {
    color: <?php echo esc_attr(Oasis_Helper::getOption("primary_color", "#ce1a2b")) ?>;
}

.header-v5 .site-category-nav .toggle-category-menu {
    background: <?php echo esc_attr(Oasis_Helper::getOption("primary_color", "#ce1a2b")) ?>;
}

.header-v5 .site-header .header-toggle-cart > a > i {
    color: <?php echo esc_attr(Oasis_Helper::getOption("primary_color", "#ce1a2b")) ?>;
}
.header-v5 .site-header .mega-menu > li > a{
    color: <?php echo esc_attr(Oasis_Helper::getOption("mm_lv_1_color", "#2b2c30")) ?>;
    background-color: <?php echo esc_attr(Oasis_Helper::getOption("mm_lv_1_bg_color", "transparent")) ?>;
}
.header-v5 .site-header .mega-menu > li:hover > a{
    color: <?php echo esc_attr(Oasis_Helper::getOption("mm_lv_1_hover_color", "#ce1a2b")) ?>;
    background-color: <?php echo esc_attr(Oasis_Helper::getOption("mm_lv_1_hover_bg_color", "transparent")) ?>;
}
.header-v5 .site-header .mega-menu > li.active > a{
    color: <?php echo esc_attr(Oasis_Helper::getOption("mm_lv_1_active_color", "#ce1a2b")) ?>;
    background-color: <?php echo esc_attr(Oasis_Helper::getOption("_mm_lv_1_active_bg_color", "transparent")) ?>;
}

.header-v5.enable-header-transparency .site-header:not(.is-sticky) .mega-menu > li > a{
    color: <?php echo esc_attr(Oasis_Helper::getOption("header_transparency_mm_lv_1_color", "#2b2c30")) ?>;
    background-color: <?php echo esc_attr(Oasis_Helper::getOption("header_transparency_mm_lv_1_bg_color", "transparent")) ?>;
}
.header-v5.enable-header-transparency .site-header:not(.is-sticky) .mega-menu > li:hover > a{
    color: <?php echo esc_attr(Oasis_Helper::getOption("header_transparency_mm_lv_1_hover_color", "#ce1a2b")) ?>;
    background-color: <?php echo esc_attr(Oasis_Helper::getOption("header_transparency_mm_lv_1_hover_bg_color", "transparent")) ?>;
}
.header-v5.enable-header-transparency .site-header:not(.is-sticky) .mega-menu > li.active > a{
    color: <?php echo esc_attr(Oasis_Helper::getOption("header_transparency_mm_lv_1_active_color", "#ce1a2b")) ?>;
    background-color: <?php echo esc_attr(Oasis_Helper::getOption("header_transparency_mm_lv_1_active_bg_color", "transparent")) ?>;
}
.header-v5 .site-category-nav .nav-inner{
    background: #1e1e21;
}
.header-v5 .site-header .site-category-nav .nav-inner .mega-menu > li > a{
    color: #ffffff;
}
.header-v5 .site-header .site-category-nav .nav-inner .mega-menu > li:hover > a{
    color: <?php echo esc_attr(Oasis_Helper::getOption("primary_color", "#ce1a2b")) ?>;
}
.header-v5 .site-header .site-category-nav .nav-inner .mega-menu > li.active > a{
    color: <?php echo esc_attr(Oasis_Helper::getOption("primary_color", "#ce1a2b")) ?>;
}


/*--------------------------------------------------------------
@Package: Oasis SASS
@File: site/header/_header-6.scss
---------------------------------------------------------------*/
.header-v6 .header-main .header-search .search-button {
    background: <?php echo esc_attr(Oasis_Helper::getOption("primary_color", "#ce1a2b")) ?>;
}

.header-v6 .header-main .header-search .search-button:hover {
    background-color: <?php echo esc_attr(Oasis_Helper::getOption("secondary_color", "#2b2c30")) ?>;
}

/*--------------------------------------------------------------
@Package: Oasis SASS
@File: site/header/_header-7.scss
---------------------------------------------------------------*/
/*--------------------------------------------------------------
@Package: Oasis SASS
@File: site/header/_header-transparency.scss
---------------------------------------------------------------*/
.enable-header-transparency .site-header:not(.is-sticky) .header-search {
    color: <?php echo esc_attr(Oasis_Helper::getOption("header_transparency_text_color", "#303744")) ?>;
}

.enable-header-transparency .site-header:not(.is-sticky) .btn-aside-toggle,
.enable-header-transparency .site-header:not(.is-sticky) .header-toggle-cart > a,
.enable-header-transparency .site-header:not(.is-sticky) .header-top-nav ul.menu > li > a {
    color: <?php echo esc_attr(Oasis_Helper::getOption("header_transparency_link_color", "#303744")) ?>;
}

.enable-header-transparency .site-header:not(.is-sticky) .btn-aside-toggle:hover,
.enable-header-transparency .site-header:not(.is-sticky) .btn-aside-toggle.active,
.enable-header-transparency .site-header:not(.is-sticky) .header-toggle-cart.active > a,
.enable-header-transparency .site-header:not(.is-sticky) .header-toggle-cart:hover > a,
.enable-header-transparency .site-header:not(.is-sticky) .header-top-nav ul.menu > li:hover > a {
    color: <?php echo esc_attr(Oasis_Helper::getOption("header_transparency_link_hover_color", "#303744")) ?>;
}

.enable-header-transparency .header-top-areas .header-search {
    color: <?php echo esc_attr(Oasis_Helper::getOption("header_transparency_text_color", "#303744")) ?>;
}

.enable-header-transparency .header-top-areas .header-top-nav ul.menu > li > a,
.enable-header-transparency .header-top-areas .header-toggle-cart > a {
    color: <?php echo esc_attr(Oasis_Helper::getOption("header_transparency_link_color", "#303744")) ?>;
}

.enable-header-transparency .header-top-areas .header-top-nav ul.menu > li:hover > a,
.enable-header-transparency .header-top-areas .header-toggle-cart.active > a,
.enable-header-transparency .header-top-areas .header-toggle-cart:hover > a {
    color: <?php echo esc_attr(Oasis_Helper::getOption("header_transparency_link_hover_color", "#303744")) ?>;
}

/*--------------------------------------------------------------
@Package: Oasis SASS
@File: site/header/_header-mobile.scss
---------------------------------------------------------------*/

.dl-menuwrapper ul {
    background: <?php echo esc_attr(Oasis_Helper::getOption("mb_background", "#fff")) ?>;
    border-color: <?php echo esc_attr(Oasis_Helper::getOption("border_color", "rgba(169,174,189,0.30)")) ?>;
}
.dl-menuwrapper li {
    border-top-color: <?php echo esc_attr(Oasis_Helper::getOption("border_color", "rgba(169,174,189,0.30)")) ?>;
}
.dl-menuwrapper li li > a{
    background-color: <?php echo esc_attr(Oasis_Helper::getOption("mb_lv_2_bg_color", "#f4f6f7")) ?>;
    color: <?php echo esc_attr(Oasis_Helper::getOption("mb_lv_2_color", "#727883")) ?>;
}
.dl-menuwrapper li li.active > a{
    background-color: <?php echo esc_attr(Oasis_Helper::getOption("mb_lv_2_hover_bg_color", "#f4f6f7")) ?>;
    color: <?php echo esc_attr(Oasis_Helper::getOption("mb_lv_2_hover_color", "#727883")) ?>;
}
.dl-menuwrapper li a{
    background-color: <?php echo esc_attr(Oasis_Helper::getOption("mb_lv_1_bg_color", "#f4f6f7")) ?>;
    color: <?php echo esc_attr(Oasis_Helper::getOption("mb_lv_1_color", "#727883")) ?>;
}
.dl-menuwrapper li.active > a{
    background-color: <?php echo esc_attr(Oasis_Helper::getOption("mb_lv_1_hover_bg_color", "#f4f6f7")) ?>;
    color: <?php echo esc_attr(Oasis_Helper::getOption("mb_lv_1_hover_color", "#727883")) ?>;
}
.site-header-mobile .header-main .search-form{
    border-color: <?php echo esc_attr(Oasis_Helper::getOption("border_color", "rgba(169,174,189,0.30)")) ?>;
    color: <?php echo esc_attr(Oasis_Helper::getOption("secondary_color", "#2b2c30")) ?>;
}
.site-header-mobile .btn-mobile-menu-trigger,
.site-header-mobile .header-toggle-cart > a{
    color: <?php echo esc_attr(Oasis_Helper::getOption("header_link_color", "#2b2c30")) ?>;
}
.site-header-mobile .btn-mobile-menu-trigger:hover,
.site-header-mobile .btn-mobile-menu-trigger.active,
.site-header-mobile .header-toggle-cart:hover > a{
    color: <?php echo esc_attr(Oasis_Helper::getOption("header_link_hover_color", "#303744")) ?>;
}

/*--------------------------------------------------------------
@Package: Oasis SASS
@File: site/_mega_menu.scss
---------------------------------------------------------------*/
.mega-menu .tip.hot,
.menu .tip.hot {
    background-color: <?php echo esc_attr(Oasis_Helper::getOption("primary_color", "#ce1a2b")) ?>;
}

.mega-menu .tip.hot .tip-arrow:before,
.menu .tip.hot .tip-arrow:before {
    color: <?php echo esc_attr(Oasis_Helper::getOption("primary_color", "#ce1a2b")) ?>;
}

.mega-menu .popup li > a {
    color: <?php echo esc_attr(Oasis_Helper::getOption("mm_dropdown_link_color", "#696c75")) ?>;
    background-color: <?php echo esc_attr(Oasis_Helper::getOption("mm_dropdown_link_bg", "rgba(0,0,0,0)")) ?>;
}

.mega-menu .popup li:hover > a {
    color: <?php echo esc_attr(Oasis_Helper::getOption("mm_dropdown_link_hover_color", "#2b2c30")) ?>;
    background-color: <?php echo esc_attr(Oasis_Helper::getOption("mm_dropdown_link_hover_bg", "rgba(0,0,0,0)")) ?>;
}

.mega-menu .popup li.active > a {
    color: <?php echo esc_attr(Oasis_Helper::getOption("mm_dropdown_link_hover_color", "#2b2c30")) ?>;
    background-color: <?php echo esc_attr(Oasis_Helper::getOption("mm_dropdown_link_hover_bg", "rgba(0,0,0,0)")) ?>;
}

.mega-menu .popup > .inner,
.mega-menu .mm-popup-wide .inner > ul.sub-menu > li li ul.sub-menu,
.mega-menu .mm-popup-narrow ul ul {
    background-color: <?php echo esc_attr(Oasis_Helper::getOption("mm_dropdown_bg", "#fff")) ?>;
}

.mega-menu .mm-popup-wide .inner > ul.sub-menu > li li li:hover > a,
.mega-menu .mm-popup-narrow li.menu-item:hover > a {
    color: <?php echo esc_attr(Oasis_Helper::getOption("mm_dropdown_link_hover_color", "#2b2c30")) ?>;
    background-color: <?php echo esc_attr(Oasis_Helper::getOption("mm_dropdown_link_hover_bg", "rgba(0,0,0,0)")) ?>;
}

.mega-menu .mm-popup-wide .inner > ul.sub-menu > li li li.active > a,
.mega-menu .mm-popup-narrow li.menu-item.active > a {
    color: <?php echo esc_attr(Oasis_Helper::getOption("mm_dropdown_link_hover_color", "#2b2c30")) ?>;
    background-color: <?php echo esc_attr(Oasis_Helper::getOption("mm_dropdown_link_hover_bg", "rgba(0,0,0,0)")) ?>;
}

.mega-menu .mm-popup-wide .inner > ul.sub-menu > li > a {
    color: <?php echo esc_attr(Oasis_Helper::getOption("mm_wide_dropdown_heading_color", "#2b2c30")) ?>;
}

/*--------------------------------------------------------------
@Package: Oasis SASS
@File: vendors/_dl_menu.scss
---------------------------------------------------------------*/
/*--------------------------------------------------------------
@Package: Oasis SASS
@File: site/_main.scss
---------------------------------------------------------------*/
/*--------------------------------------------------------------
@Package: Oasis SASS
@File: site/_sidebar.scss
---------------------------------------------------------------*/
.sidebar-inner .product-title,
.mini_cart_item a:not(.remove) {
    color: <?php echo esc_attr(Oasis_Helper::getOption("heading_color", "#2b2c30")) ?>;
    font-family: <?php echo esc_attr($heading_font_family) ?>;
}

/*--------------------------------------------------------------
@Package: Oasis SASS
@File: site/footer/_footer.scss
---------------------------------------------------------------*/
.site-footer {
    color: <?php echo esc_attr(Oasis_Helper::getOption("footer_text_color", "#9395a0")) ?>;
    <?php
    Oasis_Helper::renderBackgroundProperty($footer_background);
    ?>
}

.site-footer a {
    color: <?php echo esc_attr(Oasis_Helper::getOption("footer_link_color", "#9395a0")) ?>;
}

.site-footer a:hover {
    color: <?php echo esc_attr(Oasis_Helper::getOption("footer_link_hover_color", "#fff")) ?>;
}

.site-footer .widget .widget-title {
    color: <?php echo esc_attr(Oasis_Helper::getOption("footer_heading_color", "#fff")) ?>;
}

/*--------------------------------------------------------------
@Package: Oasis SASS
@File: site/_category_post.scss
---------------------------------------------------------------*/
.showposts-loop.showposts-loop-list-1col .link-readmore,
.showposts-list.loop-style-1 .link-readmore {
    color: <?php echo esc_attr(Oasis_Helper::getOption("heading_color", "#2b2c30")) ?>;
}

/*--------------------------------------------------------------
@Package: Oasis SASS
@File: site/_search_post.scss
---------------------------------------------------------------*/
/*--------------------------------------------------------------
@Package: Oasis SASS
@File: site/_single_post.scss
---------------------------------------------------------------*/
.tags-list a:hover {
    color: <?php echo esc_attr(Oasis_Helper::getOption("primary_color", "#ce1a2b")) ?>;
}

.item--category {
    color: <?php echo esc_attr(Oasis_Helper::getOption("third_color", "#a9aebd")) ?>;
}

.item--category a:hover {
    color: <?php echo esc_attr(Oasis_Helper::getOption("primary_color", "#ce1a2b")) ?>;
}

.entry-meta {
    color: <?php echo esc_attr(Oasis_Helper::getOption("third_color", "#a9aebd")) ?>;
}

.entry-meta a:hover {
    color: <?php echo esc_attr(Oasis_Helper::getOption("primary_color", "#ce1a2b")) ?>;
}

.btn-readmore {
    font-family: <?php echo esc_attr($heading_font_family) ?>;
    color: <?php echo esc_attr(Oasis_Helper::getOption("heading_color", "#2b2c30")) ?>;
}

.btn-readmore i {
    color: <?php echo esc_attr(Oasis_Helper::getOption("primary_color", "#ce1a2b")) ?>;
}

.author-info .author-bio {
    color: <?php echo esc_attr(Oasis_Helper::getOption("third_color", "#a9aebd")) ?>;
}

.post-navigation .post-title {
    color: <?php echo esc_attr(Oasis_Helper::getOption("heading_color", "#2b2c30")) ?>;
}

/*--------------------------------------------------------------
@Package: Oasis SASS
@File: site/_page.scss
---------------------------------------------------------------*/
/*--------------------------------------------------------------
@Package: Oasis SASS
@File: site/_comment.scss
---------------------------------------------------------------*/
.commentlist .comment-author {
    color: <?php echo esc_attr(Oasis_Helper::getOption("heading_color", "#2b2c30")) ?>;
}

.commentlist .meta {
    color: <?php echo esc_attr(Oasis_Helper::getOption("third_color", "#a9aebd")) ?>;
}

.commentlist .comment-reply-link {
    border-color: <?php echo esc_attr(Oasis_Helper::getOption("border_color", "rgba(169,174,189,0.30)")) ?>;
}

.wc-tab-content .commentlist .meta strong {
    color: <?php echo esc_attr(Oasis_Helper::getOption("heading_color", "#2b2c30")) ?>;
}

/*--------------------------------------------------------------
@Package: Oasis SASS
@File: site/_portfolio.scss
---------------------------------------------------------------*/
/*--------------------------------------------------------------
@Package: Oasis SASS
@File: shortcodes/_overrride.scss
---------------------------------------------------------------*/
.vc_btn3-container .vc_btn3 {
    text-align: center;
    max-width: 100%;
    overflow: hidden;
    line-height: inherit;
    color: #fff;
}

.vc_btn3-container .vc_btn3.vc_btn3-color-la-primary {
    background-color: <?php echo esc_attr(Oasis_Helper::getOption("primary_color", "#ce1a2b")) ?>;
    border-color: <?php echo esc_attr(Oasis_Helper::getOption("primary_color", "#ce1a2b")) ?>;
}

.vc_btn3-container .vc_btn3.vc_btn3-color-la-secondary {
    background-color: <?php echo esc_attr(Oasis_Helper::getOption("secondary_color", "#2b2c30")) ?>;
    border-color: <?php echo esc_attr(Oasis_Helper::getOption("secondary_color", "#2b2c30")) ?>;
}

.vc_btn3-container .vc_btn3.vc_btn3-color-la-white {
    color: <?php echo esc_attr(Oasis_Helper::getOption("secondary_color", "#2b2c30")) ?>;
}

.vc_btn3-container .vc_btn3.vc_btn3-color-la-transparent {
    color: <?php echo esc_attr(Oasis_Helper::getOption("secondary_color", "#2b2c30")) ?> !important;
    border-color: <?php echo esc_attr(Oasis_Helper::getOption("secondary_color", "#2b2c30")) ?> !important;
}

.vc_btn3-container .vc_btn3.vc_btn3-color-la-transparent:hover {
    background-color: <?php echo esc_attr(Oasis_Helper::getOption("primary_color", "#ce1a2b")) ?>;
    color: #fff !important;
    border-color: <?php echo esc_attr(Oasis_Helper::getOption("primary_color", "#ce1a2b")) ?> !important;
}

.vc_btn3-container .vc_general.vc_btn3:hover {
    background-color: <?php echo esc_attr(Oasis_Helper::getOption("primary_color", "#ce1a2b")) ?>;
    border-color: <?php echo esc_attr(Oasis_Helper::getOption("primary_color", "#ce1a2b")) ?>;
    color: #fff;
}

.social-media-link.style-round a, .social-media-link.style-square a, .social-media-link.style-circle a {
    background-color: <?php echo esc_attr(Oasis_Helper::getOption("secondary_color", "#2b2c30")) ?>;
}

.social-media-link.style-round a:hover, .social-media-link.style-square a:hover, .social-media-link.style-circle a:hover {
    background-color: <?php echo esc_attr(Oasis_Helper::getOption("primary_color", "#ce1a2b")) ?>;
}

/*--------------------------------------------------------------
@Package: Oasis SASS
@File: shortcodes/_heading.scss
---------------------------------------------------------------*/
/*--------------------------------------------------------------
@Package: Oasis SASS
@File: shortcodes/_team_member.scss
---------------------------------------------------------------*/
.loop-style-3 .team-member-item .item--title a {
    color: <?php echo esc_attr(Oasis_Helper::getOption("primary_color", "#ce1a2b")) ?>;
}

.loop-style-3 .team-member-item .item--social a:hover {
    color: <?php echo esc_attr(Oasis_Helper::getOption("primary_color", "#ce1a2b")) ?>;
}

.loop-style-4 .team-member-item .item--social {
    background-color: <?php echo esc_attr(Oasis_Helper::getOption("primary_color", "#ce1a2b")) ?>;
}

.loop-style-4 .team-member-item .item--title:before {
    border-top-color: <?php echo esc_attr(Oasis_Helper::getOption("primary_color", "#ce1a2b")) ?>;
}

/*--------------------------------------------------------------
@Package: Oasis SASS
@File: shortcodes/_banner.scss
---------------------------------------------------------------*/
/*--------------------------------------------------------------
@Package: Oasis SASS
@File: shortcodes/_tabs.scss
---------------------------------------------------------------*/
.vc_tta[class*="tabs-la-"] .vc_tta-tabs-list li.vc_active a {
    color: <?php echo esc_attr(Oasis_Helper::getOption("primary_color", "#ce1a2b")) ?>;
}

.vc_tta.tabs-la-2 .vc_tta-tabs-list {
    border-bottom-color: 1px solid <?php echo esc_attr(Oasis_Helper::getOption("border_color", "rgba(169,174,189,0.30)")) ?>;
}

/*--------------------------------------------------------------
@Package: Oasis SASS
@File: shortcodes/_testimonial.scss
---------------------------------------------------------------*/
/*--------------------------------------------------------------
@Package: Oasis SASS
@File: shortcodes/_icon_box.scss
---------------------------------------------------------------*/
.la-sc-icon-boxes .box-icon-style-simple {
    color: <?php echo esc_attr(Oasis_Helper::getOption("primary_color", "#ce1a2b")) ?>;
}

.la-sc-icon-boxes .box-icon-style-square,
.la-sc-icon-boxes .box-icon-style-circle,
.la-sc-icon-boxes .box-icon-style-round {
    background-color: <?php echo esc_attr(Oasis_Helper::getOption("primary_color", "#ce1a2b")) ?>;
}

/*--------------------------------------------------------------
@Package: Oasis SASS
@File: shortcodes/_showposts.scss
---------------------------------------------------------------*/
/*--------------------------------------------------------------
@Package: Oasis SASS
@File: shortcodes/_maps.scss
---------------------------------------------------------------*/
/*--------------------------------------------------------------
@Package: Oasis SASS
@File: shortcodes/_contact_form_7.scss
---------------------------------------------------------------*/
.subscribe-form .field-submit .wpcf7-submit {
    background: <?php echo esc_attr(Oasis_Helper::getOption("secondary_color", "#2b2c30")) ?>;
}

/*--------------------------------------------------------------
@Package: Oasis SASS
@File: shortcodes/_show_portfolios.scss
---------------------------------------------------------------*/
/*--------------------------------------------------------------
@Package: Oasis SASS
@File: shortcodes/_cta.scss
---------------------------------------------------------------*/
/*--------------------------------------------------------------
@Package: Oasis SASS
@File: shortcodes/_countdown.scss
---------------------------------------------------------------*/
/*--------------------------------------------------------------
@Package: Oasis SASS
@File: shortcodes/_progress_bar.scss
---------------------------------------------------------------*/
/*--------------------------------------------------------------
@Package: Oasis SASS
@File: shortcodes/_stats_counter.scss
---------------------------------------------------------------*/
/*--------------------------------------------------------------
@Package: Oasis SASS
@File: shortcodes/_accordion.scss
---------------------------------------------------------------*/
.vc_tta.vc_tta-accordion.vc_tta-style-la-1 .vc_tta-panel-title {
    border-bottom-color: <?php echo esc_attr(Oasis_Helper::getOption("border_color", "rgba(169,174,189,0.30)")) ?>;
}

.vc_tta.vc_tta-accordion.vc_tta-style-la-2 .vc_tta-panel.vc_active .vc_tta-panel-title {
    color: <?php echo esc_attr(Oasis_Helper::getOption("primary_color", "#ce1a2b")) ?>;
}

/*--------------------------------------------------------------
@Package: Oasis SASS
@File: shortcodes/_pricing_table.scss
---------------------------------------------------------------*/
.la-pricing-table .wrap-icon .icon-inner {
    color: <?php echo esc_attr(Oasis_Helper::getOption("primary_color", "#ce1a2b")) ?>;
}

.la-pricing-table .price-box .price-value {
    color: <?php echo esc_attr(Oasis_Helper::getOption("heading_color", "#2b2c30")) ?>;
}

.la-pricing-table .package-featured li strong {
    color: <?php echo esc_attr(Oasis_Helper::getOption("heading_color", "#2b2c30")) ?>;
}

.la-pricing-table-wrap.style-1 .pricing-heading {
    color: <?php echo esc_attr(Oasis_Helper::getOption("primary_color", "#ce1a2b")) ?>;
}

.la-pricing-table-wrap.style-1 .package-featured li {
    border-top-color: <?php echo esc_attr(Oasis_Helper::getOption("border_color", "rgba(169,174,189,0.30)")) ?>;
}

.la-pricing-table-wrap.style-1 .pricing-action a {
    color: <?php echo esc_attr(Oasis_Helper::getOption("primary_color", "#ce1a2b")) ?>;
}

.la-pricing-table-wrap.style-1 .pricing-action a:hover {
    background-color: <?php echo esc_attr(Oasis_Helper::getOption("primary_color", "#ce1a2b")) ?>;
    border-color: <?php echo esc_attr(Oasis_Helper::getOption("primary_color", "#ce1a2b")) ?>;
}

.la-pricing-table-wrap.style-1.is_box_featured .pricing-action a {
    background-color: <?php echo esc_attr(Oasis_Helper::getOption("primary_color", "#ce1a2b")) ?>;
    border-color: <?php echo esc_attr(Oasis_Helper::getOption("primary_color", "#ce1a2b")) ?>;
}

.la-pricing-table-wrap.style-2 .la-pricing-table {
    border-color: <?php echo esc_attr(Oasis_Helper::getOption("border_color", "rgba(169,174,189,0.30)")) ?>;
}

.la-pricing-table-wrap.style-2 .la-pricing-table .pricing-heading {
    background-color: <?php echo esc_attr(Oasis_Helper::getOption("primary_color", "#ce1a2b")) ?>;
}

.la-pricing-table-wrap.style-2 .la-pricing-table .wrap-icon .icon-inner {
    color: <?php echo esc_attr(Oasis_Helper::getOption("primary_color", "#ce1a2b")) ?>;
}

.la-pricing-table-wrap.style-2 .la-pricing-table .pricing-action {
    background-color: <?php echo esc_attr(Oasis_Helper::getOption("primary_color", "#ce1a2b")) ?>;
}

/*--------------------------------------------------------------
@Package: Oasis SASS
@File: shortcodes/_timeline.scss
---------------------------------------------------------------*/
/*--------------------------------------------------------------
@Package: Oasis SASS
@File: site/_extra_class.scss
---------------------------------------------------------------*/
.item--overlay {
    background-color: <?php echo esc_attr(Oasis_Helper::getOption("primary_color", "#ce1a2b")) ?>;
}

.three-text-color,
.text-color-highlight,
.highlight-text-color {
    color: <?php echo esc_attr(Oasis_Helper::getOption("third_color", "#a9aebd")) ?> !important;
}

.text-color-heading {
    color: <?php echo esc_attr(Oasis_Helper::getOption("heading_color", "#2b2c30")) ?> !important;
}

.text-color-primary {
    color: <?php echo esc_attr(Oasis_Helper::getOption("primary_color", "#ce1a2b")) ?> !important;
}

/*--------------------------------------------------------------
@Package: Oasis SASS
@File: _colors.scss
---------------------------------------------------------------*/
/*--------------------------------------------------------------
@Package: Oasis SASS
@File: woocommerce/_wooecommerce.scss
---------------------------------------------------------------*/
.select2-container .select2-choice,
.select2-search,
.select2-dropdown-open.select2-drop-above .select2-choice,
.select2-dropdown-open.select2-drop-above .select2-choices,
.select2-drop.select2-drop-active,
.select2-input,
.input-text {
    border-color: <?php echo esc_attr(Oasis_Helper::getOption("border_color", "rgba(169,174,189,0.30)")) ?>;
}

.stars [class*="star-"]:hover, .stars [class*="star-"].active {
    color: <?php echo esc_attr(Oasis_Helper::getOption("primary_color", "#ce1a2b")) ?>;
}

.onsale,
.onsale-badge {
    background: <?php echo esc_attr(Oasis_Helper::getOption("primary_color", "#ce1a2b")) ?>;
}

.wc-toolbar .wc-view-toggle .active {
    color: <?php echo esc_attr(Oasis_Helper::getOption("primary_color", "#ce1a2b")) ?>;
}

.wc-toolbar .wc-toolbar-left .wc-ordering {
    border-color: <?php echo esc_attr(Oasis_Helper::getOption("border_color", "rgba(169,174,189,0.30)")) ?>;
}

.wc-ordering ul {
    border-color: <?php echo esc_attr(Oasis_Helper::getOption("border_color", "rgba(169,174,189,0.30)")) ?>;
}

.wc-ordering ul li:hover a, .wc-ordering ul li.active a {
    background-color: <?php echo esc_attr(Oasis_Helper::getOption("primary_color", "#ce1a2b")) ?>;
}

.wc-tabs {
    font-family: <?php echo esc_attr($heading_font_family) ?>;
}

.wc-tabs .active a {
    color: <?php echo esc_attr(Oasis_Helper::getOption("secondary_color", "#2b2c30")) ?>;
    border-color: <?php echo esc_attr(Oasis_Helper::getOption("secondary_color", "#2b2c30")) ?>;
}

/*--------------------------------------------------------------
@Package: Oasis SASS
@File: woocommerce/_category_product.scss
---------------------------------------------------------------*/
.product-item .button:hover {
    color: <?php echo esc_attr(Oasis_Helper::getOption("primary_color", "#ce1a2b")) ?>;
}

.product-item .button,
.product-item .added_to_cart {
    color: <?php echo esc_attr(Oasis_Helper::getOption("secondary_color", "#2b2c30")) ?>;
}

.product-item .button:hover,
.product-item .added_to_cart:hover {
    color: <?php echo esc_attr(Oasis_Helper::getOption("primary_color", "#ce1a2b")) ?>;
}

.product-item .price {
    color: <?php echo esc_attr(Oasis_Helper::getOption("secondary_color", "#2b2c30")) ?>;
}

.products.products-list.products-list-book .product-item .product--action {
    border-top: 1px solid #eaeaed;
}

.products.products-list.products-list-book .product-item .product--action a:last-child {
    background-color: <?php echo esc_attr(Oasis_Helper::getOption("primary_color", "#ce1a2b")) ?>;
    border-color: <?php echo esc_attr(Oasis_Helper::getOption("primary_color", "#ce1a2b")) ?>;
}

/*--------------------------------------------------------------
@Package: Oasis SASS
@File: woocommerce/_search_product.scss
---------------------------------------------------------------*/
/*--------------------------------------------------------------
@Package: Oasis SASS
@File: woocommerce/_single_product.scss
---------------------------------------------------------------*/
.product--thumbnails .slick-current img {
    border-color: <?php echo esc_attr(Oasis_Helper::getOption("border_color", "rgba(169,174,189,0.30)")) ?>;
}

.product--summary .price {
    color: <?php echo esc_attr(Oasis_Helper::getOption("secondary_color", "#2b2c30")) ?>;
    font-family: <?php echo esc_attr($heading_font_family) ?>;
}

.product--summary .variations label,
.product--summary .product_meta label {
    color: <?php echo esc_attr(Oasis_Helper::getOption("heading_color", "#2b2c30")) ?>;
}

.product-single-design-3 .design-03-row-02 .product_meta label {
    color: <?php echo esc_attr(Oasis_Helper::getOption("heading_color", "#2b2c30")) ?>;
}

/*--------------------------------------------------------------
@Package: Oasis SASS
@File: woocommerce/_cart.scss
---------------------------------------------------------------*/
.shop_table.cart th {
    color: <?php echo esc_attr(Oasis_Helper::getOption("third_color", "#a9aebd")) ?>;
}

td.actions .coupon {
    border-color: <?php echo esc_attr(Oasis_Helper::getOption("border_color", "rgba(169,174,189,0.30)")) ?>;
}

/*--------------------------------------------------------------
@Package: Oasis SASS
@File: woocommerce/_checkout.scss
---------------------------------------------------------------*/
/*--------------------------------------------------------------
@Package: Oasis SASS
@File: woocommerce/_my_account.scss
---------------------------------------------------------------*/
.woocommerce-MyAccount-navigation li.is-active a {
    color: <?php echo esc_attr(Oasis_Helper::getOption("primary_color", "#ce1a2b")) ?>;
}

.custom-header-top-text{
    background-color: <?php echo esc_attr(Oasis_Helper::getOption("header_top_custom_bg", "#fff")) ?>;
    color: <?php echo esc_attr(Oasis_Helper::getOption("header_top_custom_color", "#252634")) ?>;
}
