<?php if ( ! defined( 'ABSPATH' ) ) { die; }

add_action('oasis/action/before_main_loop', 'oasis_create_variable_main_loop', 1 );
add_action('oasis/action/before_main_loop', 'oasis_action_before_main_loop', 10 );
add_action('oasis/action/after_main_loop', 'oasis_action_after_main_loop', 10 );
add_action('oasis/action/after_main_loop', 'oasis_reset_variable_main_loop', 99 );


add_action('oasis/action/before_portfolio_loop', 'oasis_create_variable_portfolio_loop', 1 );
add_action('oasis/action/after_portfolio_loop', 'oasis_reset_variable_portfolio_loop', 99 );

add_action('oasis/action/before_portfolio_loop', 'oasis_action_before_portfolio_loop', 10 );
add_action('oasis/action/after_portfolio_loop', 'oasis_action_after_portfolio_loop', 10 );

if(!function_exists('oasis_create_variable_main_loop')){
    function oasis_create_variable_main_loop(){
        global $oasis_loop;
        $oasis_loop['blog_style'] = Oasis_Helper::getOption('blog_style', 'grid-3col');
        $blog_show_postformat = Oasis_Helper::getOption('blog_show_postformat', false);
        $oasis_loop['blog_show_postformat'] = ($blog_show_postformat == 'yes' ? true : false);
        $oasis_loop['excerpt_length'] = Oasis_Helper::getOption('blog_excerpt_length', 5);
    }
}

if(!function_exists('oasis_reset_variable_main_loop')){
    function oasis_reset_variable_main_loop(){
        global $oasis_loop;
        $oasis_loop = '';
    }
}

if(!function_exists('oasis_custom_excerpt_length')){
    function oasis_custom_excerpt_length($length){
        global $oasis_custom_excerpt_length;
        if(isset($oasis_custom_excerpt_length) && !empty($oasis_custom_excerpt_length)){
            $length = absint($oasis_custom_excerpt_length);
        }
        return $length;
    }
}

if(!function_exists('oasis_action_before_main_loop')){
    function oasis_action_before_main_loop(){
        global $oasis_loop;

        $blog_style = isset($oasis_loop['blog_style']) ? $oasis_loop['blog_style'] : 'grid-3col';
        $loopCssClass = array('la-loop','showposts-loop');
        $loopCssClass[] = "blog-main-loop showposts-loop-{$blog_style}";
        if(false !== strpos($blog_style, 'grid') || false !== strpos($blog_style, 'pinterest')){
            preg_match('/\d+/', $blog_style, $matches);
            if(!empty($matches[0])){
                switch($matches[0]){
                    case 1:
                        $blog_col = array('xlg'=> 1, 'lg'=> 1,'md'=> 1,'sm'=> 1,'xs'=> 1);
                        break;

                    case 2:
                        $blog_col = array('xlg'=> 2, 'lg'=> 2,'md'=> 2,'sm'=> 1,'xs'=> 1);
                        break;

                    case 3:
                        $blog_col = array('xlg'=> 3, 'lg'=> 3,'md'=> 2,'sm'=> 2,'xs'=> 1);
                        break;

                    case 4:
                        $blog_col = array('xlg'=> 4, 'lg'=> 4,'md'=> 3,'sm'=> 2,'xs'=> 1);
                        break;

                    case 5:
                        $blog_col = array('xlg'=> 5, 'lg'=> 5,'md'=> 4,'sm'=> 2,'xs'=> 1);
                        break;

                    case 6:
                        $blog_col = array('xlg'=> 6, 'lg'=> 6,'md'=> 4,'sm'=> 2,'xs'=> 1);
                        break;

                    default:
                        $blog_col = array('xlg'=> 1, 'lg'=> 1,'md'=> 1,'sm'=> 1,'xs'=> 1);
                }
            }
            else{
                $blog_col = array('xlg'=> 1, 'lg'=> 1,'md'=> 1,'sm'=> 1,'xs'=> 1);
            }
            $loopCssClass[] = 'grid-items la-isotope-container';
            foreach( $blog_col as $screen => $value ){
                $loopCssClass[]  =  sprintf('%s-grid-%s-items', $screen, $value);
            }
        }

        if(isset($oasis_loop['excerpt_length']) && !empty($oasis_loop['excerpt_length'])){
            global $oasis_custom_excerpt_length;
            $oasis_custom_excerpt_length = absint($oasis_loop['excerpt_length']);
            add_filter( 'excerpt_length', 'oasis_custom_excerpt_length', 1001 );
        }
        printf('<div class="%s" data-item_selector=".post-item">',
            esc_attr(implode(' ', $loopCssClass))
        );
    }
}

if(!function_exists('oasis_action_after_main_loop')){
    function oasis_action_after_main_loop(){
        global $oasis_loop;
        if(isset($oasis_loop['excerpt_length']) && !empty($oasis_loop['excerpt_length']) ){
            remove_all_filters('excerpt_length', 1001);
        }
        printf('</div>');
    }
}


if(!function_exists('oasis_create_variable_portfolio_loop')){
    function oasis_create_variable_portfolio_loop(){
        global $oasis_loop;
        $oasis_loop['loop_id'] = 'page_archive_portfolios';
        $oasis_loop['loop_style'] = 1;
        $oasis_loop['responsive_column'] = shortcode_atts(array('xlg'=> 1, 'lg'=> 1,'md'=> 1,'sm'=> 1,'xs'=> 1), Oasis_Helper::getOption('portfolio_columns'));
        $oasis_loop['image_size'] = Oasis_Helper::getImageSizeFormString(Oasis_Helper::getOption('portfolio_thumbnail_size', 'thumbnail'));

        if(Oasis_Helper::getOption('enable_portfolio_masonry')){
            $oasis_loop['loop_layout'] = 'masonry';
        }else{
            $oasis_loop['loop_layout'] = 'grid';
        }
    }
}

if(!function_exists('oasis_reset_variable_portfolio_loop')){
    function oasis_reset_variable_portfolio_loop(){
        global $oasis_loop;
        $oasis_loop = '';
    }
}

if(!function_exists('oasis_action_before_portfolio_loop')){
    function oasis_action_before_portfolio_loop(){
        global $oasis_loop;
        $loop_id = isset($oasis_loop['loop_id']) ? $oasis_loop['loop_id'] : 'page_archive_portfolios';
        $loop_class = array();
        if(Oasis_Helper::getOption('portfolio_style') == 'no-padding'){
            $loop_class[] = 'grid-item-no-padding';
        }
        printf(
            '<div id="%s" class="%s">',
            esc_attr($loop_id),
            esc_attr(implode(' ', $loop_class))
        );

        if(!is_tax('la_portfolio_skill') && Oasis_Helper::getOption('enable_portfolio_masonry') && Oasis_Helper::getOption('enable_portfolio_masonry_filter')){
            $filters = Oasis_Helper::getOption('portfolio_skill_filters', array());
            if(!empty($filters) && is_array($filters)){
                ?>
                <div class="la-isotope-filter-container filter-style-default" data-isotope_container="#<?php echo esc_attr($loop_id) ?> .la-isotope-container">
                    <div class="la-toggle-filter"><?php esc_html_e('All','oasis')?></div>
                    <ul>
                        <li class="active" data-filter="*"><a href="#"><?php esc_html_e('All','oasis')?></a></li>
                        <?php foreach($filters as $filter){
                            $category = get_term(isset($filter['category']) ? $filter['category'] : $filter,'la_portfolio_skill');
                            if($category){
                                ?>
                                <li data-filter="la_portfolio_skill-<?php echo esc_attr($category->slug)?>"><a href="#"><?php echo esc_html($category->name);?></a></li>
                                <?php
                            }
                        }
                        ?>
                    </ul>
                </div>
<?php
            }
        }

    }
}

if(!function_exists('oasis_action_after_portfolio_loop')){
    function oasis_action_after_portfolio_loop(){
        echo '</div>';
    }
}