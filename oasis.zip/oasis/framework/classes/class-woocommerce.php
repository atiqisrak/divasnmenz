<?php if ( ! defined( 'ABSPATH' ) ) { die; }

if(!class_exists('Oasis_Woocommerce')){

    class Oasis_Woocommerce {

        private static $instance = null;

        public static function instance(){
            if (null === static::$instance) {
                static::$instance = new static();
            }
            return static::$instance;
        }

        protected function __construct(){

            if(!class_exists('WooCommerce')) return;

            add_filter('oasis/filter/site_layout', array( $this, 'setSiteLayout') );
            add_action('wp_head', array( $this, 'overridePageHeader' ) );
            add_action('init', array( $this, 'setCookieDefault' ), 1 );
            add_action('init', array( $this, 'emptyCart' ), 1 );

            add_filter('body_class', array( $this, 'addBodyClass' ), 999 );
            add_filter('woocommerce_add_to_cart_fragments', array( $this, 'modifyCartAjaxResponse'));

            /**
             * In Plugin
             */
            add_filter('woocommerce_show_page_title', '__return_false');
            add_action('woocommerce_after_single_product', array( $this, 'addScriptToQuickview'));
            add_action('yith_woocompare_after_main_table', array( $this, 'addScriptToCompare'));
            add_action('init', array( $this, 'disableYithHooks'));

            add_filter('woocommerce_placeholder_img_src', array( $this, 'modifyPlaceholder') );
            /**
             * In Loop
             */
            remove_action('woocommerce_before_shop_loop', 'woocommerce_catalog_ordering', 30);
            remove_action('woocommerce_before_shop_loop', 'woocommerce_result_count', 20);

            remove_action('woocommerce_before_shop_loop_item', 'woocommerce_template_loop_product_link_open', 10);
            remove_action('woocommerce_after_shop_loop_item', 'woocommerce_template_loop_product_link_close', 5);
            remove_action('woocommerce_after_shop_loop_item', 'woocommerce_template_loop_add_to_cart', 10);
            remove_action('woocommerce_shop_loop_item_title', 'woocommerce_template_loop_product_title', 10);

            add_filter('single_product_archive_thumbnail_size', array( $this, 'modifyProductThumbnailSize') );

            add_filter('loop_shop_per_page', array($this,'changePerPageDefault'));
            add_action('oasis/action/before_render_main', array( $this, 'renderToolbar') );

            add_filter('post_class', array( $this, 'addPostClassToLoop'), 30, 3 );
            add_action('woocommerce_before_shop_loop_item_title', array( $this, 'addScriptResizeImageInLoop' ), 1 );
            add_action('woocommerce_before_shop_loop_item_title', array( $this, 'removeScriptResizeImageInLoop' ), 100 );
            add_action('woocommerce_before_shop_loop_item_title', array( $this, 'addBadgeStockInProduct' ), 9 );
            add_action('woocommerce_before_shop_loop_item_title', array( $this, 'addSecondProductThumbnailToLoop' ), 10 );
            add_action('woocommerce_shop_loop_item_title', array( $this, 'renderLoopItemTitle' ), 10 );
            add_action('woocommerce_after_shop_loop_item_title', array( $this, 'renderLoopItemExcerpt' ), 15 );

            if(Oasis_Helper::getOption('show_quick_view_btn')){
                add_action('oasis_shop_loop_item_action', array( $this, 'renderBtnQuickview' ), 10 );
            }
            if(Oasis_Helper::getOption('show_wishlist_btn')){
                add_action('oasis_shop_loop_item_action', array( $this, 'renderBtnWishlist' ), 15 );
            }

            add_action('oasis_shop_loop_item_action', 'woocommerce_template_loop_add_to_cart', 20 );

            /**
             * Product Page
             */
            add_action('woocommerce_before_single_product_summary', array( $this, 'addBadgeStockInProduct' ), 9 );

            add_action('wp_head', array($this, 'checkConditionShowUpsellAndCrosssell'));
            remove_action('woocommerce_single_product_summary', 'woocommerce_template_single_meta', 40);
            add_action('woocommerce_single_product_summary', 'woocommerce_template_single_meta', 10);

            add_action('woocommerce_share', 'oasis_social_sharing');
            add_filter('woocommerce_product_description_heading', '__return_empty_string');
            add_filter('woocommerce_product_additional_information_heading', '__return_empty_string');

            add_filter('woocommerce_product_tabs', array( $this, 'addCustomTabs'));

            add_action('woocommerce_after_single_product_summary', array( $this, 'addLineAfterTabs'), 13);

            /**
             * Catalog Mode
             */
            if(Oasis_Helper::getOption('enable_catalog_mode', false)){
                // In Loop
                remove_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_add_to_cart', 10 );
                add_filter( 'woocommerce_loop_add_to_cart_link', '__return_empty_string', 10 );
                // In Single
                remove_action('woocommerce_single_product_summary','woocommerce_template_single_add_to_cart',30);
                // In Page
                add_action( 'wp', array( $this, 'redirectWhenActiveCatalogMode' ) );
            }
        }

        public function addBodyClass($classes){
            $product_design = Oasis_Helper::getOptionByMetadata('product_single_style', Oasis_Helper::getOption('product_single_style', '1'));
            if(is_singular('product')){
                $classes[] = 'product-single-design-' . esc_attr($product_design);
            }
            return $classes;
        }

        public function setSiteLayout($layout){
            if(is_checkout() || is_cart()){
                $layout = 'col-1c';
            }
            if (!is_user_logged_in() && is_account_page()) {
                $layout = 'col-1c';
            }
            if(is_product()){
                $product_design = Oasis_Helper::getOptionByMetadata('product_single_style', Oasis_Helper::getOption('product_single_style', '1'));
                switch($product_design){
                    case 1:
                    case 2:
                    case 3:
                        $layout = 'col-1c';
                        break;
                    case 4:
                        $layout = 'col-2cl';
                        break;
                    case 5:
                        $layout = 'col-2cr';
                        break;
                }
            }

            return $layout;
        }

        public function overridePageHeader(){
            $allow_display = Oasis_Helper::getOption('show_pageheader_on_shop', false);
            if(!$allow_display){
                if(is_shop() || is_product_taxonomy()){
                    add_filter('oasis/filter/show_page_header', '__return_false');
                    add_filter('oasis/filter/show_page_title', '__return_false');
                    add_filter('oasis/filter/show_breadcrumbs', '__return_false');
                }
            }
        }

        public function emptyCart(){
            if (isset($_REQUEST['clear-cart'])) {
                global $woocommerce;
                $woocommerce->cart->empty_cart();
            }
        }

        public function modifyPlaceholder($src){
            return esc_url( get_template_directory_uri() . '/assets/images/wc-placeholder.png' );
        }

        /*
         * Loop
         */

        public function renderToolbar(){
            if(is_woocommerce()){
                wc_get_template( 'loop/toolbar.php' );
            }
        }

        public function addPostClassToLoop($classes, $class, $post_id){
            if ( ! $post_id || 'product' !== get_post_type( $post_id ) ) {
                return $classes;
            }

            global $oasis_loop;
            $product = wc_get_product( $post_id );

            if ( $product ) {

                if(!empty($oasis_loop['loop_style']) && in_array( $oasis_loop['loop_style'], array('featured-01', 'single-01', 'mini')) ){
                    return $classes;
                }
                $show_image = Oasis_Helper::getOption('show_alt_image_catalog_page', false);
                if(isset($oasis_loop['disable_alt_image']) && true == $oasis_loop['disable_alt_image']){
                    $show_image = false;
                }
                if($show_image && (($galleries = $product->get_gallery_image_ids()) && !empty($galleries[0]))){
                    $classes[] = 'thumb-has-effect';
                }else{
                    $classes[] = 'thumb-no-effect';
                }
            }

            return $classes;
        }

        public function addScriptResizeImageInLoop(){
            do_action('oasis/before_resize_image');
        }
        public function removeScriptResizeImageInLoop(){
            do_action('oasis/after_resize_image');
        }

        public function modifyProductThumbnailSize($size){
            global $oasis_loop;
            if(!empty($oasis_loop['image_size'])){
                return $oasis_loop['image_size'];
            }
            return $size;
        }

        public function addSecondProductThumbnailToLoop(){
            global $oasis_loop, $product;
            $show_image = Oasis_Helper::getOption('show_alt_image_catalog_page', false);
            if(isset($oasis_loop['disable_alt_image']) && true == $oasis_loop['disable_alt_image']){
                $show_image = false;
            }
            if($show_image){
                $ids = $product->get_gallery_image_ids();
                if(!empty($ids) && isset($ids[0])){
                   echo wp_get_attachment_image( $ids[0], apply_filters( 'single_product_archive_thumbnail_size', 'shop_catalog' ) ,false , array('class'=>'wp-alt-image'));
                }
            }
        }

        public function addBadgeStockInProduct(){
            global $product;
            $availability = $product->get_availability();
            if(!empty($availability['class']) && $availability['class'] == 'out-of-stock' && !empty($availability['availability'])){
                printf('<span class="new-badge badge-out-of-stock">%s</span>', esc_html($availability['availability']));
            }
        }

        public function renderBtnQuickview(){
            global $product;
            printf(
                '<a class="%s" href="%s" data-href="%s" title="%s">%s</a>',
                'quickview button la-quickview-button',
                esc_url(get_the_permalink($product->get_id())),
                esc_url(add_query_arg('product_quickview', $product->get_id(), get_the_permalink($product->get_id()))),
                esc_attr__('Quick View', 'oasis'),
                esc_attr__('Quick View', 'oasis')
            );
        }

        public function renderBtnWishlist(){
            if (function_exists('YITH_WCWL')) {
                global $product;
                $default_wishlists = is_user_logged_in() ? YITH_WCWL()->get_wishlists(array('is_default' => true)) : false;
                if (!empty($default_wishlists)) {
                    $default_wishlist = $default_wishlists[0]['ID'];
                } else {
                    $default_wishlist = false;
                }

                if (YITH_WCWL()->is_product_in_wishlist($product->get_id(), $default_wishlist)) {
                    $text = esc_html__('View Wishlist', 'oasis');
                    $class = 'add_wishlist button added';
                    $url = YITH_WCWL()->get_wishlist_url('');
                } else {
                    $text = esc_html__('Add to Wishlist', 'oasis');
                    $class = 'add_wishlist button';
                    $url = add_query_arg('add_to_wishlist', $product->get_id(), YITH_WCWL()->get_wishlist_url(''));
                }

                printf(
                    '<a class="%s" href="%s" title="%s" rel="nofollow" data-product_title="%s" data-product_id="%s">%s</a>',
                    esc_attr($class),
                    esc_url($url),
                    esc_attr($text),
                    esc_attr($product->get_title()),
                    esc_attr($product->get_id()),
                    esc_attr($text)
                );
            }
        }

        public function renderLoopItemTitle(){
            the_title( sprintf( '<h3 class="product--title"><a href="%s">', esc_url( get_the_permalink() ) ), '</a></h3>' );
        }

        public function renderLoopItemExcerpt(){
            global $post, $oasis_loop;
            if(!$post->post_excerpt) return;
            printf(
                '<div class="item--excerpt">%s</div>',
                (( isset($oasis_loop['loop_style'])  && $oasis_loop['loop_style'] == 'single-01') ? $post->post_excerpt : strip_tags($post->post_excerpt))
            );
        }

        public function changePerPageDefault($cols){
            $per_page_array = apply_filters('oasis/filter/product_per_page_array', Oasis_Helper::getOption('product_per_page_grid', '9,15,30'));
            $per_page = apply_filters('oasis/filter/product_per_page', Oasis_Helper::getOption('product_per_page_default_grid', 9));
            $per_page_array = explode(',', $per_page_array);
            $per_page_array = array_map('trim', $per_page_array);
            $per_page_array = array_map('absint', $per_page_array);
            asort($per_page_array);
            if (count($per_page_array) > 0 && in_array($per_page, $per_page_array)) {
                $cols = $per_page;
            }
            return $cols;
        }

        public function setCookieDefault(){
            if (isset($_GET['per_page']) && $per_page = $_GET['per_page']) {
                add_filter('oasis/filter/product_per_page', array( $this, 'getParameterPerPage'));
            }
        }
        public function getParameterPerPage($per_page) {
            if (isset($_GET['per_page']) && ($_per_page = $_GET['per_page'])) {
                $per_page = $_per_page;
            }
            return $per_page;
        }
        /*
         * Single
         */

        public function checkConditionShowUpsellAndCrosssell(){
            if (!Oasis_Helper::getOption('show_related_product')) {
                remove_action('woocommerce_after_single_product_summary', 'woocommerce_output_related_products', 20);
            }
            if (!Oasis_Helper::getOption('show_upsell_product')) {
                remove_action('woocommerce_after_single_product_summary', 'woocommerce_upsell_display', 15);
            }
        }

        public function addLineAfterTabs(){
?>
            <div data-vc-full-width="true" data-vc-full-width-init="false" data-vc-stretch-content="true" class="row_after_wc_tabs vc_row wpb_row vc_row-fluid row-1750">
                <div class="wpb_column vc_column_container vc_col-sm-12">
                    <div class="vc_column-inner"><div class="wpb_wrapper"><div class="after_line"></div></div></div>
                </div>
            </div>
            <div class="vc_row-full-width vc_clearfix"></div>
            <?php
        }

        public function addCustomTabs($tabs){
            $product_design = Oasis_Helper::getOptionByMetadata('product_single_style', Oasis_Helper::getOption('product_single_style', '1'));
            if (Oasis_Helper::getOption('show_custom_tab')) {
                $tabs['custom_tab'] = array(
                    'title' => Oasis_Helper::getOption('product_custom_tab_title'),
                    'priority' => 50,
                    'callback' => array( $this, 'getCustomTabsContent')
                );
            }
            if($product_design == 3){
                if(isset($tabs['description'])){
                    unset($tabs['description']);
                }
                if(isset($tabs['additional_information'])){
                    unset($tabs['additional_information']);
                }
            }
            return $tabs;
        }

        public function getCustomTabsContent(){
            echo Oasis_Helper::removeJsWpAutop(Oasis_Helper::getOption('product_custom_tab_content'));
        }

        public function addScriptToQuickview(){
            global $product;
            if (isset($_GET['product_quickview']) && is_product() && $product->is_type('variable')) {
                wp_print_scripts('underscore');
                wc_get_template('single-product/add-to-cart/variation.php');
                ?>
                <script type="text/javascript">
                    /* <![CDATA[ */
                    var _wpUtilSettings = <?php echo json_encode(array(
                        'ajax' => array('url' => admin_url( 'admin-ajax.php', 'relative' ))
                    ));?>;
                    var wc_add_to_cart_variation_params = <?php echo json_encode(array(
                        'i18n_no_matching_variations_text' => esc_attr__( 'Sorry, no products matched your selection. Please choose a different combination.', 'oasis' ),
                        'i18n_make_a_selection_text'       => esc_attr__( 'Select product options before adding this product to your cart.', 'oasis' ),
                        'i18n_unavailable_text'            => esc_attr__( 'Sorry, this product is unavailable. Please choose a different combination.', 'oasis' )
                    )); ?>;
                    /* ]]> */
                </script>
                <script type="text/javascript" src="<?php echo esc_url(includes_url('js/wp-util.min.js')) ?>"></script>
                <script type="text/javascript" src="<?php echo esc_url(WC()->plugin_url()) . '/assets/js/frontend/add-to-cart-variation.min.js' ?>"></script>
                <?php
            }
        }
        public function addScriptToCompare(){
            echo '<script type="text/javascript">var redirect_to_cart=true;</script>';
        }

        /*
         * Cart
         */

        public function modifyCartAjaxResponse( $fragments ){
            $fragments['span.la-cart-count'] = sprintf('<span class="la-cart-count">%s</span>', WC()->cart->get_cart_contents_count());
            $text = '<span class="la-cart-text">'. esc_html__('%s items', 'oasis') .'</span>';
            $fragments['span.la-cart-text'] = sprintf($text, WC()->cart->get_cart_contents_count());
            $fragments['span.la-cart-total-price'] = sprintf('<span class="la-cart-total-price">%s</span>', WC()->cart->get_cart_total());
            return $fragments;
        }

        public function redirectWhenActiveCatalogMode(){
            wp_reset_postdata();
            if (is_cart() || is_checkout()) {
                wp_redirect(($shop_page_url = wc_get_page_id('shop')) ? get_permalink($shop_page_url) : home_url('/'));
                exit;
            }
        }

        /*
         * Checkout
         */

        /*
         * Other
         */
        public function disableYithHooks() {
            global $yith_wcwl, $yith_woocompare;
            if (is_object($yith_wcwl) && is_object($yith_wcwl->wcwl_init) && get_class($yith_wcwl->wcwl_init) == 'YITH_WCWL_Init') {
                remove_action('wp_head', array($yith_wcwl->wcwl_init, 'add_button'));
            }
            if (is_object($yith_woocompare) && is_object($yith_woocompare->obj) && get_class($yith_woocompare->obj) == 'YITH_Woocompare_Frontend') {
                remove_action('woocommerce_single_product_summary', array($yith_woocompare->obj, 'add_compare_link'), 35);
                remove_action('woocommerce_after_shop_loop_item', array($yith_woocompare->obj, 'add_compare_link'), 20);
            }
        }
    }

}