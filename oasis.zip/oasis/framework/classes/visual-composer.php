<?php if ( ! defined( 'ABSPATH' ) ) { die; }

if(!class_exists('Oasis_VC')){

    class Oasis_VC{

        private static $instance = null;
        public $category;
        public static function instance() {
            if ( null === static::$instance ) {
                static::$instance = new static();
            }
            return static::$instance;
        }

        protected function __construct() {
            if(!class_exists('Vc_Manager')) return;

            $this->category = esc_html__( 'La Studio', 'oasis');
            add_action( 'vc_before_init', array( $this, 'vcBeforeInit') );
            add_action( 'vc_after_init', array( $this, 'vcAfterInit') );
            add_filter( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG , array( $this, 'customFilterTags' ), 10, 3 );
            add_filter('vc_google_fonts_get_fonts_filter', array( $this, 'addGoogleFonts' ) );
            add_filter('vc_tta_container_classes', array( $this, 'modifyTtaTabsClasses'), 10, 2 );
        }

        function vcBeforeInit(){
            vc_automapper()->setDisabled( true );
            vc_manager()->disableUpdater( true );
            vc_manager()->setIsAsTheme( true );
            if(class_exists( 'WooCommerce' )){
                remove_action( 'wp_enqueue_scripts', 'vc_woocommerce_add_to_cart_script' );
            }
            add_filter('vc_map_get_param_defaults', array( $this, 'modifyCssAnimationValue' ), 10, 2);
        }

        function vcAfterInit(){
            $this->overrideButton();
            $this->overrideMessage();
            $this->overrideProgressBar();
            $this->overridePieChart();
            $this->overrideTtaAccordion();
            $this->overrideTtaTabs();
            $this->overrideTtaTour();

            if( function_exists('vc_set_default_editor_post_types') ){
                $list = array(
                    'page',
                    'post',
                    'la_block'
                );
                vc_set_default_editor_post_types( $list );
            }
        }

        public function modifyCssAnimationValue($value, $param){
            if( 'css_animation' ==  $param['param_name'] && 'none' == $value){
                $value = '';
            }
            return $value;
        }

        public function customFilterTags($css_classes, $shortcode_name, $atts){
            if ( $shortcode_name == 'vc_progress_bar' ){
                if( isset($atts['display_type']) ){
                    $css_classes .= ' vc_progress_bar_' . esc_attr($atts['display_type']);
                }
            }
            if ( $shortcode_name == 'vc_tta_tabs' || $shortcode_name == 'vc_tta_accordion' || $shortcode_name == 'vc_tta_tour' ){
                if( isset($atts['style']) && strpos($atts['style'], 'la-') !== false ){
                    $css_classes = preg_replace('/ vc_tta-(o|shape|spacing|gap|color)[0-9a-zA-Z\_\-]+/','',$css_classes);
                    $css_classes .= ' vc_tta-o-no-fill';
                    if($shortcode_name == 'vc_tta_tabs'){
                        $css_classes = str_replace('vc_tta-style-','tabs-',$css_classes);
                        $css_classes = str_replace('vc_general ','',$css_classes);
                    }
                    if($shortcode_name == 'vc_tta_tour'){
                        $css_classes = str_replace('vc_tta-style-','tour-',$css_classes);
                        $css_classes = str_replace('vc_general ','',$css_classes);
                    }
                }
            }
            return $css_classes;
        }

        public function addGoogleFonts($fonts){
            $fonts[] = json_decode('{"font_family":"Playball","font_styles":"regular","font_types":"400 regular:400:normal"}');
            $fonts[] = json_decode('{"font_family":"Kaushan Script","font_styles":"regular","font_types":"400 regular:400:normal"}');
            $fonts[] = json_decode('{"font_family":"Work Sans","font_styles":"100,200,300,regular,500,600,700,800","font_types":"100 thin regular:100:normal,200 extra light regular:200:normal,300 light regular:300:normal,400 regular:400:normal,500 medium regular:500:normal,600 semi bold regular:600:normal,700 bold regular:700:normal,800 extra bold regular:800:normal,900 black regular:900:normal"}');
            return $fonts;
        }

        public function overrideButton(){
            $shortcode_name = 'vc_btn';
            $shortcode_object = vc_get_shortcode($shortcode_name);
            $shortcode_params = $shortcode_object['params'];

            $param_color_index = self::getParamIndex($shortcode_params,'color');
            $param_style_index = self::getParamIndex($shortcode_params,'style');

            if($param_style_index !== -1){
                $shortcode_params[$param_style_index]['value'] = array(
                    esc_html__('Modern', 'oasis') => 'modern',
                    esc_html__('Outline', 'oasis') => 'outline',
                    esc_html__('Custom', 'oasis') => 'custom',
                    esc_html__('Outline custom', 'oasis') => 'outline-custom',
                );
            }

            if($param_color_index !== -1){
                $shortcode_params[$param_color_index]['value'] = array(
                    esc_html__('Blue', 'oasis') => 'la-blue',
                    esc_html__('White', 'oasis') => 'la-white',
                    esc_html__('Light Blue', 'oasis') => 'la-light-blue',
                    esc_html__('Dark', 'oasis') => 'la-dark',
                    esc_html__('Grey', 'oasis') => 'la-grey',
                    esc_html__('Red', 'oasis') => 'la-red',
                    esc_html__('Pink', 'oasis') => 'la-pink',
                    esc_html__('Yellow', 'oasis') => 'la-yellow',
                    esc_html__('Orange', 'oasis') => 'la-orange',
                    esc_html__('Brown', 'oasis') => 'la-brown',
                    esc_html__('Nuggets', 'oasis') => 'la-nuggets',
                    esc_html__('Green', 'oasis') => 'la-green',
                    esc_html__('Light Green', 'oasis') => 'la-light-green',
                    esc_html__('Primary', 'oasis') => 'la-primary',
                    esc_html__('Secondary', 'oasis') => 'la-secondary',
                    esc_html__('Background Transparent', 'oasis') => 'la-transparent',
                );
            }
            vc_map_update($shortcode_name , array(
                'category' => $this->category,
                'params' => $shortcode_params
            ));
        }

        public function overrideMessage(){
            $shortcode_name = 'vc_message';

            $shortcode_object = vc_get_shortcode($shortcode_name);
            $shortcode_params = $shortcode_object['params'];

            $message_box_color = self::getParamIndex($shortcode_params,'message_box_color');
            $message_box_style = self::getParamIndex($shortcode_params,'message_box_style');
            $color = self::getParamIndex($shortcode_params,'color');
            $style = self::getParamIndex($shortcode_params,'style');
            $icon_type = self::getParamIndex($shortcode_params,'icon_type');

            $shortcode_params[] = array(
                'type'          => 'colorpicker',
                'param_name'    => 'text_color',
                'heading'       => esc_html__('Text Color', 'oasis'),
                'group'         => esc_html__('Typography', 'oasis'),
            );

            if($message_box_color !== -1){
                unset($shortcode_params[$message_box_color]);
            }
            if($message_box_style !== -1){
                unset($shortcode_params[$message_box_style]);
            }
            if($color !== -1){
                unset($shortcode_params[$color]);
            }
            if($style !== -1){
                unset($shortcode_params[$style]);
            }
            if($icon_type !== -1){
                $shortcode_params[$icon_type]['value'][esc_html__( 'None', 'oasis' )] = 'none';
            }

            vc_map_update($shortcode_name , array(
                'category' => $this->category,
                'params' => $shortcode_params
            ));
        }

        public function overrideProgressBar(){
            vc_map_update( 'vc_progress_bar', array(
                'category' => $this->category
            ));
        }

        public function overridePieChart(){
            vc_map_update( 'vc_pie', array(
                'category' => $this->category
            ));
        }

        public function overrideTtaAccordion(){
            vc_map_update('vc_tta_accordion' , array(
                'category' => $this->category,
                'params' => array(
                    array(
                        'type' => 'dropdown',
                        'param_name' => 'style',
                        'value' => array(
                            esc_html__( 'Style 1', 'oasis' ) => 'la-1',
                            esc_html__( 'Style 2', 'oasis' ) => 'la-2',
                            esc_html__( 'Classic', 'oasis' ) => 'classic',
                            esc_html__( 'Modern', 'oasis' ) => 'modern',
                            esc_html__( 'Flat', 'oasis' ) => 'flat',
                            esc_html__( 'Outline', 'oasis' ) => 'outline',
                        ),
                        'heading' => esc_html__( 'Style', 'oasis' ),
                        'description' => esc_html__( 'Select accordion display style.', 'oasis' ),
                    ),
                    array(
                        'type' => 'dropdown',
                        'param_name' => 'shape',
                        'value' => array(
                            esc_html__( 'Rounded', 'oasis' ) => 'rounded',
                            esc_html__( 'Square', 'oasis' ) => 'square',
                            esc_html__( 'Round', 'oasis' ) => 'round',
                        ),
                        'heading' => esc_html__( 'Shape', 'oasis' ),
                        'description' => esc_html__( 'Select accordion shape.', 'oasis' ),
                        'dependency' => array(
                            'element' => 'style',
                            'value' => array('classic','modern','flat','outline')
                        ),
                    ),
                    array(
                        'type' => 'dropdown',
                        'param_name' => 'color',
                        'value' => getVcShared( 'colors-dashed' ),
                        'std' => 'grey',
                        'heading' => esc_html__( 'Color', 'oasis' ),
                        'description' => esc_html__( 'Select accordion color.', 'oasis' ),
                        'param_holder_class' => 'vc_colored-dropdown',
                        'dependency' => array(
                            'element' => 'style',
                            'value' => array('classic','modern','flat','outline')
                        ),
                    ),
                    array(
                        'type' => 'checkbox',
                        'param_name' => 'no_fill',
                        'heading' => esc_html__( 'Do not fill content area?', 'oasis' ),
                        'description' => esc_html__( 'Do not fill content area with color.', 'oasis' ),
                        'dependency' => array(
                            'element' => 'style',
                            'value' => array('classic','modern','flat','outline')
                        ),
                    ),
                    array(
                        'type' => 'dropdown',
                        'param_name' => 'spacing',
                        'value' => array(
                            esc_html__( 'None', 'oasis' ) => '',
                            '1px' => '1',
                            '2px' => '2',
                            '3px' => '3',
                            '4px' => '4',
                            '5px' => '5',
                            '10px' => '10',
                            '15px' => '15',
                            '20px' => '20',
                            '25px' => '25',
                            '30px' => '30',
                            '35px' => '35',
                        ),
                        'heading' => esc_html__( 'Spacing', 'oasis' ),
                        'description' => esc_html__( 'Select accordion spacing.', 'oasis' ),
                        'dependency' => array(
                            'element' => 'style',
                            'value' => array('classic','modern','flat','outline')
                        ),
                    ),
                    array(
                        'type' => 'dropdown',
                        'param_name' => 'gap',
                        'value' => array(
                            esc_html__( 'None', 'oasis' ) => '',
                            '1px' => '1',
                            '2px' => '2',
                            '3px' => '3',
                            '4px' => '4',
                            '5px' => '5',
                            '10px' => '10',
                            '15px' => '15',
                            '20px' => '20',
                            '25px' => '25',
                            '30px' => '30',
                            '35px' => '35',
                        ),
                        'heading' => esc_html__( 'Gap', 'oasis' ),
                        'description' => esc_html__( 'Select accordion gap.', 'oasis' ),
                        'dependency' => array(
                            'element' => 'style',
                            'value' => array('classic','modern','flat','outline')
                        ),
                    ),
                    array(
                        'type' => 'dropdown',
                        'param_name' => 'c_align',
                        'value' => array(
                            esc_html__( 'Left', 'oasis' ) => 'left',
                            esc_html__( 'Right', 'oasis' ) => 'right',
                            esc_html__( 'Center', 'oasis' ) => 'center',
                        ),
                        'heading' => esc_html__( 'Alignment', 'oasis' ),
                        'description' => esc_html__( 'Select accordion section title alignment.', 'oasis' ),
                    ),
                    array(
                        'type' => 'dropdown',
                        'param_name' => 'autoplay',
                        'value' => array(
                            esc_html__( 'None', 'oasis' ) => 'none',
                            '1' => '1',
                            '2' => '2',
                            '3' => '3',
                            '4' => '4',
                            '5' => '5',
                            '10' => '10',
                            '20' => '20',
                            '30' => '30',
                            '40' => '40',
                            '50' => '50',
                            '60' => '60',
                        ),
                        'std' => 'none',
                        'heading' => esc_html__( 'Autoplay', 'oasis' ),
                        'description' => esc_html__( 'Select auto rotate for accordion in seconds (Note: disabled by default).', 'oasis' ),
                        'dependency' => array(
                            'element' => 'style',
                            'value' => array('classic','modern','flat','outline')
                        ),
                    ),
                    array(
                        'type' => 'checkbox',
                        'param_name' => 'collapsible_all',
                        'heading' => esc_html__( 'Allow collapse all?', 'oasis' ),
                        'description' => esc_html__( 'Allow collapse all accordion sections.', 'oasis' ),
                    ),
                    // Control Icons
                    array(
                        'type' => 'dropdown',
                        'param_name' => 'c_icon',
                        'value' => array(
                            esc_html__( 'None', 'oasis' ) => '',
                            esc_html__( 'Chevron', 'oasis' ) => 'chevron',
                            esc_html__( 'Plus', 'oasis' ) => 'plus',
                            esc_html__( 'Triangle', 'oasis' ) => 'triangle',
                        ),
                        'std' => 'plus',
                        'heading' => esc_html__( 'Icon', 'oasis' ),
                        'description' => esc_html__( 'Select accordion navigation icon.', 'oasis' ),
                    ),
                    array(
                        'type' => 'dropdown',
                        'param_name' => 'c_position',
                        'value' => array(
                            esc_html__( 'Left', 'oasis' ) => 'left',
                            esc_html__( 'Right', 'oasis' ) => 'right',
                        ),
                        'dependency' => array(
                            'element' => 'c_icon',
                            'not_empty' => true,
                        ),
                        'heading' => esc_html__( 'Position', 'oasis' ),
                        'description' => esc_html__( 'Select accordion navigation icon position.', 'oasis' ),
                    ),
                    // Control Icons END
                    array(
                        'type' => 'textfield',
                        'param_name' => 'active_section',
                        'heading' => esc_html__( 'Active section', 'oasis' ),
                        'value' => 1,
                        'description' => esc_html__( 'Enter active section number (Note: to have all sections closed on initial load enter non-existing number).', 'oasis' ),
                    ),
                    array(
                        'type' => 'textfield',
                        'heading' => esc_html__( 'Extra class name', 'oasis' ),
                        'param_name' => 'el_class',
                        'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'oasis' ),
                    ),
                )
            ));
        }

        public function overrideTtaTabs(){
            vc_map_update( 'vc_tta_tabs', array(
                'category' => $this->category,
                'params' => array(
                    array(
                        'type' => 'textfield',
                        'param_name' => 'title',
                        'heading' => __( 'Widget title', 'oasis' ),
                        'description' => __( 'Enter text used as widget title (Note: located above content element).', 'oasis' ),
                    ),
                    array(
                        'type' => 'dropdown',
                        'param_name' => 'style',
                        'value' => array(
                            esc_html__( 'Style 1', 'oasis' ) => 'la-1',
                            esc_html__( 'Style 2', 'oasis' ) => 'la-2',
                            esc_html__( 'Classic', 'oasis' ) => 'classic',
                            esc_html__( 'Modern', 'oasis' ) => 'modern',
                            esc_html__( 'Flat', 'oasis' ) => 'flat',
                            esc_html__( 'Outline', 'oasis' ) => 'outline',
                        ),
                        'heading' => esc_html__( 'Style', 'oasis' ),
                        'description' => esc_html__( 'Select tabs display style.', 'oasis' ),
                    ),
                    array(
                        'type' => 'dropdown',
                        'param_name' => 'shape',
                        'value' => array(
                            esc_html__( 'Rounded', 'oasis' ) => 'rounded',
                            esc_html__( 'Square', 'oasis' ) => 'square',
                            esc_html__( 'Round', 'oasis' ) => 'round',
                        ),
                        'heading' => esc_html__( 'Shape', 'oasis' ),
                        'description' => esc_html__( 'Select tabs shape.', 'oasis' ),
                        'dependency' => array(
                            'element' => 'style',
                            'value' => array('classic','modern','flat','outline')
                        ),
                    ),
                    array(
                        'type' => 'dropdown',
                        'param_name' => 'color',
                        'heading' => esc_html__( 'Color', 'oasis' ),
                        'description' => esc_html__( 'Select tabs color.', 'oasis' ),
                        'value' => getVcShared( 'colors-dashed' ),
                        'std' => 'grey',
                        'param_holder_class' => 'vc_colored-dropdown',
                        'dependency' => array(
                            'element' => 'style',
                            'value' => array('classic','modern','flat','outline')
                        ),
                    ),

                    array(
                        'type' => 'checkbox',
                        'param_name' => 'no_fill_content_area',
                        'heading' => esc_html__( 'Do not fill content area?', 'oasis' ),
                        'std' => 'true',
                        'description' => esc_html__( 'Do not fill content area with color.', 'oasis' ),
                        'dependency' => array(
                            'element' => 'style',
                            'value' => array('classic','modern','flat','outline')
                        ),
                    ),
                    array(
                        'type' => 'dropdown',
                        'param_name' => 'spacing',
                        'value' => array(
                            esc_html__( 'None', 'oasis' ) => '',
                            '1px' => '1',
                            '2px' => '2',
                            '3px' => '3',
                            '4px' => '4',
                            '5px' => '5',
                            '10px' => '10',
                            '15px' => '15',
                            '20px' => '20',
                            '25px' => '25',
                            '30px' => '30',
                            '35px' => '35',
                        ),
                        'heading' => esc_html__( 'Spacing', 'oasis' ),
                        'description' => esc_html__( 'Select tabs spacing.', 'oasis' ),
                        'std' => '',
                        'dependency' => array(
                            'element' => 'style',
                            'value' => array('classic','modern','flat','outline')
                        ),
                    ),
                    array(
                        'type' => 'dropdown',
                        'param_name' => 'gap',
                        'value' => array(
                            esc_html__( 'None', 'oasis' ) => '',
                            '1px' => '1',
                            '2px' => '2',
                            '3px' => '3',
                            '4px' => '4',
                            '5px' => '5',
                            '10px' => '10',
                            '15px' => '15',
                            '20px' => '20',
                            '25px' => '25',
                            '30px' => '30',
                            '35px' => '35',
                        ),
                        'heading' => esc_html__( 'Gap', 'oasis' ),
                        'description' => esc_html__( 'Select tabs gap.', 'oasis' ),
                        'std' => '',
                        'dependency' => array(
                            'element' => 'style',
                            'value' => array('classic','modern','flat','outline')
                        ),
                    ),
                    array(
                        'type' => 'dropdown',
                        'param_name' => 'tab_position',
                        'value' => array(
                            esc_html__( 'Top', 'oasis' ) => 'top',
                            esc_html__( 'Bottom', 'oasis' ) => 'bottom',
                        ),
                        'heading' => esc_html__( 'Position', 'oasis' ),
                        'description' => esc_html__( 'Select tabs navigation position.', 'oasis' ),
                    ),
                    array(
                        'type' => 'dropdown',
                        'param_name' => 'alignment',
                        'value' => array(
                            esc_html__( 'Left', 'oasis' ) => 'left',
                            esc_html__( 'Right', 'oasis' ) => 'right',
                            esc_html__( 'Center', 'oasis' ) => 'center',
                        ),
                        'heading' => esc_html__( 'Alignment', 'oasis' ),
                        'description' => esc_html__( 'Select tabs section title alignment.', 'oasis' ),
                        'std' => 'center',
                    ),
                    array(
                        'type' => 'dropdown',
                        'param_name' => 'autoplay',
                        'value' => array(
                            esc_html__( 'None', 'oasis' ) => 'none',
                            '1' => '1',
                            '2' => '2',
                            '3' => '3',
                            '4' => '4',
                            '5' => '5',
                            '10' => '10',
                            '20' => '20',
                            '30' => '30',
                            '40' => '40',
                            '50' => '50',
                            '60' => '60',
                        ),
                        'std' => 'none',
                        'heading' => esc_html__( 'Autoplay', 'oasis' ),
                        'description' => esc_html__( 'Select auto rotate for tabs in seconds (Note: disabled by default).', 'oasis' ),
                        'dependency' => array(
                            'element' => 'style',
                            'value' => array('classic','modern','flat','outline')
                        ),
                    ),
                    array(
                        'type' => 'textfield',
                        'param_name' => 'active_section',
                        'heading' => esc_html__( 'Active section', 'oasis' ),
                        'value' => 1,
                        'description' => esc_html__( 'Enter active section number (Note: to have all sections closed on initial load enter non-existing number).', 'oasis' ),
                    ),
                    array(
                        'type' => 'dropdown',
                        'param_name' => 'pagination_style',
                        'value' => array(
                            esc_html__( 'None', 'oasis' ) => '',
                            esc_html__( 'Square Dots', 'oasis' ) => 'outline-square',
                            esc_html__( 'Radio Dots', 'oasis' ) => 'outline-round',
                            esc_html__( 'Point Dots', 'oasis' ) => 'flat-round',
                            esc_html__( 'Fill Square Dots', 'oasis' ) => 'flat-square',
                            esc_html__( 'Rounded Fill Square Dots', 'oasis' ) => 'flat-rounded',
                        ),
                        'heading' => esc_html__( 'Pagination style', 'oasis' ),
                        'description' => esc_html__( 'Select pagination style.', 'oasis' ),
                        'dependency' => array(
                            'element' => 'style',
                            'value' => array('classic','modern','flat','outline')
                        ),
                    ),
                    array(
                        'type' => 'dropdown',
                        'param_name' => 'pagination_color',
                        'value' => getVcShared( 'colors-dashed' ),
                        'heading' => esc_html__( 'Pagination color', 'oasis' ),
                        'description' => esc_html__( 'Select pagination color.', 'oasis' ),
                        'param_holder_class' => 'vc_colored-dropdown',
                        'std' => 'grey',
                        'dependency' => array(
                            'element' => 'pagination_style',
                            'not_empty' => true,
                        ),
                    ),
                    array(
                        'type' => 'textfield',
                        'heading' => esc_html__( 'Extra class name', 'oasis' ),
                        'param_name' => 'el_class',
                        'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'oasis' ),
                    ),
                    array(
                        'type' => 'css_editor',
                        'heading' => esc_html__( 'CSS box', 'oasis' ),
                        'param_name' => 'css',
                        'group' => esc_html__( 'Design Options', 'oasis' ),
                    ),
                )
            ));
        }

        public function modifyTtaTabsClasses($classes, $atts){
            if(isset($atts['style']) && strpos($atts['style'],'la-') !== false && isset($atts['alignment'])){
                $classes[] = 'vc_tta-' . $atts['style'];
                $classes[] = 'vc_tta-alignment-' . $atts['alignment'];
            }
            return $classes;
        }

        public function overrideTtaTour(){
            vc_map_update( 'vc_tta_tour', array(
                'category' => $this->category,
                'params' => array(
                    array(
                        'type' => 'dropdown',
                        'param_name' => 'style',
                        'value' => array(
                            esc_html__( 'Style 1', 'oasis' ) => 'la-1',
                        ),
                        'heading' => esc_html__( 'Style', 'oasis' ),
                        'description' => esc_html__( 'Select tabs display style.', 'oasis' ),
                    ),
                    array(
                        'type' => 'dropdown',
                        'param_name' => 'tab_position',
                        'value' => array(
                            esc_html__( 'Left', 'oasis' ) => 'left',
                            esc_html__( 'Right', 'oasis' ) => 'right',
                        ),
                        'heading' => esc_html__( 'Position', 'oasis' ),
                        'description' => esc_html__( 'Select tour navigation position.', 'oasis' ),
                    ),
                    array(
                        'type' => 'dropdown',
                        'param_name' => 'alignment',
                        'value' => array(
                            esc_html__( 'Left', 'oasis' ) => 'left',
                            esc_html__( 'Right', 'oasis' ) => 'right',
                            esc_html__( 'Center', 'oasis' ) => 'center',
                        ),
                        'heading' => esc_html__( 'Alignment', 'oasis' ),
                        'description' => esc_html__( 'Select tabs section title alignment.', 'oasis' ),
                        'std' => 'center',
                    ),
                    array(
                        'type' => 'hidden',
                        'param_name' => 'autoplay',
                        'std' => 'none',
                    ),
                    array(
                        'type' => 'dropdown',
                        'param_name' => 'controls_size',
                        'value' => array(
                            esc_html__( 'Auto', 'oasis' ) => '',
                            esc_html__( 'Extra large', 'oasis' ) => 'xl',
                            esc_html__( 'Large', 'oasis' ) => 'lg',
                            esc_html__( 'Medium', 'oasis' ) => 'md',
                            esc_html__( 'Small', 'oasis' ) => 'sm',
                            esc_html__( 'Extra small', 'oasis' ) => 'xs',
                        ),
                        'heading' => esc_html__( 'Navigation width', 'oasis' ),
                        'description' => esc_html__( 'Select tour navigation width.', 'oasis' ),
                    ),

                    array(
                        'type' => 'textfield',
                        'param_name' => 'active_section',
                        'heading' => esc_html__( 'Active section', 'oasis' ),
                        'value' => 1,
                        'description' => esc_html__( 'Enter active section number (Note: to have all sections closed on initial load enter non-existing number).', 'oasis' ),
                    ),
                    array(
                        'type' => 'textfield',
                        'heading' => esc_html__( 'Extra class name', 'oasis' ),
                        'param_name' => 'el_class',
                        'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'oasis' ),
                    ),
                    array(
                        'type' => 'css_editor',
                        'heading' => esc_html__( 'CSS box', 'oasis' ),
                        'param_name' => 'css',
                        'group' => esc_html__( 'Design Options', 'oasis' ),
                    ),
                )
            ));
        }

        protected function arrayToObject($array) {
            if (!is_array($array)) {
                return $array;
            }
            $object = new stdClass();
            if (is_array($array) && count($array) > 0) {
                foreach ($array as $name=>$value) {
                    $name = strtolower(trim($name));
                    if (!empty($name)) {
                        $object->$name = $this->arrayToObject($value);
                    }
                }
                return $object;
            }
            else {
                return FALSE;
            }
        }

        public static function getParamIndex($array, $attr){
            foreach ($array as $index => $entry) {
                if ($entry['param_name'] == $attr) {
                    return $index;
                }
            }
            return -1;
        }
    }
}