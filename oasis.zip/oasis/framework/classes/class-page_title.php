<?php if ( ! defined( 'ABSPATH' ) ) { die; }

if(!class_exists('Oasis_Page_Title')){

	class Oasis_Page_Title{

		private static $instance = null;

		public $options = null;

		protected function __construct() {

			add_filter( 'oasis/filter/get_page_title', array( $this, 'override_page_title' ) );
			$blog_title = esc_html__( 'Blog', 'oasis' );
			if ( get_option('show_on_front') == 'page') {
				if ( $tmp = get_option('page_for_posts') ) {
					$blog_title = get_the_title( $tmp );
				}
			}
			else if ( $tmp = Oasis_Helper::getOption( 'blog_title' ) ) {
				$blog_title = $tmp;
			}

			$this->options = array(
				'blog_title' => $blog_title
			);
		}

		public static function instance() {
			if ( null === static::$instance ) {
				static::$instance = new static();
			}
			return static::$instance;
		}

		public function override_page_title( $title ){
			if ( $_title = Oasis_Helper::getOptionByMetadata( 'page_title_custom', false ) ) {
				return $_title;
			}
			if( $tmp = Oasis_Helper::getOption('page_title_custom') ){
				$title = $tmp;
			}
			return $title;
		}

		public function get_title(){
			$output = '';
			if(is_singular()){
				$output .= $this->get_leaf();
			}
			elseif(is_post_type_archive()){
				if(is_search()){
					$output .= $this->get_leaf( 'search' );
				}
				else{
					$output .= $this->get_title_archive();
				}
			}
			elseif ( is_tax() || is_tag() || is_category() ) {
				$html = $this->get_leaf( 'term' );
				if(is_tag()){
					$output .= sprintf( esc_html__( 'Tag - %s', 'oasis' ), $html );
				}
				elseif ( is_tax( 'product_tag' ) ) {
					$output .= sprintf( esc_html__( 'Product Tag - %s', 'oasis' ), $html );
				}
				else {
					$output .= $html;
				}
			}
			elseif ( is_date() ) {
				if ( is_year() ) {
					$output .= $this->get_leaf( 'year' );
				}
				elseif ( is_month() ) {
					$output .= $this->get_leaf( 'month' );
				}
				elseif ( is_day() ) {
					$output .= $this->get_leaf( 'day' );
				}
			}
			elseif ( is_author() ) {
				$output .= $this->get_leaf( 'author' );
			}
			elseif ( is_search() ) {
				$output .= $this->get_leaf( 'search' );
			}
			elseif ( is_404() ) {
				$output .= $this->get_leaf( '404' );
			}
			elseif ( class_exists( 'bbPress' ) && is_bbpress() ) {
				if ( bbp_is_search() ) {
					$output .= $this->get_leaf( 'bbpress_search' );
				}
				elseif ( bbp_is_single_user() ) {
					$output .= $this->get_leaf( 'bbpress_user' );
				}
				else {
					$output .= $this->get_leaf();
				}
			}
			else {
				if ( is_home() && !is_front_page() ) {
					$output .= $this->options['blog_title'];
				}
			}

			return apply_filters('oasis/filter/get_page_title', $output);
		}

		public function get_leaf( $object_type = null ){

			switch ( $object_type ) {
				case 'term':
					$term = get_queried_object();
					$title = $term->name;
					break;
				case 'year':
					$title = sprintf( esc_html__( 'Yearly Archives - %s', 'oasis' ), get_the_date( esc_html_x( 'Y', 'yearly archives date format', 'oasis' ) ) );
					break;
				case 'month':
					$title = sprintf( esc_html__( 'Monthly Archives - %s', 'oasis' ), get_the_date( esc_html_x( 'F Y', 'monthly archives date format', 'oasis' ) ) );
					break;
				case 'day':
					$title = sprintf( esc_html__( 'Daily Archives - %s', 'oasis' ), get_the_date() );
					break;
				case 'author':
					$user = get_queried_object();
					$title = sprintf( esc_html__( 'Author - %s', 'oasis' ), $user->display_name );
					break;
				case 'search':
					$title = esc_html__( 'Search Results', 'oasis' );
					break;
				case '404':
					$title = esc_html__( '404 - Page Not Found', 'oasis' );
					break;
				case 'bbpress_search':
					$title = esc_html__( 'Search Results', 'oasis' );
					break;
				case 'bbpress_user':
					$current_user = wp_get_current_user();
					$title = $current_user->user_nicename;
					break;
				default:
					$title = get_the_title( get_the_ID() );
					break;
			}

			return $title;
		}

		public function get_shop_title(){
			$post_type = 'product';
			$post_type_object = get_post_type_object( $post_type );

			$output = '';
			if ( is_object( $post_type_object ) && class_exists( 'WooCommerce' ) && ( is_woocommerce() || is_cart() || is_checkout() || is_account_page() ) ) {
				$shop_page_id = wc_get_page_id( 'shop' );
				$shop_page_name = $shop_page_id ? get_the_title( $shop_page_id ) : '';

				if ( !$shop_page_name ) {
					$shop_page_name = $post_type_object->labels->name;
				}
				$output .= $shop_page_name;
			}

			return $output;
		}

		public function get_title_archive(){

			$post_type = get_query_var('post_type');
			$post_type_object = get_post_type_object( $post_type );
			$archive_title = '';
			if ( is_object( $post_type_object ) ) {

				if ( $post_type === 'product' ) {
					$shop_title = $this->get_shop_title();
					if($shop_title) {
						return $shop_title;
					}
				}
				// bbpress
				if ( class_exists( 'bbPress' ) && $post_type == 'topic' ) {
					$archive_title = bbp_get_topic_archive_title();
					return $archive_title;
				}

				// default
				if ( isset( $post_type_object->label ) && $post_type_object->label !== '' ) {
					$archive_title = $post_type_object->label;
				} elseif ( isset( $post_type_object->labels->menu_name ) && $post_type_object->labels->menu_name !== '' ) {
					$archive_title = $post_type_object->labels->menu_name;
				} else {
					$archive_title = $post_type_object->name;
				}
			}

			return $archive_title;
		}

	}
}