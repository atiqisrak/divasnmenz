<?php if ( ! defined( 'ABSPATH' ) ) { die; }

if(!class_exists('Oasis_Menu_Item_Custom_Fields')){
    class Oasis_Menu_Item_Custom_Fields{

        protected static $fields = array();

        protected static $default_metakey = '';

        private static $instance = null;

        public static function instance() {
            if ( null === static::$instance ) {
                static::$instance = new static();
            }
            return static::$instance;
        }
        /**
         * Initialize plugin
         */
        protected function __construct( ) {
            add_action( 'wp_loaded',                        array( $this, 'loadWalkerEdit' ), 9);
            add_filter( 'wp_setup_nav_menu_item',           array( $this, 'setupNavMenuItem' ));
            add_action( 'wp_nav_menu_item_custom_fields',   array( $this, 'addCustomFields' ), 10, 4);
            add_action( 'wp_update_nav_menu_item',          array( $this, 'updateMenuItem' ), 10, 3);
            add_filter( 'walker_nav_menu_start_el',         array( $this, 'addIconToMenuItem' ),10, 4);
            self::$default_metakey = '_mm_meta';
            self::$fields = array(
                'icon' => array(
                    'id'    => 'icon',
                    'type'  => 'icon',
                    'title' => esc_html__('Custom Icon','oasis'),
                    'wrap_class' => '',
                ),
                'nolink' => array(
                    'id'    => 'nolink',
                    'type'  => 'switcher',
                    'label' => esc_html__("Don't link",'oasis'),
                    'wrap_class' => '',
                ),
                'only_icon' => array(
                    'id'    => 'only_icon',
                    'type'  => 'switcher',
                    'label' => esc_html__("Show Only Icon",'oasis'),
                    'wrap_class' => 'show-only-depth-0',
                ),
                'hide' => array(
                    'id'    => 'hide',
                    'type'  => 'switcher',
                    'label' => esc_html__("Don't show a link",'oasis'),
                    'wrap_class' => '',
                ),
                'menu_type' => array(
                    'id'    => 'menu_type',
                    'type'  => 'select',
                    'title' => esc_html__('Menu Type','oasis'),
                    'options' => array(
                        'narrow'      => esc_html__('Narrow','oasis'),
                        'wide'  => esc_html__('Wide','oasis')
                    ),
                    'default' => 'narrow',
                    'wrap_class' => 'show-only-depth-0 field-menu-type',
                ),
                'submenu_position' => array(
                    'id'    => 'submenu_position',
                    'type'  => 'select',
                    'title' => esc_html__('SubMenu Position','oasis'),
                    'after' => sprintf(__('%sApply for parent with "Menu Type" is "wide" %s','oasis'), '<p class="cs-text-desc">','</p>'),
                    'options' => array(
                        'right'     => esc_html__('Right','oasis'),
                        'left'      => esc_html__('Left','oasis'),
                    ),
                    'default'   => 'right',
                    'wrap_class' => 'hide-depth-0 field-submenu-position',
                ),
                'popup_column' => array(
                    'id'    => 'popup_column',
                    'type'  => 'select',
                    'title' => esc_html__('Popup Columns','oasis'),
                    'options' => array(
                        '1'         => esc_html__('1 Column','oasis'),
                        '2'         => esc_html__('2 Columns','oasis'),
                        '3'         => esc_html__('3 Columns','oasis'),
                        '4'         => esc_html__('4 Columns','oasis'),
                        '5'         => esc_html__('5 Columns','oasis'),
                        '6'         => esc_html__('6 Columns','oasis')
                    ),
                    'default'   => '4',
                    'dependency'   => array( 'menu_type', '==', 'wide' ),
                    'wrap_class' => 'show-only-depth-0 field-popup-column',
                ),
                'popup_max_width' => array(
                    'id'    => 'popup_max_width',
                    'type'  => 'number',
                    'title' => esc_html__('Popup Max Width','oasis'),
                    'after' => 'px',
                    'dependency'   => array( 'menu_type', '==', 'wide' ),
                    'wrap_class' => 'show-only-depth-0 field-popup-max-width',
                ),
                'item_column' => array(
                    'id'    => 'item_column',
                    'type'  => 'text',
                    'title' => esc_html__('Columns','oasis'),
                    'after' => sprintf(__('%swill occupy x columns of parent popup columns%s','oasis'), '<p class="cs-text-desc">','</p>'),
                    'wrap_class' => 'show-only-depth-1 field-item-column',
                ),
                'block' => array(
                    'id'    => 'block',
                    'type'  => 'select',
                    'title' => esc_html__('Custom Block','oasis'),
                    'options'   => 'posts',
                    'query_args'    => array(
                        'post_type'    => 'la_block',
                        'orderby'      => 'post_date',
                        'order'        => 'DESC',
                        'posts_per_page' => -1
                    ),
                    'default_option' => esc_html__('Select a banner','oasis'),
                    'wrap_class' => 'show-only-depth-1 field-custom-block',
                ),
                'popup_background' => array(
                    'id'           => 'popup_background',
                    'type'         => 'background',
                    'title' 	   => esc_html__('Popup Background','oasis'),
                    'dependency'   => array( 'menu_type', '==', 'wide' ),
                    'wrap_class' => 'show-only-depth-0 field-popup-background',
                ),
                'custom_style' => array(
                    'id'        => 'custom_style',
                    'type'      => 'textarea',
                    'title' 	=> esc_html__('Custom Styles for Popup','oasis'),
                    'attributes'    => array(
                        'rows'        => 3,
                    ),
                    'wrap_class' => 'show-only-depth-0 field-custom-style',
                ),
                'tip_label' => array(
                    'id'        => 'tip_label',
                    'type'      => 'text',
                    'title' 	=> esc_html__('Tip Label','oasis'),
                    'wrap_class' => 'field-tip-label',
                ),
                'tip_color' => array(
                    'id'        => 'tip_color',
                    'type'      => 'color_picker',
                    'title' 	=> esc_html__('Tip Color','oasis'),
                    'rgba'      => true,
                    'wrap_class' => 'field-tip-color',
                ),
                'tip_background_color' => array(
                    'id'        => 'tip_background_color',
                    'type'      => 'color_picker',
                    'title' 	=> esc_html__('Tip Background','oasis'),
                    'rgba'      => true,
                    'wrap_class' => 'field-tip-background-color',
                )
            );
        }

        public function loadWalkerEdit() {
            add_filter( 'wp_edit_nav_menu_walker', array( $this, 'findWalkerEdit' ), 99 );
        }

        public function findWalkerEdit( $walker ) {
            $walker = 'Oasis_Walker_Nav_Menu_Edit';
            if ( ! class_exists( $walker ) ) {
                require get_template_directory() . '/framework/classes/megamenu/class-megamenu_walker_edit.php';
            }
            return $walker;
        }

        public function setupNavMenuItem($menu_item){
            $meta_value = Oasis_Helper::getPostMeta($menu_item->ID, self::$default_metakey);

            foreach ( self::$fields as $key => $value ){
                $menu_item->$key = isset($meta_value[$key]) ? $meta_value[$key] : '';
            }

            return $menu_item;
        }

        public function updateMenuItem( $menu_id, $menu_item_db_id, $menu_item_args ) {
            if ( defined( 'DOING_AJAX' ) && DOING_AJAX ) {
                return;
            }
            check_admin_referer( 'update-nav_menu', 'update-nav-menu-nonce' );

            $key = self::$default_metakey;

            if ( ! empty( $_POST[$key][$menu_item_db_id] ) ) {
                $value = $_POST[$key][$menu_item_db_id];
            }
            else {
                $value = null;
            }

            if(!empty($value)){
                update_post_meta( $menu_item_db_id, $key, $value );
            }
            else {
                delete_post_meta( $menu_item_db_id, $key );
            }
        }

        public function addCustomFields( $id, $item, $depth, $args ) {
            if(function_exists('cs_add_element')){
                ?><div class="lastudio-megamenu-settings cs-content">
                <h3><?php esc_html_e('MegaMenu Settings','oasis');?></h3>
                <div class="lastudio-megamenu-custom-fields">
                    <?php
                    foreach ( self::$fields as $key => $field ) {
                        $unique     = self::$default_metakey . '['.$item->ID.']';
                        $default    = ( isset( $field['default'] ) ) ? $field['default'] : '';
                        $elem_id    = ( isset( $field['id'] ) ) ? $field['id'] : '';
                        if(isset($field['dependency']) && isset($field['dependency'][0])){
                            if($depth == 1){
                                if(strpos($field['dependency'][0],'__parent__') === FALSE){
                                    $field['dependency'][0] .= '_' . $item->ID;
                                }else{
                                    $field['dependency'][0] = str_replace('__parent__', '_' . $item->menu_item_parent, $field['dependency'][0]);
                                }
                            }else{
                                $field['dependency'][0] = str_replace('__parent__', '', $field['dependency'][0]);
                                $field['dependency'][0] .= '_' . $item->ID;
                            }
                        }

                        $field['name'] = $unique. '[' . $elem_id . ']';
                        $field['id'] = $elem_id . '_' . $item->ID;
                        $elem_value =  isset($item->$key) ? $item->$key : $default;
                        echo cs_add_element( $field, $elem_value, $unique );
                    }
                    ?>
                </div>
                </div><?php
            }
        }

        public function addIconToMenuItem($item_output, $item, $depth, $args){
            if ( !is_a( $args->walker, 'Oasis_Walker_Menu' ) && !is_a( $args->walker, 'Oasis_Walker_Accordion_Menu' ) && $item->icon){
                $icon_class = 'mm-icon ' . $item->icon;
                $icon = "<i class=\"".esc_attr($icon_class)."\"></i>";
                $pattern = '/>(.*?)<\/a>/';
                $item_output = preg_replace( $pattern, '>' . $args->link_before . $icon . '$1' . $args->link_after . '</a>', $item_output );
            }
            return $item_output;
        }

        public function addColumnSettings( $columns ) {
            $columns = array_merge( $columns, self::$fields );
            return $columns;
        }

    }
}


if(!class_exists('Oasis_Walker_Menu')){
    class Oasis_Walker_Menu extends Walker_Nav_Menu {

        // add popup class to ul sub-menus
        public function start_lvl( &$output, $depth = 0, $args = array() ) {
            $indent = str_repeat("\t", $depth);
            $submenu_custom_style = '';
            $out_div = '';
            if($depth == 0){
                $popup_custom_style = isset( $args->popup_custom_style ) ? ' style="' . esc_attr( $args->popup_custom_style ) . '"' : '';
                $out_div = '<div class="popup"><div class="inner" ' . $popup_custom_style . '>';
                $args->popup_custom_style = '';
            }
            elseif($depth == 1){
                $submenu_custom_style = isset( $args->popup_custom_style ) ? ' style="' . esc_attr( $args->popup_custom_style ) . '"' : '';
                $args->popup_custom_style = '';
            }
            $output .= "\n$indent$out_div<ul class=\"sub-menu\"$submenu_custom_style>\n";
        }

        public function end_lvl( &$output, $depth = 0, $args = array() ) {
            $indent = str_repeat("\t", $depth);
            if($depth == 0){
                $out_div = '</div></div>';
            }
            else{
                $out_div = '';
            }
            $output .= "$indent</ul>$out_div\n";
        }

        // add main/sub classes to li's and links
        public function start_el( &$output, $item, $depth = 0, $args = array(), $id = 0 ) {
            $classes = empty( $item->classes ) ? array() : (array)$item->classes;
            $indent = ( $depth > 0 ? str_repeat( "\t", $depth ) : '' );

            $classes[] = 'mm-item';

            if($this->has_children){
                $classes[] = 'mm-item-has-sub';
            }
            if ( $item->current || $item->current_item_ancestor || $item->current_item_parent ){
                $classes[] = 'active';
            }

            if ($depth == 0) {
                $popup_custom_styles = '';
                if ($item->menu_type == "wide") {
                    if ($item->popup_column == ""){
                        $item->popup_column = 4;
                    }
                    $classes[] = "mm-popup-wide";
                    $classes[] = "mm-popup-column-{$item->popup_column}";

                    if(isset($item->popup_background)){
                        $popup_background = shortcode_atts(array(
                            'repeat' => '',
                            'position' => '',
                            'attachment' => '',
                            'image' => '',
                            'color' => ''
                        ),$item->popup_background);
                        $popup_background_repeat        = $popup_background['repeat'] ? $popup_background['repeat'] : 'repeat';
                        $popup_background_position      = $popup_background['position'] ? $popup_background['position'] : 'left top';
                        $popup_background_attachment    = $popup_background['attachment'] ? $popup_background['attachment'] : 'scroll';
                        if($popup_background['image']){
                            $popup_custom_styles .= 'background-image:url(' . $popup_background['image'] . ');';
                            $popup_custom_styles .= 'background-repeat:'.$popup_background_repeat.';';
                            $popup_custom_styles .= 'background-position:'.$popup_background_position.';';
                            $popup_custom_styles .= 'background-attachment:'.$popup_background_attachment.';';
                        }
                        if($popup_background['color']){
                            $popup_custom_styles .= 'background-color:'.$popup_background['color'].';';
                        }
                    }
                    if(isset($item->popup_max_width) && !empty($item->popup_max_width)){
                        $popup_custom_styles .= 'max-width:' . absint($item->popup_max_width) . 'px;';
                        $classes[] = "mm-popup-max-width";
                    }
                }
                else {
                    $classes[] = "mm-popup-narrow";
                }
                if(isset($item->custom_style) && !empty($item->custom_style)){
                    $popup_custom_styles .= $item->custom_style;
                }
                $popup_custom_styles = str_replace('"', '\'', $popup_custom_styles);

                $args->popup_custom_style = self::compress_text($popup_custom_styles);
            }
            if ($depth == 1) {
                $popup_custom_styles = '';
                if ( isset( $item->popup_background ) ) {
                    $popup_background = shortcode_atts(array(
                        'repeat' => '',
                        'position' => '',
                        'attachment' => '',
                        'image' => '',
                        'color' => ''
                    ),$item->popup_background);
                    $popup_background_repeat        = $popup_background['repeat'] ? $popup_background['repeat'] : 'repeat';
                    $popup_background_position      = $popup_background['position'] ? $popup_background['position'] : 'left top';
                    $popup_background_attachment    = $popup_background['attachment'] ? $popup_background['attachment'] : 'scroll';
                    if($popup_background['image']){
                        $popup_custom_styles .= 'background-image:url(' . $popup_background['image'] . ');';
                        $popup_custom_styles .= 'background-repeat:'.$popup_background_repeat.';';
                        $popup_custom_styles .= 'background-position:'.$popup_background_position.';';
                        $popup_custom_styles .= 'background-attachment:'.$popup_background_attachment.';';
                    }
                    if ( $popup_background[ 'color' ] ) {
                        $popup_custom_styles .= 'background-color:' . $popup_background[ 'color' ] . ';';
                    }
                }
                if ( isset( $item->custom_style ) && !empty( $item->custom_style ) ) {
                    $popup_custom_styles .= $item->custom_style;
                }
                $popup_custom_styles = str_replace( '"', '\'', $popup_custom_styles );
                /** waiting for options behind */
                $args->popup_custom_style = self::compress_text($popup_custom_styles);

                if ( $item->block ) {
                    $classes[] = 'mm-menu-custom-block';
                }
            }
            $classes[] = "mm-item-level-{$depth}";
            if ( $item->hide ) {
                $classes[] = "mm-item-hide";
            }
            if ( $item->nolink ) {
                $classes[] = "mm-item-nolink";
                $item->url = 'javascript:;';
                $item->target = '_self';
            }
            if($depth > 0 && $this->has_children){
                $classes[] = 'submenu-position-' . ( isset($item->submenu_position) && !empty($item->submenu_position) ? $item->submenu_position : 'left' );
            }
            $classes[] = 'menu-item-' .$item->ID;
            $class_names = esc_attr( implode( ' ', apply_filters( 'nav_menu_css_class', array_filter( $classes ), $item ) ) );

            if($depth == 1) {
                $output .= $indent . '<li class="' . esc_attr( $class_names ) . '" data-column="'.esc_attr( $item->item_column ? $item->item_column : 1).'">';
            }
            else{
                $output .= $indent . '<li  class="' . esc_attr( $class_names ) . '">';
            }

            // link attributes
            $attributes  = ! empty( $item->attr_title ) ? ' title="'  . esc_attr( $item->attr_title ) .'"' : '';
            $attributes .= ! empty( $item->target )     ? ' target="' . esc_attr( $item->target     ) .'"' : '';
            $attributes .= ! empty( $item->xfn )        ? ' rel="'    . esc_attr( $item->xfn        ) .'"' : '';
            $attributes .= ! empty( $item->url )        ? ' href="'   . esc_attr( $item->url        ) .'"' : '';

            $item_output = $args->before;
            $item_output .= '<a'. $attributes .'>';
            $item_output .= $args->link_before . ($item->icon ? '<i class="mm-icon '.esc_attr($item->icon).'"></i>' : '') ;
            if($depth != 0 || ( $depth == 0 && !$item->only_icon )){
                $item_output .= apply_filters( 'the_title', $item->title, $item->ID );
            }
            $item_output .= $args->link_after;
            if($depth == 0 && !empty($args->show_menu_item_description) && $args->show_menu_item_description && !empty($item->description)){
                $item_output .= '<span class="mm-desc">'.esc_html($item->description).'</span>';
            }
            if ($item->tip_label) {
                $tip_style = '';
                $tip_arrow_style = '';
                if ($item->tip_color) {
                    $tip_style .= 'color:'.$item->tip_color.';';
                }
                if ($item->tip_background_color) {
                    $tip_style .= 'background:'.$item->tip_background_color.';';
                    $tip_arrow_style .= 'color:'.$item->tip_background_color.';';
                }
                $item_output .= '<span class="tip" style="'.esc_attr( $tip_style ).'"><span class="tip-arrow" style="'.esc_attr( $tip_arrow_style ).'"></span>'. esc_html( $item->tip_label ) .'</span>';
            }
            $item_output .= '</a>';
            if ($item->block){
                $item_output .= '<div class="mm-menu-block menu-block-after">'.do_shortcode('[la_block id="'.esc_attr($item->block).'"]').'</div>';
            }

            $item_output .= $args->after;

            // build html
            $output .= apply_filters( 'walker_nav_menu_start_el', $item_output, $item, $depth, $args );
        }

        public static function compress_text($content){
            $content = preg_replace('!/\*[^*]*\*+([^/][^*]*\*+)*/!', '', $content);
            $content = str_replace(array("\r\n", "\r", "\n", "\t", '	', '	', '	'), '', $content);
            return $content;
        }

        public static function fallback( $args ){
            ?><ul class="main-menu mega-menu"><?php
            echo str_replace( array("page_item","<ul class='children'>"), array("page_item menu-item","<ul class='sub-menu'>"), wp_list_pages('number=4&depth=1&echo=0&title_li=') );
            ?></ul><?php
        }
    }
}