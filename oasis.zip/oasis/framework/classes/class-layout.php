<?php if ( ! defined( 'ABSPATH' ) ) { die; }

if(!class_exists('Oasis_Layout')){
    class Oasis_Layout{

        public function __construct() {

            add_filter( 'oasis/filter/main_menu_location', array( $this, 'getMainNavArgs' ) );
            add_filter( 'oasis/filter/show_page_header', array( $this, 'checkConditionShowPageHeader' ) );

            add_action( 'wp_head', array( $this, 'addPageLoaderCss' ), 1 );
            add_action( 'oasis/action/before_render_body', array( $this, 'getPageLoaderIcon' ), 1 );

            add_action( 'oasis/action/before_render_main', array( $this, 'getBlockContentTop' ) );
            add_action( 'oasis/action/before_render_main_inner', array( $this, 'getBlockContentInnerTop' ) );
            add_action( 'oasis/action/after_render_main_inner', array( $this, 'getBlockContentInnerBottom' ) );
            add_action( 'oasis/action/after_render_main', array( $this, 'getBlockContentBottom' ) );

        }

        public function getSiteLayout(){
            $meta_key = OASIS_OPTION;
            $meta_param = 'layout';

            $value = $value_default = Oasis_Helper::getOption($meta_param,'col-1c');
            $value_shop = Oasis_Helper::getOption('shop_layout',$value_default);
            $value_blog = Oasis_Helper::getOption('blog_layout',$value_default);

            if($value_shop == 'inherit'){
                $value_shop = $value_default;
            }
            if($value_blog == 'inherit'){
                $value_blog = $value_default;
            }

            if (is_front_page() || is_home()){
                if(is_front_page()){
                    $value = $value_default;
                }elseif(is_home()){
                    $value = $value_blog;
                }
                $_value = Oasis_Helper::getPostMeta(get_queried_object_id() , $meta_key, $meta_param);
                if(!empty($_value) && $_value !== 'inherit'){
                    $value = $_value;
                }
            }
            elseif(is_singular()){
                switch (get_query_var('post_type')) {
                    case 'product':
                        $_value = Oasis_Helper::getOption('product_layout',$value_shop);
                        if(!empty($_value) && $_value != 'inherit'){
                            $value = $_value;
                        }
                        break;
                    case 'la_portfolio':
                        $_value = Oasis_Helper::getOption('single_portfolio_layout',$value_blog);
                        if(!empty($_value) && $_value != 'inherit'){
                            $value = $_value;
                        }
                        break;
                    case 'attachment':
                        $_value = Oasis_Helper::getOption('single_post_layout',$value_blog);
                        if(!empty($_value) && $_value != 'inherit'){
                            $value = $_value;
                        }
                        break;
                    default:
                        $_value = Oasis_Helper::getOption('single_post_layout',$value_blog);
                        if(!empty($_value) && $_value != 'inherit'){
                            $value = $_value;
                        }
                }
                $_value = Oasis_Helper::getPostMeta( get_queried_object_id() , $meta_key, $meta_param);
                if(!empty($_value) && $_value !== 'inherit'){
                    $value = $_value;
                }
            }
            else{
                if(is_archive()){
                    if( function_exists('is_shop') && is_post_type_archive('product')){
                        $value = $value_shop;
                        $_value = Oasis_Helper::getPostMeta( wc_get_page_id('shop') , $meta_key, $meta_param);
                        if(!empty($_value) && $_value !== 'inherit'){
                            $value = $_value;
                        }
                    }
                    elseif (is_post_type_archive('la_portfolio')) {
                        $_value = Oasis_Helper::getOption('portfolio_layout',$value_default);
                        if(!empty($_value) && $_value != 'inherit'){
                            $value = $_value;
                        }
                    }
                    elseif ( is_tax() || is_category() || is_tag() ){
                        if(is_category() || is_tag()){
                            $value = $value_blog;
                        }
                        elseif( is_tax( get_object_taxonomies( 'product' ) ) ){
                            $value = $value_shop;
                        }
                        elseif( is_tax( get_object_taxonomies( 'la_portfolio' ) ) ){
                            $_value = Oasis_Helper::getOption('portfolio_layout',$value_default);
                            if(!empty($_value) && $_value != 'inherit'){
                                $value = $_value;
                            }
                        }
                        $_value = Oasis_Helper::getTermMeta( get_queried_object_id() , $meta_key, $meta_param );
                        if(!empty($_value) && $_value !== 'inherit'){
                            $value = $_value;
                        }
                    }
                }
                elseif(is_search()){
                    $value = $value_default;
                }
                elseif(is_404()){
                    $value = 'col-1c';
                }
            }
            return apply_filters('oasis/filter/site_layout',$value);
        }

        public function getMainContentCssClass( $el_class = '' ){
            switch($this->getSiteLayout()){
                case 'col-2cl':
                    $_class = 'col-md-9 col-md-push-3';
                    break;
                case 'col-2cr':
                    $_class = 'col-md-9';
                    break;
                case 'col-2cl-l':
                    $_class = 'col-md-8 col-md-push-4';
                    break;
                case 'col-2cr-l':
                    $_class = 'col-md-8';
                    break;
                case 'col-3cl':
                    $_class = 'col-md-6';
                    break;
                case 'col-3cm':
                    $_class = 'col-md-6';
                    break;
                case 'col-3cr':
                    $_class = 'col-md-6';
                    break;
                default:
                    $_class = 'col-md-12';
            }
            return $_class . ' ' . $el_class;
        }

        public function getMainSidebarCssClass($el_class = ''){
            switch($this->getSiteLayout()){
                case 'col-2cl':
                    $_class = 'col-md-3 col-md-pull-9';
                    break;
                case 'col-2cr':
                    $_class = 'col-md-3';
                    break;
                case 'col-2cl-l':
                    $_class = 'col-md-4 col-md-pull-8';
                    break;
                case 'col-2cr-l':
                    $_class = 'col-md-4';
                    break;
                case 'col-3cl':
                    $_class = 'col-md-3';
                    break;
                case 'col-3cm':
                    $_class = 'col-md-3';
                    break;
                case 'col-3cr':
                    $_class = 'col-md-3';
                    break;
                default:
                    $_class = 'hidden';
            }
            return $_class . ' ' . $el_class;
        }

        public function getSecondSidebarCssClass( $el_class ){
            switch($this->getSiteLayout()){
                case 'col-3cl':
                    $_class = 'col-md-3';
                    break;
                case 'col-3cm':
                    $_class = 'col-md-3';
                    break;
                case 'col-3cr':
                    $_class = 'col-md-3';
                    break;
                default:
                    $_class = 'hidden';
            }
            return $_class . ' ' . $el_class;
        }

        public function getLogoUrl(){
            $logo_src = wp_get_attachment_image_url(Oasis_Helper::getOption('logo'), 'full');
            if($logo_src === false){
                $logo_src = get_template_directory_uri() . '/assets/images/logo.png';
            }
            return $logo_src;
        }

        public function getLogoRetinaUrl(){
            $logo_src = wp_get_attachment_image_url(Oasis_Helper::getOption('logo_2x'), 'full');
            return $logo_src;
        }

        public function getTransparencyLogoUrl(){
            $logo_src = wp_get_attachment_image_url(Oasis_Helper::getOption('logo_transparency'), 'full');
            if($logo_src === false){
                $logo_src = get_template_directory_uri() . '/assets/images/logo.png';
            }
            return $logo_src;
        }

        public function getTransparencyLogoRetinaUrl(){
            $logo_src = wp_get_attachment_image_url(Oasis_Helper::getOption('logo_transparency_2x'), 'full');
            return $logo_src;
        }

        public function getStickyLogoUrl(){
            $logo_src = wp_get_attachment_image_url(Oasis_Helper::getOption('logo_sticky'), 'full');
            if($logo_src === false){
                $logo_src = get_template_directory_uri() . '/assets/images/logo.png';
            }
            return $logo_src;
        }

        public function getStickyLogoRetinaUrl(){
            $logo_src = wp_get_attachment_image_url(Oasis_Helper::getOption('logo_sticky_2x'), 'full');
            return $logo_src;
        }
        public function getMobileLogoUrl(){
            $logo_src = wp_get_attachment_image_url(Oasis_Helper::getOption('logo_mobile'), 'full');
            if($logo_src === false){
                $logo_src = get_template_directory_uri() . '/assets/images/logo.png';
            }
            return $logo_src;
        }

        public function getMobileLogoRetinaUrl(){
            $logo_src = wp_get_attachment_image_url(Oasis_Helper::getOption('logo_mobile_2x'), 'full');
            return $logo_src;
        }


        public function renderLogo(){
            printf(
                '<img src="%1$s" alt="%2$s"%3$s/>',
                esc_url($this->getLogoUrl()),
                esc_attr(get_bloginfo('name')),
                (false !== $this->getLogoRetinaUrl() ? ' srcset="'.esc_url($this->getLogoRetinaUrl()).' 2x"' : '')
            );
        }

        public function renderStickyLogo(){
            printf(
                '<img src="%1$s" alt="%2$s"%3$s/>',
                esc_url($this->getStickyLogoUrl()),
                esc_attr(get_bloginfo('name')),
                (false !== $this->getStickyLogoRetinaUrl() ? ' srcset="'.esc_url($this->getStickyLogoRetinaUrl()).' 2x"' : '')
            );
        }

        public function renderTransparencyLogo(){
            printf(
                '<img src="%1$s" alt="%2$s"%3$s/>',
                esc_url($this->getTransparencyLogoUrl()),
                esc_attr(get_bloginfo('name')),
                (false !== $this->getTransparencyLogoRetinaUrl() ? ' srcset="'.esc_url($this->getTransparencyLogoRetinaUrl()).' 2x"' : '')
            );
        }

        public function renderMobileLogo(){
            printf(
                '<img src="%1$s" alt="%2$s"%3$s/>',
                esc_url($this->getMobileLogoUrl()),
                esc_attr(get_bloginfo('name')),
                (false !== $this->getMobileLogoRetinaUrl() ? ' srcset="'.esc_url($this->getMobileLogoRetinaUrl()).' 2x"' : '')
            );
        }

        public function renderHeaderTpl(){
            if(Oasis_Helper::getOptionByQuery('hide_header')){
                return;
            }
            $value = Oasis_Helper::getOptionByQuery('header_layout','1');
            do_action('oasis/action/before_render_header',$value);
            get_template_part('headers/header',$value);
            do_action('oasis/action/after_render_header',$value);
        }

        public function renderHeaderMobileTpl(){
            get_template_part('headers/header', 'mobile');
        }

        public function renderFooterTpl(){
            if(Oasis_Helper::getOptionByQuery('hide_footer')){
               return;
            }
            $value = Oasis_Helper::getOptionByQuery('footer_layout','1');
            do_action('oasis/action/before_render_footer',$value);
            get_template_part('footers/footer',$value);
            do_action('oasis/action/after_render_footer',$value);
        }

        public function renderPageHeaderTpl(){
            if( apply_filters( 'oasis/filter/show_page_header', true ) ){
                $value = Oasis_Helper::getOptionByQuery('page_header_layout','1');
                do_action('oasis/action/before_render_page_header',$value);
                get_template_part('page-header/page-header',$value);
                do_action('oasis/action/after_render_page_header',$value);
            }
        }

        public function renderMainNav($args = array()){
            $default = array(
                'container'     => false,
                'menu_class'    => 'main-menu mega-menu',
                'link_before'   => '<span class="mm-text">',
                'link_after'    => '</span>',
                'fallback_cb'   => array( 'Oasis_Walker_Menu', 'fallback' ),
                'walker'        => new Oasis_Walker_Menu
            );

            $menu_args = array_merge( $default, apply_filters( 'oasis/filter/main_menu_location' , array(
                'theme_location' => 'main-nav',
            )) ,$args );

            do_action('oasis/action/before_render_main_menu');
            wp_nav_menu($menu_args);
            do_action('oasis/action/after_render_main_menu');
        }

        public function getMainNavArgs($args){
            if($menu_id = Oasis_Helper::getOptionByMetadata('main_menu',false)){
                if(is_nav_menu($menu_id)){
                    $args = array(
                        'menu' => $menu_id
                    );
                }
            }
            return $args;
        }

        public function getPageTitle(){
            if(class_exists('Oasis_Page_Title')){
                $page_title = Oasis_Page_Title::instance();
                return $page_title->get_title();
            }
            return '';
        }

        public function getBreadcrumbs(){
            if(class_exists('Oasis_Breadcrumbs')){
                $breadcrumbs = Oasis_Breadcrumbs::instance();
                return $breadcrumbs->get_breadcrumbs();
            }
            return '';
        }

        public function checkConditionShowPageHeader( $boolean ){
            if(is_front_page()){
                return false;
            }
            $page_header_layout = Oasis_Helper::getOptionByQuery('page_header_layout', '1');
            $hide_breadcrumb = Oasis_Helper::getOptionByMetadata('hide_breadcrumb',false);
            $hide_page_title = Oasis_Helper::getOptionByMetadata('hide_page_title',false);
            if('hide' == $page_header_layout){
                $boolean = false;
            }
            if($hide_breadcrumb && $hide_page_title){
                $boolean = false;
            }
            if($hide_page_title){
                add_filter( 'oasis/filter/show_page_title', '__return_false' );
            }
            if($hide_breadcrumb){
                add_filter( 'oasis/filter/show_breadcrumbs', '__return_false' );
            }
            return $boolean;
        }

        public function getBlockContentTop(){
            if( $block_id = Oasis_Helper::getOptionByMetadata('block_content_top',false) ){
                $block_id = absint($block_id);
                if($block_id > 0){
                    printf( '<div class="la-block-content-top">%s</div>',
                        do_shortcode('[la_block id="'. $block_id .'"]')
                    );
                }
            }
        }

        public function getBlockContentInnerTop(){
            if( $block_id = Oasis_Helper::getOptionByMetadata('block_content_inner_top',false) ){
                $block_id = absint($block_id);
                if($block_id > 0){
                    printf('<div class="la-block-content-inner-top">%s</div>',
                        do_shortcode('[la_block id="'. $block_id .'"]')
                    );
                }
            }
        }

        public function getBlockContentInnerBottom(){
            if( $block_id = Oasis_Helper::getOptionByMetadata('block_content_inner_bottom',false) ){
                $block_id = absint($block_id);
                if($block_id > 0){
                    printf( '<div class="la-block-content-inner-bottom">%s</div>',
                        do_shortcode('[la_block id="'. $block_id .'"]')
                    );
                }
            }
        }

        public function getBlockContentBottom(){
            if( $block_id = Oasis_Helper::getOptionByMetadata('block_content_bottom',false) ){
                $block_id = absint($block_id);
                if($block_id > 0){
                    printf( '<div class="la-block-content-bottom">%s</div>',
                        do_shortcode('[la_block id="'. $block_id .'"]')
                    );
                }
            }
        }

        public function getPageLoaderIcon(){
            if(Oasis_Helper::getOption('enable_page_loader')){
                $loading_style = Oasis_Helper::getOption('page_loader_icon_style', '1');
                if($loading_style == 'custom'){
                    if($img = Oasis_Helper::getOption('page_loader_icon_style_custom')){
                        echo '<div class="la-image-loading spinner-custom"><div class="content"><div class="la-loader">'. wp_get_attachment_image($img, 'full') .'</div></div></div>';
                    }else{
                        echo '<div class="la-image-loading"><div class="content"><div class="la-loader spinner1"></div></div></div>';
                    }
                }else{
                    echo '<div class="la-image-loading"><div class="content"><div class="la-loader spinner'.esc_attr($loading_style).'"><div class="dot1"></div><div class="dot2"></div><div class="bounce1"></div><div class="bounce2"></div><div class="bounce3"></div></div></div></div>';
                }

            }
        }

        public function addPageLoaderCss(){
            $css = '
                .site-loading .la-image-loading {
                    opacity: 1;
                    visibility: visible;
                }
                .la-image-loading.spinner-custom .content {
                    width: 100px;
                    margin-top: -50px;
                    height: 100px;
                    margin-left: -50px;
                    text-align: center;
                }
                .la-image-loading.spinner-custom .content img {
                    width: auto;
                    margin: 0 auto;
                }
                .site-loading #page.site{
                    opacity: 0;
                    transition: all .3s ease-in-out;
                }
                #page.site{
                    opacity: 1;
                }
                .la-image-loading {
                    opacity: 0;
                    position: fixed;
                    z-index: 999;
                    left: 0;
                    top: 0;
                    right: 0;
                    bottom: 0;
                    background: #fff;
                    overflow: hidden;
                    transition: all .3s ease-in-out;
                    visibility: hidden;
                }
                .la-image-loading .content {
                    position: absolute;
                    width: 50px;
                    height: 50px;
                    top: 50%;
                    left: 50%;
                    margin-left: -25px;
                    margin-top: -50px;
                }
                .la-loader.spinner1 {
                    height: 100%;
                    width: 100%;
                    display: block;
                    box-shadow: 0px 0px 20px 0px rgba(0,0,0,0.15);
                    -webkit-box-shadow: 0px 0px 20px 0px rgba(0,0,0,0.15);
                    -webkit-animation: la-rotateplane 1.2s infinite ease-in-out;
                    animation: la-rotateplane 1.2s infinite ease-in-out;
                    border-radius: 3px;
                    -moz-border-radius: 3px;
                    -webkit-border-radius: 3px;
                    background-color: '. esc_attr(Oasis_Helper::getOption("primary_color", "#ce1a2b")) .';
                }
                @-webkit-keyframes la-rotateplane {
                  0% { -webkit-transform: perspective(120px) }
                  50% { -webkit-transform: perspective(120px) rotateY(180deg) }
                  100% { -webkit-transform: perspective(120px) rotateY(180deg)  rotateX(180deg) }
                }

                @keyframes la-rotateplane {
                  0% { transform: perspective(120px) rotateX(0deg) rotateY(0deg);}
                  50% { transform: perspective(120px) rotateX(-180.1deg) rotateY(0deg);}
                  100% { transform: perspective(120px) rotateX(-180deg) rotateY(-179.9deg);}
                }
                .la-loader.spinner2 {
                    width: 40px;
                    height: 40px;
                    margin-top:-20px;margin-left:-20px;
                    background-color: '. esc_attr(Oasis_Helper::getOption("primary_color", "#ce1a2b")) .';
                    box-shadow: 0px 0px 20px 0px rgba(0,0,0,0.15);
                    -webkit-box-shadow: 0px 0px 20px 0px rgba(0,0,0,0.15);
                    border-radius: 100%;
                    -webkit-animation: la-scaleout 1.0s infinite ease-in-out;
                    animation: la-scaleout 1.0s infinite ease-in-out;
                }

                @-webkit-keyframes la-scaleout {
                  0% { -webkit-transform: scale(0.0) }
                  100% {-webkit-transform: scale(1.0); opacity: 0;}
                }

                @keyframes la-scaleout {
                  0% {transform: scale(0.0);-webkit-transform: scale(0.0);}
                  100% {transform: scale(1.0);-webkit-transform: scale(1.0);opacity: 0;}
                }

                .la-loader.spinner3 {
                  margin: -9px 0px 0px -35px;
                  width: 70px;
                  text-align: center;
                }

                .la-loader.spinner3 .bounce1,
                .la-loader.spinner3 .bounce2,
                .la-loader.spinner3 .bounce3 {
                  width: 18px;
                  height: 18px;
                  background-color: '. esc_attr(Oasis_Helper::getOption("primary_color", "#ce1a2b")) .';
                  box-shadow: 0px 0px 20px 0px rgba(0,0,0,0.15);
                  -webkit-box-shadow: 0px 0px 20px 0px rgba(0,0,0,0.15);
                  border-radius: 100%;
                  display: inline-block;
                  -webkit-animation: la-bouncedelay 1.4s infinite ease-in-out;
                  animation: la-bouncedelay 1.4s infinite ease-in-out;
                  /* Prevent first frame from flickering when animation starts */
                  -webkit-animation-fill-mode: both;
                  animation-fill-mode: both;
                }

                .la-loader.spinner3 .bounce1 {
                  -webkit-animation-delay: -0.32s;
                  animation-delay: -0.32s;
                }

                .la-loader.spinner3 .bounce2 {
                  -webkit-animation-delay: -0.16s;
                  animation-delay: -0.16s;
                }

                @-webkit-keyframes la-bouncedelay {
                  0%, 80%, 100% { -webkit-transform: scale(0.0) }
                  40% { -webkit-transform: scale(1.0) }
                }

                @keyframes la-bouncedelay {
                  0%, 80%, 100% {transform: scale(0.0);}
                  40% {transform: scale(1.0);}
                }

                .la-loader.spinner4 {
                  margin: -20px 0px 0px -20px;
                  width: 40px;
                  height: 40px;
                  text-align: center;
                  -webkit-animation: la-rotate 2.0s infinite linear;
                  animation: la-rotate 2.0s infinite linear;
                }

                .la-loader.spinner4 .dot1,
                .la-loader.spinner4 .dot2 {
                  width: 60%;
                  height: 60%;
                  display: inline-block;
                  position: absolute;
                  top: 0;
                  background-color: '. esc_attr(Oasis_Helper::getOption("primary_color", "#ce1a2b")) .';
                  border-radius: 100%;
                  -webkit-animation: la-bounce 2.0s infinite ease-in-out;
                  animation: la-bounce 2.0s infinite ease-in-out;
                  box-shadow: 0px 0px 20px 0px rgba(0,0,0,0.15);
                  -webkit-box-shadow: 0px 0px 20px 0px rgba(0,0,0,0.15);
                }

                .la-loader.spinner4 .dot2 {
                  top: auto;
                  bottom: 0px;
                  -webkit-animation-delay: -1.0s;
                  animation-delay: -1.0s;
                }

                @-webkit-keyframes la-rotate { 100% { -webkit-transform: rotate(360deg) }}
                @keyframes la-rotate { 100% { transform: rotate(360deg); -webkit-transform: rotate(360deg) }}

                @-webkit-keyframes la-bounce {
                  0%, 100% { -webkit-transform: scale(0.0) }
                  50% { -webkit-transform: scale(1.0) }
                }

                @keyframes la-bounce {
                  0%, 100% {transform: scale(0.0);}
                  50% { transform: scale(1.0);}
                }

                ';
            printf(
                '<%s>%s</%s>',
                'style',
                Oasis_Helper::compressText($css),
                'style'
            );
        }
    }
}