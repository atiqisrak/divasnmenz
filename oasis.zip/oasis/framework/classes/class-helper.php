<?php if ( ! defined( 'ABSPATH' ) ) { die; }

if(!class_exists('Oasis_Helper')){

    class Oasis_Helper{

        public static function isActivePlugin( $plugin ){
            include_once ABSPATH . 'wp-admin/includes/plugin.php';
            return is_plugin_active($plugin);
        }

        public static function isActiveWooCommerce(){
            return self::isActivePlugin('woocommerce/woocommerce.php');
        }

        public static function compressText($content){
            $content = preg_replace('!/\*[^*]*\*+([^/][^*]*\*+)*/!', '', $content);
            $content = str_replace(array("\r\n", "\r", "\n", "\t", '	', '	', '	', '                ', '    '), '', $content);
            return $content;
        }

        public static function writeLog($log){
            if ( true === WP_DEBUG ) {
                if ( is_array( $log ) || is_object( $log ) ) {
                    error_log( print_r( $log, true ) );
                } else {
                    error_log( $log );
                }
            }
        }

        public static function get_hooks( $hook = '' ) {
            global $wp_filter;

            $hooks = isset( $wp_filter[$hook] ) ? $wp_filter[$hook] : array();
            if(empty($hooks)){
                return;
            }
            if ($hooks instanceof WP_Hook) {
                $hooks = $hooks->callbacks;
            }
            if(!empty($hook)){
                foreach( $hooks as $key => &$items ) {
                    foreach ( $items as &$item ){
                        $item['priority'] = $key;
                    }
                }
            }
            $hooks = call_user_func_array( 'array_merge', $hooks );

            foreach( $hooks as $key => &$item ) {
                // function name as string or static class method eg. 'Foo::Bar'
                if ( is_string( $item['function'] ) ) {
                    $ref = strpos( $item['function'], '::' ) ? new ReflectionClass( strstr( $item['function'], '::', true ) ) : new ReflectionFunction( $item['function'] );
                    $item['file'] = $ref->getFileName();
                    $item['line'] = get_class( $ref ) == 'ReflectionFunction'
                        ? $ref->getStartLine()
                        : $ref->getMethod( substr( $item['function'], strpos( $item['function'], '::' ) + 2 ) )->getStartLine();

                    // array( object, method ), array( string object, method ), array( string object, string 'parent::method' )
                } elseif ( is_array( $item['function'] ) ) {

                    $ref = new ReflectionClass( $item['function'][0] );

                    // $item['function'][0] is a reference to existing object
                    $item['function'] = array(
                        is_object( $item['function'][0] ) ? get_class( $item['function'][0] ) : $item['function'][0],
                        $item['function'][1]
                    );
                    $item['file'] = $ref->getFileName();
                    $item['line'] = strpos( $item['function'][1], '::' )
                        ? $ref->getParentClass()->getMethod( substr( $item['function'][1], strpos( $item['function'][1], '::' ) + 2 ) )->getStartLine()
                        : $ref->getMethod( $item['function'][1] )->getStartLine();

                    // closures
                } elseif ( is_callable( $item['function'] ) ) {
                    $ref = new ReflectionFunction( $item['function'] );
                    $item['function'] = get_class( $item['function'] );
                    $item['file'] = $ref->getFileName();
                    $item['line'] = $ref->getStartLine();
                }
            }
            echo '<pre>';
            echo "HOOK NAME : <b>$hook</b><br/>";
            print_r($hooks);
            echo '</pre>';
        }

        public static function removeJsWpAutop($content, $autop = false){
            if ( $autop ) {
                $content = preg_replace( '/<\/?p\>/', "\n", $content );
                $content = preg_replace( '/<p[^>]*><\\/p[^>]*>/', "", $content );
                $content = wpautop( $content . "\n" );
            }
            return do_shortcode( shortcode_unautop( $content ) );
        }

        public static function getOption( $option_name = '', $default = '', $mode = null ){
            $options = apply_filters( 'oasis/filter/getOption', get_option( $mode === null ? OASIS_OPTION : OASIS_CUSTOMIZE_OPTION ), $option_name, $default );
            if( ! empty( $option_name ) && ! empty( $options[$option_name] ) ) {
                return $options[$option_name];
            } else {
                return ( ! empty( $default ) ) ? $default : null;
            }
        }

        public static function getPostMeta( $id, $key = OASIS_OPTION, $param = null, $single = true){
            $GLOBALS['oasis_post_metadata'] = isset( $GLOBALS['oasis_post_metadata'] ) ? $GLOBALS['oasis_post_metadata'] : array();
            if ( ! is_numeric( $id ) ) {
                return false;
            }
            if ( ! isset( $GLOBALS['oasis_post_metadata'][ $id ] ) ) {
                $GLOBALS['oasis_post_metadata'][ $id ] = get_post_meta( $id );
            }
            if ( !empty( $key ) && isset( $GLOBALS['oasis_post_metadata'][ $id ][$key] ) && !empty( $GLOBALS['oasis_post_metadata'][ $id ][$key] ) ) {
                if ( $single ){
                    $post_meta = maybe_unserialize( $GLOBALS['oasis_post_metadata'][ $id ][$key][0] );
                    if($param !== null){
                        if(isset($post_meta[$param])){
                            return $post_meta[$param];
                        }else{
                            return false;
                        }
                    }else{
                        return $post_meta;
                    }
                }
                else{
                    $post_meta_arrays = array_map( 'maybe_unserialize', $GLOBALS['oasis_post_metadata'][ $id ][$key] );
                    if($param !== null){
                        $tmp = array();
                        foreach ( $post_meta_arrays as $post_meta_value){
                            if(isset($post_meta_value[$param])){
                                $tmp[] = $post_meta_value[$param];
                            }
                        }
                        return $tmp;
                    }else{
                        return $post_meta_arrays;
                    }
                }
            }
            if ( $single ){
                return false;
            }
            else{
                return array();
            }
        }

        public static function getTermMeta( $id, $key = OASIS_OPTION, $param = null, $single = true ){
            $GLOBALS['oasis_term_metadata'] = isset( $GLOBALS['oasis_term_metadata'] ) ? $GLOBALS['oasis_term_metadata'] : array();

            if ( ! is_numeric( $id ) ) {
                return false;
            }
            if ( ! isset( $GLOBALS['oasis_term_metadata'][ $id ] ) ) {
                $GLOBALS['oasis_term_metadata'][$id] = get_term_meta($id);
            }
            if ( !empty( $key ) && isset( $GLOBALS['oasis_term_metadata'][$id][$key] ) && !empty( $GLOBALS['oasis_term_metadata'][$id][$key] ) ) {
                if ( $single ){
                    $term_meta = maybe_unserialize( $GLOBALS['oasis_term_metadata'][ $id ][$key][0] );
                    if($param !== null){
                        if(isset($term_meta[$param])){
                            return $term_meta[$param];
                        }else{
                            return false;
                        }
                    }else{
                        return $term_meta;
                    }
                }
                else{
                    $term_meta_arrays = array_map( 'maybe_unserialize', $GLOBALS['oasis_term_metadata'][ $id ][$key] );
                    if($param !== null){
                        $tmp = array();
                        foreach ( $term_meta_arrays as $term_meta_value){
                            if(isset($term_meta_value[$param])){
                                $tmp[] = $term_meta_value[$param];
                            }
                        }
                        return $tmp;
                    }else{
                        return $term_meta_arrays;
                    }
                }
            }
            if ( $single ){
                return false;
            }
            else{
                return array();
            }
        }

        public static function getOptionByQuery($meta_param, $default = '', $meta_param_global = null, $meta_key = OASIS_OPTION , $blog_value_default = null, $shop_value_default = null){
            if($meta_param_global == null){
                $meta_param_global = $meta_param;
            }
            $value = $value_default = self::getOption($meta_param_global,$default);
            $value_shop = ( $shop_value_default !== null ) ? $shop_value_default : $value_default;
            $value_blog = ( $blog_value_default !== null ) ? $blog_value_default : $value_default;

            if(is_front_page() || is_home()){
                if(is_front_page()){
                    $value = $value_default;
                }elseif(is_home()){
                    $value = $value_blog;
                }
                $_value = self::getPostMeta( get_queried_object_id() , $meta_key, $meta_param);
                if(!empty($_value) && $_value !== 'inherit'){
                    $value = $_value;
                }
            }
            elseif(is_singular()){
                switch (get_query_var('post_type')) {
                    case 'product':
                        $value = $value_shop;
                        break;
                    case 'la_portfolio':
                        $value = $value_default;
                        break;
                    case 'post':
                        $value = $value_blog;
                        break;
                    default:
                        $value = $value_default;
                }
                $_value = self::getPostMeta( get_queried_object_id() , $meta_key, $meta_param);
                if(!empty($_value) && $_value !== 'inherit'){
                    $value = $_value;
                }
            }else{

                if( is_post_type_archive('la_portfolio') ){
                    $_value = self::getOption('portfolio_' . $meta_param);
                    if(!empty($_value) && $_value !== 'inherit'){
                        $value = $_value;
                    }
                }
                elseif( function_exists('is_shop') && is_post_type_archive('product')){
                    $value = $value_shop;
                    $_value = self::getPostMeta( wc_get_page_id('shop') , $meta_key, $meta_param);
                    if(!empty($_value) && $_value !== 'inherit'){
                        $value = $_value;
                    }
                }
                elseif( is_tax( get_object_taxonomies( 'product' ) ) ){
                    $value = $value_shop;
                    $_value = self::getTermMeta( get_queried_object_id(), $meta_key, $meta_param);
                    if(!empty($_value) && $_value !== 'inherit'){
                        $value = $_value;
                    }
                }
                elseif( is_tax( get_object_taxonomies( 'la_portfolio' ) ) ){

                    $_value_archive = self::getOption('portfolio_' . $meta_param);

                    if(!empty($_value_archive) && $_value_archive !== 'inherit'){
                        $value = $_value_archive;
                    }else{
                        $value = $value_default;
                    }

                    $_value = self::getTermMeta( get_queried_object_id(), $meta_key, $meta_param);
                    if(!empty($_value) && $_value !== 'inherit'){
                        $value = $_value;
                    }
                }
                elseif( is_tag() || is_category() ){
                    $value = $value_blog;
                    $_value = self::getTermMeta( get_queried_object_id(), $meta_key, $meta_param);
                    if(!empty($_value) && $_value !== 'inherit'){
                        $value = $_value;
                    }
                }
                else{
                    $value = $value_default;
                }
            }
            return apply_filters('oasis/filter/getOptionByQuery', $value, $meta_param, $meta_param_global, $meta_key);
        }

        public static function getOptionByMetadata( $meta_param, $default = '', $meta_key = OASIS_OPTION){
            if(empty($meta_param)){
                return $default;
            }
            $value = false;
            if(is_singular()){
                if ( $_value = self::getPostMeta( get_queried_object_id(), $meta_key, $meta_param ) ) {
                    if(!empty($_value) && $_value !== 'inherit'){
                        $value = $_value;
                    }
                }
            }else{
                if(is_front_page() || is_home()){
                    if ( $_value = self::getPostMeta( get_queried_object_id(), $meta_key, $meta_param ) ) {
                        if(!empty($_value) && $_value !== 'inherit'){
                            $value = $_value;
                        }
                    }
                }
                elseif( function_exists('is_shop') && is_shop() ){
                    if ( $_value = self::getPostMeta( wc_get_page_id('shop'), $meta_key, $meta_param ) ) {
                        if(!empty($_value) && $_value !== 'inherit'){
                            $value = $_value;
                        }
                    }
                }
                elseif(is_tax() || is_tag() || is_category()){
                    if ( $_value = self::getTermMeta( get_queried_object_id(), $meta_key, $meta_param ) ) {
                        if(!empty($_value) && $_value !== 'inherit'){
                            $value = $_value;
                        }
                    }
                }
            }
            return apply_filters('oasis/filter/getOptionByMetadata', ($value === false ? $default : $value), $meta_param, $default, $meta_key);
        }

        public static function hex2rgba( $color, $opacity = false ) {
            $default = 'rgb(0,0,0)';
            if(empty($color)){
                return $default;
            }
            if ($color[0] == '#' ) {
                $color = substr( $color, 1 );
            }
            if (strlen($color) == 6) {
                $hex = array( $color[0] . $color[1], $color[2] . $color[3], $color[4] . $color[5] );
            } elseif ( strlen( $color ) == 3 ) {
                $hex = array( $color[0] . $color[0], $color[1] . $color[1], $color[2] . $color[2] );
            } else {
                return $default;
            }
            $rgb =  array_map('hexdec', $hex);
            if($opacity){
                if(abs($opacity) > 1)
                    $opacity = 1.0;
                $output = 'rgba('.implode(",",$rgb).','.$opacity.')';
            } else {
                $output = 'rgb('.implode(",",$rgb).')';
            }
            return $output;
        }

        public static function buildMemberSocial($id = 0){
            $output = '<div class="item--social member-social">';
            if(($facebook = self::getPostMeta($id, OASIS_OPTION, 'facebook')) && !empty($facebook)){
                $output .= sprintf('<a class="social-facebook" href="%s"><i class="fa fa-facebook-f"></i></a>', esc_url($facebook));
            }
            if(($twitter = self::getPostMeta($id, OASIS_OPTION, 'twitter')) && !empty($twitter)){
                $output .= sprintf('<a class="social-facebook" href="%s"><i class="fa fa-twitter"></i></a>', esc_url($twitter));
            }
            if(($pinterest = self::getPostMeta($id, OASIS_OPTION, 'pinterest')) && !empty($pinterest)){
                $output .= sprintf('<a class="social-facebook" href="%s"><i class="fa fa-pinterest-p"></i></a>', esc_url($pinterest));
            }
            if(($dribbble = self::getPostMeta($id, OASIS_OPTION, 'dribbble')) && !empty($dribbble)){
                $output .= sprintf('<a class="social-facebook" href="%s"><i class="fa fa-dribbble"></i></a>', esc_url($dribbble));
            }
            if(($gplus = self::getPostMeta($id, OASIS_OPTION, 'gplus')) && !empty($gplus)){
                $output .= sprintf('<a class="social-facebook" href="%s"><i class="fa fa-google"></i></a>', esc_url($gplus));
            }
            if(($email = self::getPostMeta($id, OASIS_OPTION, 'email')) && !empty($email)){
                $output .= sprintf('<a class="social-email" href="%s"><i class="fa fa-envelope-o"></i></a>', esc_url('mailto:'.$email));
            }
            $output .= '</div>';
            return $output;
        }

        public static function getImageHwString($size){
            $out = '';
            if(is_array($size)){
                $out = image_hwstring($size[0],$size[1]);
            }else{
                global $_wp_additional_image_sizes;
                if(in_array($size, $_wp_additional_image_sizes)){
                    $out = image_hwstring($_wp_additional_image_sizes[$size]['width'], $_wp_additional_image_sizes[$size]['height']);
                }
            }
            return $out;
        }

        public static function getImagePlaceHolder($size){
            ?><img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/placeholder.png')?>" alt=""<?php
            if(is_array($size)){
                echo ' width="' . esc_attr($size[0]) . '" height="' . esc_attr($size[1]) . '"';
            }else{
                global $_wp_additional_image_sizes;
                if(array_key_exists($size, $_wp_additional_image_sizes)){
                    echo ' width="' . esc_attr($_wp_additional_image_sizes[$size]['width']) . '" height="' . esc_attr($_wp_additional_image_sizes[$size]['height']) . '"';
                }
            }
            ?>/><?php
        }

        public static function getColumnFromShortcodeAtts( $atts ){
            $array = array(
                'xlg'	=> 1,
                'lg' 	=> 1,
                'md' 	=> 1,
                'sm' 	=> 1,
                'xs' 	=> 1
            );
            $atts = explode(';',$atts);
            if(!empty($atts)){
                foreach($atts as $val){
                    $val = explode(':',$val);
                    if(isset($val[0]) && isset($val[1])){
                        if(isset($array[$val[0]])){
                            $array[$val[0]] = absint($val[1]);
                        }
                    }
                }
            }
            return $array;
        }

        public static function getImageSizeFormString($thumb_size, $default = 'thumbnail'){
            if( strpos($thumb_size, 'la_') !== FALSE ){
                return $thumb_size;
            }
            global $_wp_additional_image_sizes;
            if ( is_string( $thumb_size ) && ( ( ! empty( $_wp_additional_image_sizes[ $thumb_size ] ) && is_array( $_wp_additional_image_sizes[ $thumb_size ] ) ) || in_array( $thumb_size, array(
                        'thumbnail',
                        'thumb',
                        'medium',
                        'large',
                        'full',
                    ) ) )
            ) {
                return $thumb_size;
            }
            else{
                preg_match_all( '/\d+/', $thumb_size, $thumb_matches );
                if ( isset( $thumb_matches[0] ) ) {
                    $thumb_size = array();
                    if ( count( $thumb_matches[0] ) > 1 ) {
                        $thumb_size[] = $thumb_matches[0][0]; // width
                        $thumb_size[] = $thumb_matches[0][1]; // height
                    } elseif ( count( $thumb_matches[0] ) > 0 && count( $thumb_matches[0] ) < 2 ) {
                        $thumb_size[] = $thumb_matches[0][0]; // width
                        $thumb_size[] = 0; //$thumb_matches[0][0]; // height
                    } else {
                        $thumb_size = $default;
                    }
                }else{
                    $thumb_size = $default;
                }
                return $thumb_size;
            }
        }

        public static function getSliderConfigs($default = array()){
            $configs = array_merge($configs = array(
                'infinite' => false,
                'xlg' => 1,
                'lg' => 1,
                'md' => 1,
                'sm' => 1,
                'xs' => 1,
                'dots' => false,
                'autoplay' => false,
                'arrows' => false,
                'speed' => 1000,
                'autoplaySpeed' => 3000,
                'custom_nav' => ''
            ), $default);
            $slider_config = array(
                'infinite' => $configs['infinite'],
                'dots' => $configs['dots'],
                'slidesToShow' => $configs['xlg'],
                'slidesToScroll' => $configs['xlg'],
                'autoplay' => $configs['autoplay'],
                'arrows' => $configs['arrows'],
                'speed' => $configs['speed'],
                'autoplaySpeed' => $configs['autoplaySpeed'],
                'responsive' => array(
                    array(
                        'breakpoint' => 1200,
                        'settings' => array(
                            'slidesToShow' => $configs['lg'],
                            'slidesToScroll' => $configs['lg']
                        )
                    ),
                    array(
                        'breakpoint' => 1024,
                        'settings' => array(
                            'slidesToShow' => $configs['md'],
                            'slidesToScroll' => $configs['md']
                        )
                    ),
                    array(
                        'breakpoint' => 992,
                        'settings' => array(
                            'slidesToShow' => $configs['sm'],
                            'slidesToScroll' => $configs['sm']
                        )
                    ),
                    array(
                        'breakpoint' => 768,
                        'settings' => array(
                            'slidesToShow' => $configs['xs'],
                            'slidesToScroll' => $configs['xs']
                        )
                    )
                )
            );
            if(isset($configs['custom_nav']) && !empty($configs['custom_nav'])){
                $slider_config['appendArrows'] = 'jQuery("'.esc_attr($configs['custom_nav']).'")';
            }
            return json_encode($slider_config);
        }

        public static function getPageHeaderBackgroundOpts(){

            $default = self::getOption('page_header_background', array());
            $current = self::getOptionByMetadata('page_header_background', array());
            $tmp = array();
            if(!is_array($default)) $default = array();
            foreach($default as $k => $v){
                if(empty($v)){
                    unset($default[$k]);
                }
            }
            if ( class_exists( 'WooCommerce' ) && ( is_woocommerce() || is_cart() || is_checkout() || is_account_page() ) ) {
                $shop_page_id = wc_get_page_id( 'shop' );
                if($shop_page_id > 0){
                    if( $shop_default = self::getPostMeta( $shop_page_id, OASIS_OPTION, 'page_header_background', true ) ) {
                        if( is_array( $shop_default ) ) {
                            foreach ( $shop_default as $k => $v ) {
                                if( '' !== $v ) {
                                    $tmp[$k] = $v;
                                }
                            }
                        }
                    }
                }
            }

            if( is_post_type_archive('la_portfolio') || is_tax( get_object_taxonomies( 'la_portfolio' ))){
                $portfolio_default = Oasis_Helper::getOption('portfolio_page_header_background', array());

                if(!empty($portfolio_default) && is_array($portfolio_default)){
                    foreach ($portfolio_default as $k => $v ){
                        if( '' !== $v ) {
                            $tmp[$k] = $v;
                        }
                    }
                }
            }

            if( is_array( $current ) ) {
                foreach ( $current as $k => $v ) {
                    if( '' !== $v ) {
                        $tmp[$k] = $v;
                    }
                }
            }

            return array_merge( $default , $tmp );
        }

        public static function renderBackgroundProperty($options){
            if(!empty($options) && is_array($options)){
                foreach ($options as $k => $val){
                    if(!empty($val)){
                        printf('background-%s: %s;'
                            , esc_attr($k)
                            , ($k == 'image' ? 'url('.esc_url($val).')' : esc_attr($val))
                        );
                    }
                }
            }
        }

        public static function getAllImageSizes(){
            global $_wp_additional_image_sizes;
            $sizes = array();

            foreach ( get_intermediate_image_sizes() as $_size ) {
                if ( in_array( $_size, array('thumbnail', 'medium', 'medium_large', 'large') ) ) {
                    $sizes[ $_size ]['width']  = get_option( "{$_size}_size_w" );
                    $sizes[ $_size ]['height'] = get_option( "{$_size}_size_h" );
                    $sizes[ $_size ]['crop']   = (bool) get_option( "{$_size}_crop" );
                } elseif ( isset( $_wp_additional_image_sizes[ $_size ] ) ) {
                    $sizes[ $_size ] = array(
                        'width'  => $_wp_additional_image_sizes[ $_size ]['width'],
                        'height' => $_wp_additional_image_sizes[ $_size ]['height'],
                        'crop'   => $_wp_additional_image_sizes[ $_size ]['crop'],
                    );
                }
            }

            return $sizes;
        }

        public static function generateThumbnailSrc( $attachment_id, $size ){

            return wp_get_attachment_image_src($attachment_id, $size);
        }

        public static function getRemainingTime( $end_date ){
            $days    = floor( ( $end_date - time() ) / 60 / 60 / 24 );
            $hours   = floor( ( $end_date - time() ) / 60 / 60 ) - ( $days * 24 );
            $minutes = floor( ( $end_date - time() ) / 60 ) - ( $hours * 60 );
            $seconds = ( $end_date - time() ) - ( $minutes * 60 );
            return array(
                'gmt' => get_option( 'gmt_offset' ),
                'to'  => $end_date,
                'dd'  => ( $days > 10 ) ? $days : '0' . $days,
                'hh'  => ( $hours > 10 ) ? $hours : '0' . $hours,
                'mm'  => ( $minutes > 10 ) ? $minutes : '0' . $minutes,
                'ss'  => ( $seconds > 10 ) ? $seconds : '0' . $seconds,
            );
        }
    }

}