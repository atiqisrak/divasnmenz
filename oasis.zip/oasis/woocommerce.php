<?php
if(is_singular( 'product' ) && isset($_GET['product_quickview'])){
    remove_action('woocommerce_single_product_summary', 'woocommerce_template_single_excerpt', 20);
    remove_action('woocommerce_single_product_summary', 'woocommerce_template_single_sharing', 50);
    remove_all_actions('woocommerce_after_single_product_summary');
    while ( have_posts() ) : the_post();

        wc_get_template_part( 'content', 'single-quickview' );

    endwhile;
}
else{
    get_header();
    ?>
    <?php do_action( 'oasis/action/before_render_main' ); ?>
    <div id="main" class="site-main">
        <div class="container">
            <div class="row">
                <main id="site-content" class="<?php echo esc_attr(Oasis()->getLayout()->getMainContentCssClass('col-xs-12 site-content'))?>">
                    <div class="site-content-inner">

                        <?php do_action( 'oasis/action/before_render_main_inner' );?>

                        <div class="page-content">
                            <?php

                            do_action( 'oasis/action/before_render_main_content' );

                            woocommerce_content();

                            do_action( 'oasis/action/after_render_main_content' );

                            ?>
                        </div>

                        <?php do_action( 'oasis/action/after_render_main_inner' );?>
                    </div>
                </main>
                <!-- #site-content -->
                <?php get_sidebar();?>
            </div>
        </div>
    </div>
    <!-- .site-main -->
    <?php do_action( 'oasis/action/after_render_main' ); ?>
    <?php get_footer();?>
<?php } ?>