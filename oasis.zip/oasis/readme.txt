=== Oasis ===
Contributors: LA Studio
Requires at least: WordPress 4.9
Tested up to: WordPress 5.0.1, WooCommerce 3.5.2
Version: 1.1.7
Tags: one-column, two-columns, three-columns, left-sidebar, right-sidebar,  custom-background, custom-header, custom-menu, featured-images, flexible-header, full-width-template, post-formats, sticky-post, theme-options, translation-ready

== Description ==

Oasis - Creative WordPress Theme

* Mobile-first, Responsive Layout
* Custom Colors
* Custom Header
* Social Links
* Mega Menu
* Post Formats

== Installation ==

1. Navigate to Appearance → Themes in your WordPress admin dashboard.
2. Click the Add New button at the top of the page then go for the Theme Upload option.
3. For the file upload, pick Theme Files / oasis.zip in the theme package downloaded from ThemeForest and click Install Now.
4. Click Activate once the upload has finished.

== Copyright ==

Copyright 2015-2016 La-StudioWeb.com

== Changelog ==

------------ Version 1.1.7 [December 12, 2018]  ------------
* Compatibility with Wordpress 5.0.1
* Compatibility with WooCommerce 3.5.2
^ Update latest plugins: Revolution Slider, Visual Composer

Files has changed
    oasis/style.css
    oasis/assets/css/woocommerce.css
    oasis/assets/css/theme.css
    oasis/plugins/plugins.php
    oasis/plugins/js_composer.zip
    oasis/plugins/revslider.zip
    oasis/woocommerce/single-product/product-image.php
    oasis/woocommerce/single-product/product-thumbnails.php

------------ Version 1.1.6 [October 26, 2018]  ------------
* Compatibility with Wordpress 4.9.8
* Compatibility with WooCommerce 3.5.0
^ Update latest plugins: Revolution Slider, Visual Composer

The list files has changed
    oasis/style.css
    oasis/plugins/plugins.php
    oasis/plugins/js_composer.zip
    oasis/plugins/revslider.zip
    oasis/woocommerce/content-single-product.php
    oasis/woocommerce/content-product.php
    oasis/woocommerce/loop/add-to-cart.php
    oasis/woocommerce/single-product/product-image.php
    oasis/woocommerce/single-product/product-thumbnails.php
    oasis/woocommerce/product-searchform.php
    oasis/woocommerce/loop/loop-start.php
    oasis/woocommerce/loop/orderby.php
    oasis/woocommerce/loop/pagination.php

------------ Version 1.1.5 [October 17, 2017]  ------------
* Compatibility with Wordpress 4.8.2
* Compatibility with WooCommerce 3.2.1
^ Update latest plugins: Revolution Slider, Visual Composer
^ Update language file

The list files has changed
    oasis/framework/classes/visual-composer.php
    oasis/plugins/tgm-plugin-activation/class-tgm-plugin-activation.php
    oasis/plugins/plugins.php
    oasis/woocommerce/single-product/product-image.php
    oasis/woocommerce/single-product/product-thumbnails.php
    oasis/framework/configs/theme-option.php
    oasis/style.css
    oasis/languages/oasis.pot
    oasis/plugins/revslider.zip
    oasis/plugins/js_composer.zip


= 1.1.4 ( May 03, 2017 )=
# Fixed Popup cannot close anymore!

= 1.1.3 =
* Update : April 15, 2017
* Compatibility with Wordpress 4.7.3
* Compatibility with WooCommerce 3.0
^ Update latest plugins: WooCommerce0, Revolution Slider, Visual Composer, LaStudio Core
^ Add Option Loading Icon
^ Add page header option into product page.
# Fixed LA Swatches Photo


= 1.1.2 =
* Update : January 18, 2017
* Compatibility with Wordpress 4.7.1
^ Update latest plugins: Woocommerce, LaStudio Core ..
#Fixed Theme Options not working when enable ssl mode
#Fixed upsell products display not correctly

= 1.1.1 =
* Update : December 21, 2016
#Fixed "Access defined!" when importer the demo.

= 1.1 =
* Update : December 18, 2016
* Compatibility with Wordpress 4.7
^ Update latest plugins: Visual Composer, Woocommerce, LaStudio Core ..
^ Add "Out of stock" badge in product list & detail
^ Add option Show popup when add to link success
^ Add option change page loader spinner
^ Add option enable Newsletter Popup
^ Add Option Shop Infinite Scroll
# Remove Demo Selector
# Fixed Social sharing link
# Fixed a few of bugs about display


= 1.0.2 =
* Update : November 10, 2016
# Fix Color swatches plugin

= 1.0.1 =
* Update : November 10, 2016
* Fix imported demo problem not works on PHP 5.4 & run faster
* Tweak color swatches plugin

= 1.0 =
* Released: November 08, 2016

Initial release