<?php
global $oasis_loop;
if(!has_post_thumbnail()){
    return;
}
if(!isset($oasis_loop['loop_index'])){
    $oasis_loop['loop_index'] = 0;
}
$oasis_loop['loop_index']++;
$loop_index     = isset($oasis_loop['loop_index']) ? $oasis_loop['loop_index'] : 1;
$thumbnail_size = isset($oasis_loop['image_size']) && !empty($oasis_loop['image_size']) ? $oasis_loop['image_size'] : 'thumbnail';
$title_tag      = isset($oasis_loop['title_tag']) && !empty($oasis_loop['title_tag']) ? $oasis_loop['title_tag'] : 'h3';
$post_class     = array('loop-item','portfolio-item');
$thumbnail_size = apply_filters('oasis/portfolio-loop/thumbnail-size', $thumbnail_size);

?>
<article <?php post_class($post_class); ?>>
    <div data-vc-full-width="true" data-vc-full-width-init="false" data-vc-parallax="1.1" class="vc_row wpb_row vc_row-fluid vc_row-has-fill vc_row-o-full-height vc_row-o-columns-middle vc_row-o-content-middle vc_row-flex vc_general vc_parallax vc_parallax-content-moving" style="background-image: url(<?php echo esc_url(get_the_post_thumbnail_url(get_the_ID(),'full')) ?>);">
        <div class="vc_column_container col-xs-12 col-sm-6 col-md-5 item--thumbnail">
            <div class="vc_column-inner">
                <?php do_action('oasis/before_resize_image'); ?>
                <a href="<?php the_permalink()?>"><?php the_post_thumbnail($thumbnail_size)?></a>
                <?php do_action('oasis/after_resize_image'); ?>
            </div>
        </div>
        <div class="vc_column_container col-xs-12 col-sm-6 col-md-5 col-md-offset-1 item--info">
            <div class="vc_column-inner">
                <div class="item--category">
                    <?php the_terms(get_the_ID(), 'la_portfolio_category', '', '');?>
                </div>
                <header class="entry-header">
                    <?php the_title( sprintf( '<%s class="entry-title"><a href="%s">',$title_tag, esc_url( get_the_permalink() ) ), sprintf('</a></%s>', $title_tag) ); ?>
                </header>
                <div class="item--excerpt">
                    <?php the_excerpt(); ?>
                </div>
                <footer>
                    <a class="view--portfolio" href="<?php the_permalink()?>"><?php esc_html_e('See more', 'oasis')?></a>
                </footer>
            </div>
        </div>
        <div class="item--overlay"></div>
    </div>
    <div class="vc_row-full-width vc_clearfix"></div>
</article>