<?php
global $oasis_loop;
if(!has_post_thumbnail()){
    return;
}
if(!isset($oasis_loop['loop_index'])){
    $oasis_loop['loop_index'] = 0;
}
$oasis_loop['loop_index']++;
$loop_index     = isset($oasis_loop['loop_index']) ? $oasis_loop['loop_index'] : 1;
$thumbnail_size = isset($oasis_loop['image_size']) && !empty($oasis_loop['image_size']) ? $oasis_loop['image_size'] : 'thumbnail';
$title_tag      = isset($oasis_loop['title_tag']) && !empty($oasis_loop['title_tag']) ? $oasis_loop['title_tag'] : 'h3';
$post_class     = array('loop-item','grid-item','portfolio-item', 'item-overlay-effect');
$thumbnail_size = apply_filters('oasis/portfolio-loop/thumbnail-size', $thumbnail_size);

?>
<article <?php post_class($post_class); ?>>
    <div class="item-inner">
        <div class="item--thumbnail">
            <?php do_action('oasis/before_resize_image'); ?>
            <a href="<?php the_permalink()?>"><?php the_post_thumbnail($thumbnail_size)?><div class="item--overlay"></div></a>
            <?php do_action('oasis/after_resize_image'); ?>
        </div>
        <div class="item--info item--holder">
            <div class="item--info-inner">
                <div class="item--category">
                    <?php the_terms(get_the_ID(), 'la_portfolio_category', '', '');?>
                </div>
                <header class="entry-header">
                    <?php the_title( sprintf( '<%s class="entry-title"><a href="%s">',$title_tag, esc_url( get_the_permalink() ) ), sprintf('</a></%s>', $title_tag) ); ?>
                </header>
            </div>
        </div>
        <a class="item--link-overlay" href="<?php the_permalink()?>"></a>
    </div>
</article>