<?php
global $oasis_loop;
$thumbnail_size = (isset($oasis_loop['image_size']) && !empty($oasis_loop['image_size']) ? $oasis_loop['image_size'] : 'thumbnail');
$title_tag      = (isset($oasis_loop['title_tag']) && !empty($oasis_loop['title_tag']) ? $oasis_loop['title_tag'] : 'h3');
$role           = Oasis_Helper::getPostMeta(get_the_ID(), OASIS_OPTION, 'role');
$post_class     = array('loop-item','grid-item','testimonial-item');
?>
<article <?php post_class($post_class)?>>
    <div class="item-inner">
        <div class="item-inner2">
            <div class="item--excerpt"><?php the_content();?></div>
        </div>

        <div class="item--image">
            <?php do_action('oasis/before_resize_image'); ?>
            <a href="javascript:;"><?php
                if(has_post_thumbnail()){
                    the_post_thumbnail($thumbnail_size);
                }else{
                    Oasis_Helper::getImagePlaceHolder($thumbnail_size);
                }
                ?></a>
            <?php do_action('oasis/after_resize_image'); ?>
        </div>
        <div class="item--info">
            <?php
            echo sprintf(
                '<%1$s class="%5$s"><a href="%2$s">%3$s</a></%4$s>',
                esc_attr($title_tag),
                'javascript:;',
                get_the_title(),
                esc_attr($title_tag),
                'item--title'
            );
            if(!empty($role)){
                echo sprintf(
                    '<p class="item--role">%s</p>',
                    esc_html($role)
                );
            }
            ?>
        </div>
    </div>
</article><!-- .loop-item -->