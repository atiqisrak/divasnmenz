(function($) {
    'use strict';

    function find_child_menu_item($item){
        var menu_id = $item.find('.menu-item-data-db-id').val();
        return $('.menu-item-data-parent-id[value="'+menu_id+'"]').closest('.menu-item');
    }

    function update_visible_all_menu_item_lv_1_by_lv_0($elem){
        var _this = $elem,
            $menu_item = _this.closest('.menu-item'),
            $childs = find_child_menu_item($menu_item);

        if(_this.val() == 'wide'){
            $childs.find('.field-item-column').removeClass('hidden');
            $childs.find('.field-custom-block').removeClass('hidden');
        }else{
            $childs.find('.field-item-column').addClass('hidden');
            $childs.find('.field-custom-block').addClass('hidden');
        }
    }

    function update_visible_menu_item_lv_1_by_lv_0($menu_item){
        setTimeout(function(){
            if($menu_item.hasClass('menu-item-depth-1')){
                var parent_id = $menu_item.find('.menu-item-data-parent-id').val(),
                    menu_type = $('#menu-item-' + parent_id).find('select[data-depend-id^="menu_type"]').val();
                if(menu_type == 'wide'){
                    $('.field-item-column,.field-custom-block',$menu_item).removeClass('hidden');
                }else{
                    $('.field-item-column,.field-custom-block',$menu_item).addClass('hidden');
                }
            }
        },200)

    }

    function cs_extra_fn_ace_editor( selector ){
        if ( !selector ) {
            selector = $( document ).find( ".cs-section:visible" ).find( '.cs-field-ace_editor:visible' );
        }
        if($( selector).length === 0){
            return;
        }
        $( selector ).each(
            function() {
                var el = $( this );
                el.find( '.ace-editor' ).each(
                    function( index, element ) {
                        var area = element;
                        var params = JSON.parse( $( this ).parent().find( '.localize_data' ).val() );
                        var editor = $( element ).attr( 'data-editor' );

                        var aceeditor = ace.edit( editor );
                        aceeditor.setTheme( "ace/theme/" + $( element ).attr( 'data-theme' ) );
                        aceeditor.getSession().setMode( "ace/mode/" + $( element ).attr( 'data-mode' ) );
                        aceeditor.setOptions( params );
                        aceeditor.on(
                            'change', function( e ) {
                                $( '#' + area.id ).val( aceeditor.getSession().getValue() );
                                aceeditor.resize();
                            }
                        );
                    }
                );
            }
        );
    }

    function post_format_metabox(){
        if($('input[name="post_format"]:checked').length === 0){
            return;
        }

        var $section_format = $('.cs-nav a[data-section="format_option"]'),
            $section_view = $('.cs-nav a[data-section="view"]');

        function check_section(val){

            $('#cs-tab-format_option > .cs-element').hide();

            if(val == 'quote' || val == 'video' || val == 'link' || val == 'audio' || val == 'gallery'){
                $('.cs-element.post_format_' + val).show();
                $section_format.closest('li').show();
                $section_format.trigger('click');
            }else{
                $section_format.closest('li').hide();
                $section_view.trigger('click');
            }
        }

        check_section($('input[name="post_format"]:checked').val());

        $('input[name="post_format"]').on('change',function(){
            check_section($(this).val());
        });
    }

    $(document).ready(function(){

        cs_extra_fn_ace_editor('.cs-field-la_ace_editor');
        post_format_metabox();
        var $menu = $( '#menu-to-edit' );
        $menu.on( 'mouseenter.refreshAccessibility focus.refreshAccessibility touchstart.refreshAccessibility' , '.menu-item' , function(){
            var _this = $(this);
            _this.CSFRAMEWORK_DEPENDENCY();
        } );
        $('.menu-item-depth-0 .lastudio-megamenu-settings select[data-depend-id^="menu_type"]').each(function(){
            update_visible_all_menu_item_lv_1_by_lv_0($(this));
        });
        $menu.on('change', '.menu-item-depth-0 .lastudio-megamenu-settings select[data-depend-id^="menu_type"]',function(){
            update_visible_all_menu_item_lv_1_by_lv_0($(this));
        });
        $menu.on( 'click', 'a.item-edit', function() {
            var _this = $(this).closest('.menu-item');
            _this.CSFRAMEWORK_DEPENDENCY();
        } );

        // Links for moving items
        $menu.on( 'click', '.menus-move', function ( e ) {
            var _this = $(this).closest('.menu-item');
            _this.CSFRAMEWORK_DEPENDENCY();
            update_visible_menu_item_lv_1_by_lv_0(_this);
        });
        $(document)
            .on( 'sortstop',    '#menu-to-edit', function( event, ui ) {
                var menu_item = ui.item;
                menu_item.CSFRAMEWORK_DEPENDENCY();
                update_visible_menu_item_lv_1_by_lv_0(menu_item);
            } )
            .on('click','.cs-remove-bg-image',function(e){
                var _this = $(this),
                    $parent = _this.closest('.cs-field-upload');
                e.preventDefault();
                $parent.find('input').val('');
            })
            .on('click', '.la_swatch_field_meta', function(e){
                $(this).toggleClass('open-form');
            })
            .on('change', '.tab_la_swatches .fields .sub_field select', function(e){
                var $this = $(this);
                $this.closest('.sub_field').find('.attribute_swatch_type').html($this.find('option:selected').text());
                if($this.val() == 'color'){
                    $this.closest('.sub_field').find('.attr-prev-type-color').show();
                    $this.closest('.sub_field').find('.attr-prev-type-image').hide();
                }else{
                    $this.closest('.sub_field').find('.attr-prev-type-color').hide();
                    $this.closest('.sub_field').find('.attr-prev-type-image').show();
                }
            })
            .on('change', '.tab_la_swatches .fields .sub_field input.wp-color-picker', function(){
                var $this = $(this);
                $this.closest('.sub_field').find('.attr-prev-type-color').css('background-color', $this.val());
            })
            .on('change', '.tab_la_swatches .fields .sub_field .cs-field-image input', function(){
                var $this = $(this);
                $this.closest('.sub_field').find('.attr-prev-type-image').html($this.closest('.cs-fieldset').find('.cs-preview').html());
            })
            .on('change', '.tab_la_swatches .fields .la-parent-type-class', function(){
                var $this = $(this);
                $this.closest('.field').find('> .la_swatch_field_meta .attribute_swatch_type').html($this.find('option:selected').text());
            })
            .on('reload', '#variable_product_options', function(e){

                if($('#panel_la_swatches_inner').length == 0){
                    return;
                }
                $( '#woocommerce-product-data' ).block({
                    message: null,
                    overlayCSS: {
                        background: '#fff',
                        opacity: 0.6
                    }
                });
                var this_page = window.location.toString().replace( 'post-new.php?', 'post.php?post=' + woocommerce_admin_meta_boxes.post_id + '&action=edit&' );
                $( '#panel_la_swatches' ).load( this_page + ' #panel_la_swatches_inner', function() {
                    $( '#panel_la_swatches').trigger('reload');
                    $( '#panel_la_swatches').CSFRAMEWORK_DEPENDENCY();
                    $( '#panel_la_swatches').CSFRAMEWORK_RELOAD_PLUGINS();
                });
            })
            .on('woocommerce_variations_saved', '#woocommerce-product-data' ,function(e){
                if($('#panel_la_swatches_inner').length == 0){
                    return;
                }
                $( '#woocommerce-product-data' ).block({
                    message: null,
                    overlayCSS: {
                        background: '#fff',
                        opacity: 0.6
                    }
                });
                var this_page = window.location.toString().replace( 'post-new.php?', 'post.php?post=' + woocommerce_admin_meta_boxes.post_id + '&action=edit&' );
                $( '#panel_la_swatches' ).load( this_page + ' #panel_la_swatches_inner', function() {
                    $( '#panel_la_swatches').trigger('reload');
                    $( '#panel_la_swatches').CSFRAMEWORK_DEPENDENCY();
                    $( '#panel_la_swatches').CSFRAMEWORK_RELOAD_PLUGINS();
                });
            })
    })

})(jQuery);