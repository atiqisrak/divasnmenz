<?php
$show_cart      = (Oasis_Helper::isActiveWooCommerce() && Oasis_Helper::getOption('header_show_cart'));
$show_search    = Oasis_Helper::getOption('header_show_search');
$show_social    = Oasis_Helper::getOption('header_show_social');
$store_address  = Oasis_Helper::getOption('store_address');
$store_phone    = Oasis_Helper::getOption('store_phone');
$store_email    = Oasis_Helper::getOption('store_email');
?>
<?php if($show_social || $store_address || $store_phone || $store_email): ?>
<div id="top-area" class="top-area">
    <div class="container">
        <div class="top-area-items inline-inside">
            <div class="top-area-block top-area-contacts">
                <?php
                    if(!empty($store_email)){
                        printf(
                            '<div class="la-contacts-item la-contacts-email"><a href="%s">%s</a></div>'
                            , esc_url('mailto:' . $store_email)
                            , esc_html($store_email)
                        );
                    }
                    if(!empty($store_phone)){
                        printf(
                            '<div class="la-contacts-item la-contacts-phone">%s</div>'
                            , esc_html($store_phone)
                        );
                    }
                    if(!empty($store_address)){
                        printf(
                            '<div class="la-contacts-item la-contacts-address">%s</div>'
                            , esc_html($store_address)
                        );
                    }
                ?>
            </div>
            <?php if($show_social): ?>
            <div class="top-area-block top-area-socials"><?php oasis_get_social_media(); ?></div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php endif; ?>
<header id="masthead" class="site-header">
    <div class="site-header-inner">
        <div class="container">
            <div class="header-main clearfix">
                <div class="header-left">
                    <div class="site-branding">
                        <a href="<?php echo esc_url( home_url( '/'  ) ); ?>" rel="home">
                            <figure class="logo--normal"><?php Oasis()->getLayout()->renderLogo();?></figure>
                            <figure class="logo--transparency"><?php Oasis()->getLayout()->renderTransparencyLogo();?></figure>
                        </a>
                    </div>
                    <?php if($show_search):?>
                    <div class="header-search">
                        <form method="get" class="search-form" action="<?php echo esc_url( home_url( '/'  ) ); ?>">
                            <input type="search" class="search-field" placeholder="<?php echo esc_attr_x( 'Search entire store', 'placeholder', 'oasis' ); ?>" name="s"/>
                            <button class="search-button" type="submit"><i class="lnr-magnifier"></i></button>
                        </form>
                    </div>
                    <?php endif;?>
                </div>
                <div class="header-right">
                    <?php if(has_nav_menu('top-nav')): ?>
                        <div class="header-top-nav">
                            <nav id="top-area-menu">
                                <?php wp_nav_menu(array(
                                    'theme_location' => 'top-nav',
                                    'depth' => 2,
                                    'container' => false
                                ));
                                ?>
                            </nav>
                        </div>
                    <?php endif; ?>
                    <?php if($show_cart): ?>
                    <div class="header-toggle-cart">
                        <a href="<?php echo esc_url(wc_get_page_permalink('cart')) ?>"><i class="la-icon-bag"></i><span class="la-cart-count"><?php echo esc_html( WC()->cart->get_cart_contents_count() ) ?></span></a>
                        <div class="header_shopping_cart">
                            <div class="widget_shopping_cart_content">
                                <div class="cart-loading"></div>
                            </div>
                        </div>
                    </div>
                    <?php endif;?>
                </div>
            </div>
            <div class="header-bottom clearfix">
                <nav class="site-main-nav clearfix" data-container="#masthead .header-bottom">
                    <?php Oasis()->getLayout()->renderMainNav();?>
                </nav>
            </div>
        </div>
    </div>
</header>
<!-- #masthead -->