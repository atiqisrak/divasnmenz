<?php
$show_cart      = (Oasis_Helper::isActiveWooCommerce() && Oasis_Helper::getOption('header_show_cart'));
$show_search    = Oasis_Helper::getOption('header_show_search');
?>
<header id="masthead" class="site-header">
    <div class="site-header-inner">
        <div class="container">
            <div class="header-main">
                <div class="header-left">
                    <nav class="site-main-nav clearfix" data-container="#masthead">
                        <?php Oasis()->getLayout()->renderMainNav();?>
                    </nav>
                </div>
                <div class="header-middle">
                    <div class="site-branding">
                        <a href="<?php echo esc_url( home_url( '/'  ) ); ?>" rel="home">
                            <figure class="logo--normal"><?php Oasis()->getLayout()->renderLogo();?></figure>
                            <figure class="logo--transparency"><?php Oasis()->getLayout()->renderTransparencyLogo();?></figure>
                        </a>
                    </div>
                </div>
                <div class="header-right">
                    <?php if(has_nav_menu('top-nav')): ?>
                        <div class="header-top-nav">
                            <nav id="top-area-menu">
                                <?php wp_nav_menu(array(
                                    'theme_location' => 'top-nav',
                                    'depth' => 2,
                                    'container' => false
                                ));
                                ?>
                            </nav>
                        </div>
                    <?php endif; ?>
                    <?php if($show_search): ?>
                    <div class="header-search">
                        <form method="get" class="search-form" action="<?php echo esc_url( home_url( '/'  ) ); ?>">
                            <input type="search" class="search-field" placeholder="<?php echo esc_attr_x( 'Search entire store', 'placeholder', 'oasis' ); ?>" name="s"/>
                            <input type="hidden" name="post_type" value="product"/>
                            <button class="search-button" type="submit"><i class="lnr-magnifier"></i></button>
                        </form>
                    </div>
                    <?php endif; ?>
                    <?php if($show_cart): ?>
                    <div class="header-toggle-cart">
                        <a href="<?php echo esc_url(wc_get_page_permalink('cart')) ?>"><i class="la-icon-bag"></i><span class="la-cart-count"><?php echo esc_html( WC()->cart->get_cart_contents_count() ) ?></span></a>
                        <div class="header_shopping_cart">
                            <div class="widget_shopping_cart_content">
                                <div class="cart-loading"></div>
                            </div>
                        </div>
                    </div>
                    <?php endif;?>
                </div>
            </div>
        </div>
    </div>
</header>
<!-- #masthead -->