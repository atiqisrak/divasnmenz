<?php
$show_cart      = (Oasis_Helper::isActiveWooCommerce() && Oasis_Helper::getOption('header_show_cart'));
$show_search    = Oasis_Helper::getOption('header_show_search');
?>
<div class="site-header-mobile">
    <div class="site-header-inner">
        <div class="container">
            <div class="header-main clearfix">
                <div class="header-left">
                    <div class="site-branding">
                        <a href="<?php echo esc_url( home_url( '/'  ) ); ?>" rel="home">
                            <figure><?php Oasis()->getLayout()->renderMobileLogo();?></figure>
                        </a>
                    </div>
                </div>
                <div class="header-right">
                    <?php if($show_cart):?>
                    <div class="header-toggle-cart">
                        <a href="<?php echo esc_url(wc_get_page_permalink('cart')) ?>"><i class="la-icon-bag"></i><span class="la-cart-count"><?php echo esc_html( WC()->cart->get_cart_contents_count() ) ?></span></a>
                        <div class="header_shopping_cart">
                            <div class="widget_shopping_cart_content">
                                <div class="cart-loading"></div>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                    <button class="btn-mobile-menu-trigger menu-toggle-icon"><span class="menu-line-1"></span><span class="menu-line-2"></span><span class="menu-line-3"></span></button>
                </div>
                <div class="mobile-menu-wrap">
                    <?php if($show_search): ?>
                    <form method="get" class="search-form" action="<?php echo esc_url( home_url( '/'  ) ); ?>">
                        <input type="search" class="search-field" placeholder="<?php echo esc_attr_x( 'Search entire store', 'placeholder', 'oasis' ); ?>" name="s"/>
                        <button class="search-button" type="submit"><i class="lnr-magnifier"></i></button>
                    </form>
                    <?php endif;?>
                    <div id="la_mobile_nav" class="dl-menuwrapper"></div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- .site-header-mobile -->