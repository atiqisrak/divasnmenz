<?php
$show_cart      = (Oasis_Helper::isActiveWooCommerce() && Oasis_Helper::getOption('header_show_cart'));
$show_search    = Oasis_Helper::getOption('header_show_search');
$show_social    = Oasis_Helper::getOption('header_show_social');
$store_address  = Oasis_Helper::getOption('store_address');
$store_phone    = Oasis_Helper::getOption('store_phone');
$store_email    = Oasis_Helper::getOption('store_email');
?>
<div id="top-area" class="top-area">
    <div class="container">
        <div class="top-area-items inline-inside">
            <?php if($store_phone): ?>
            <div class="top-area-block top-area-contacts">
                <div class="la-contacts-item la-contacts-phone"><?php echo esc_html($store_phone)?></div>
            </div>
            <?php endif;?>
            <?php if($show_social): ?>
            <div class="top-area-block top-area-socials"><?php oasis_get_social_media(); ?></div>
            <?php endif;?>
            <?php if(has_nav_menu('top-nav')): ?>
                <div class="top-area-block header-top-nav">
                    <nav id="top-area-menu">
                        <?php wp_nav_menu(array(
                            'theme_location' => 'top-nav',
                            'depth' => 2,
                            'container' => false
                        ));
                        ?>
                    </nav>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<header id="masthead" class="site-header">
    <div class="site-header-inner">
        <div class="container">
            <div class="header-main clearfix">
                <div class="header-left">
                    <div class="site-branding">
                        <a href="<?php echo esc_url( home_url( '/'  ) ); ?>" rel="home">
                            <figure class="logo--normal"><?php Oasis()->getLayout()->renderLogo();?></figure>
                            <figure class="logo--transparency"><?php Oasis()->getLayout()->renderTransparencyLogo();?></figure>
                        </a>
                    </div>
                </div>
                <div class="header-right">
                    <?php if($show_search): ?>
                    <div class="header-search">
                        <form method="get" class="search-form" action="<?php echo esc_url( home_url( '/'  ) ); ?>">
                            <input type="search" class="search-field" placeholder="<?php echo esc_attr_x( 'Search entire store', 'placeholder', 'oasis' ); ?>" name="s"/>
                            <button class="search-button" type="submit"><?php esc_html_e('Search', 'oasis'); ?></button>
                        </form>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="header-bottom clearfix">
                <nav class="site-main-nav clearfix"  data-container="#masthead .header-bottom">
                    <?php Oasis()->getLayout()->renderMainNav(array(
                        'show_menu_item_description' => true,
                        'menu_class'    => 'main-menu mega-menu'
                    ));?>
                </nav>
                <?php if($show_cart): ?>
                <div class="header-toggle-cart">
                    <a href="#">
                        <i class="la-icon-bag"></i>
                        <span>
                            <span class="la-cart-text"><?php printf('%s items', WC()->cart->get_cart_contents_count()) ?></span>
                            <span class="la-cart-total-price"><?php echo wp_kses_post(WC()->cart->get_cart_total());?></span>
                        </span>
                    </a>
                    <div class="header_shopping_cart">
                        <div class="widget_shopping_cart_content">
                            <div class="cart-loading"></div>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</header>
<!-- #masthead -->