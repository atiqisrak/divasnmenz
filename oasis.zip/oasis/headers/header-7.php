<?php
$store_address  = Oasis_Helper::getOption('store_address');
$store_phone    = Oasis_Helper::getOption('store_phone');
$store_email    = Oasis_Helper::getOption('store_email');
?>
<div id="header_top_areas" class="header-top-areas">
    <div class="container">
        <div class="header-main clearfix">
            <div class="header-left">
                <div class="header-toggle-cart">
                    <a href="<?php echo esc_url(wc_get_page_permalink('cart')) ?>"><i class="la-icon-bag"></i><span class="la-cart-count">0</span></a>
                    <div class="header_shopping_cart">
                        <div class="widget_shopping_cart_content">
                            <div class="cart-loading"></div>
                        </div>
                    </div>
                </div>
                <div class="header-search">
                    <form method="get" class="search-form" action="<?php echo esc_url( home_url( '/'  ) ); ?>">
                        <input type="search" class="search-field" placeholder="<?php echo esc_attr_x( 'Search entire store', 'placeholder', 'oasis' ); ?>" name="s"/>
                        <button class="search-button" type="submit"><i class="lnr-magnifier"></i></button>
                    </form>
                </div>
            </div>
            <div class="header-right">
                <?php if(has_nav_menu('top-nav')): ?>
                    <div class="header-top-nav">
                        <nav id="top-area-menu">
                            <?php wp_nav_menu(array(
                                'theme_location' => 'top-nav',
                                'depth' => 2,
                                'container' => false
                            ));
                            ?>
                        </nav>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<header id="masthead_aside" class="header--aside">
    <div class="header-aside-wrap">
        <div class="header-aside-inner">
            <button class="menu-toggle-icon header7toogle-sidebar"><span class="menu-line-1"></span><span class="menu-line-2"></span><span class="menu-line-3"></span></button>
            <div class="site-branding">
                <a href="<?php echo esc_url( home_url( '/'  ) ); ?>" rel="home">
                    <figure class="logo--normal"><?php Oasis()->getLayout()->renderLogo();?></figure>
                    <figure class="logo--transparency"><?php Oasis()->getLayout()->renderTransparencyLogo();?></figure>
                </a>
            </div>
            <nav class="site-main-nav menu--vertical menu--vertical-left clearfix">
                <div class="nav-inner" data-container="#masthead_aside">
                    <?php Oasis()->getLayout()->renderMainNav(array(
                        'menu_class'    => 'main-menu mega-menu isVerticalMenu'
                    ));?>
                </div>
            </nav>
            <?php if(!empty($store_email) || !empty($store_address) || !empty($store_phone)) : ?>
            <div class="header-bottom">
                <div class="top-area-items block-inside">
                    <div class="top-area-block top-area-contacts">
                        <?php if(!empty($store_email)): ?>
                        <div class="la-contacts-item la-contacts-email">
                            <a href="<?php echo esc_url('mailto:'. $store_email) ?>"><?php echo $store_email; ?></a>
                        </div>
                        <?php endif; ?>
                        <?php if(!empty($store_phone)): ?>
                        <div class="la-contacts-item la-contacts-phone"><?php echo $store_phone; ?></div>
                        <?php endif; ?>
                        <?php if(!empty($store_address)): ?>
                        <div class="la-contacts-item la-contacts-address"><?php echo $store_address; ?></div>
                        <?php endif; ?>
                    </div>
                    <div class="top-area-block top-area-socials"><?php oasis_get_social_media(); ?></div>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</header>
<!-- #masthead -->