<?php
$show_cart      = (Oasis_Helper::isActiveWooCommerce() && Oasis_Helper::getOption('header_show_cart'));
$show_search    = Oasis_Helper::getOption('header_show_search');
$show_social    = Oasis_Helper::getOption('header_show_social');
$store_address  = Oasis_Helper::getOption('store_address');
$store_phone    = Oasis_Helper::getOption('store_phone');
?>
<aside id="header_aside" class="header--aside">
    <button class="btn-aside-toggle menu-toggle-icon"><span class="menu-line-1"></span><span class="menu-line-2"></span><span class="menu-line-3"></span></button>
    <div class="header-aside-inner">
        <nav class="site-main-nav menu--vertical menu--vertical-right">
            <div class="nav-inner" data-container="#header_aside">
                <?php Oasis()->getLayout()->renderMainNav(array(
                    'menu_class'   => 'main-menu mega-menu isVerticalMenu'
                ));?>
            </div>
        </nav>
        <div class="header-bottom">
            <div class="top-area-items block-title-inside">
                <div class="top-area-block top-area-contacts">
                    <?php if($store_address): ?>
                        <div class="la-contacts-item la-contacts-address"><span><?php esc_html_e('Our Location:','oasis')?></span><span><?php echo esc_html($store_address); ?></span></div>
                    <?php endif;?>
                    <?php if($store_phone): ?>
                    <div class="la-contacts-item la-contacts-phone"><span><?php esc_html_e('24/7 Hotline:','oasis')?></span><span><?php echo esc_html($store_phone);?></span></div>
                    <?php endif; ?>
                </div>
                <?php if($show_social): ?>
                <div class="top-area-block top-area-socials"><?php oasis_get_social_media(); ?></div>
                <?php endif;?>
            </div>
        </div>
    </div>
</aside>
<div class="header-aside-overlay"></div>
<header id="masthead" class="site-header">
    <div class="site-header-inner">
        <div class="container">
            <div class="header-main clearfix">
                <div class="header-left">
                    <div class="site-branding">
                        <a href="<?php echo esc_url( home_url( '/'  ) ); ?>" rel="home">
                            <figure class="logo--normal"><?php Oasis()->getLayout()->renderLogo();?></figure>
                            <figure class="logo--transparency"><?php Oasis()->getLayout()->renderTransparencyLogo();?></figure>
                        </a>
                    </div>
                    <?php if($show_search):?>
                    <div class="header-search">
                        <form method="get" class="search-form" action="<?php echo esc_url( home_url( '/'  ) ); ?>">
                            <input type="search" class="search-field" placeholder="<?php echo esc_attr_x( 'Search entire store', 'placeholder', 'oasis' ); ?>" name="s"/>
                            <button class="search-button" type="submit"><i class="lnr-magnifier"></i></button>
                        </form>
                    </div>
                    <?php endif;?>
                </div>
                <div class="header-right">
                    <?php if(has_nav_menu('top-nav')): ?>
                        <div class="header-top-nav">
                            <nav id="top-area-menu">
                                <?php wp_nav_menu(array(
                                    'theme_location' => 'top-nav',
                                    'depth' => 2,
                                    'container' => false
                                ));
                                ?>
                            </nav>
                        </div>
                    <?php endif; ?>
                    <?php if($show_cart): ?>
                    <div class="header-toggle-cart">
                        <a href="<?php echo esc_url(wc_get_page_permalink('cart')) ?>"><i class="la-icon-bag"></i><span class="la-cart-count"><?php echo esc_html( WC()->cart->get_cart_contents_count() ) ?></span></a>
                        <div class="header_shopping_cart">
                            <div class="widget_shopping_cart_content">
                                <div class="cart-loading"></div>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                    <button class="btn-aside-toggle menu-toggle-icon"><span class="menu-line-1"></span><span class="menu-line-2"></span><span class="menu-line-3"></span></button>
                </div>
            </div>
        </div>
    </div>
</header>
<!-- #masthead -->