<?php
$site_layout = Oasis()->getLayout()->getSiteLayout();
?>
<?php if( $site_layout != 'col-1c' ): ?>
    <aside id="sidebar_primary" class="<?php echo esc_attr(Oasis()->getLayout()->getMainSidebarCssClass('col-xs-12'));?>">
        <div class="sidebar-inner">
            <?php
            if( $site_layout == 'col-2cr' || $site_layout == 'col-2cr-l' ){
	            if(function_exists('is_woocommerce') && is_woocommerce()){
		            if(is_active_sidebar('sidebar-shop-secondary')){
			            dynamic_sidebar('sidebar-shop-secondary');
		            }
		            elseif(is_active_sidebar('sidebar-shop-primary')){
			            dynamic_sidebar('sidebar-shop-primary');
		            }
		            elseif(is_active_sidebar('sidebar-secondary')){
			            dynamic_sidebar('sidebar-secondary');
		            }
		            elseif(is_active_sidebar('sidebar-primary')){
			            dynamic_sidebar('sidebar-primary');
		            }
	            }
				else{
		            if(is_active_sidebar('sidebar-secondary')){
			            dynamic_sidebar('sidebar-secondary');
		            }
		            elseif(is_active_sidebar('sidebar-primary')){
			            dynamic_sidebar('sidebar-primary');
		            }
	            }
            }
            else{
	            if(function_exists('is_woocommerce') && is_woocommerce() && is_active_sidebar('sidebar-shop-primary')){
		            dynamic_sidebar('sidebar-shop-primary');
	            }
	            elseif(is_active_sidebar('sidebar-primary')){
		            dynamic_sidebar('sidebar-primary');
	            }
            }
            ?>
        </div>
    </aside>
<?php endif;?>
<?php if( in_array( $site_layout, array('col-3cl','col-3cm','col-3cr') ) ): ?>
    <aside id="sidebar_secondary" class="<?php echo esc_attr(Oasis()->getLayout()->getSecondSidebarCssClass('col-xs-12'));?>">
        <div class="sidebar-inner">
            <?php
            if(function_exists('is_woocommerce') && is_woocommerce() && is_active_sidebar('sidebar-shop-secondary')){
	            dynamic_sidebar('sidebar-shop-secondary');
            }
            elseif(is_active_sidebar('sidebar-secondary')){
	            dynamic_sidebar('sidebar-secondary');
            }
            ?>
        </div>
    </aside>
    <?php
endif;