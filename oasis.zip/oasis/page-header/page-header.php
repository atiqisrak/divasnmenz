<?php
$show_page_title = apply_filters('oasis/filter/show_page_title', true);
$show_breadcrumbs = apply_filters('oasis/filter/show_breadcrumbs', true);
?>
<section id="section_page_header" class="section-page-header">
    <div class="container">
        <div class="page-header-inner">
            <div class="row">
                <div class="col-xs-12">
                    <?php
                    if($show_page_title){
                        $tag = is_singular() ? 'div' : 'h1';
                        printf('<header><%s class="page-title h2">%s</%s></header>',
                            esc_attr($tag),
                            esc_html(Oasis()->getLayout()->getPageTitle()),
                            esc_attr($tag)
                        );
                    }
                    ?>
                    <?php
                    if($show_breadcrumbs){
                        Oasis()->getLayout()->getBreadcrumbs();
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- #page_header -->